#ifndef RNDAGENT_H
#define RNDAGENT_H

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <sstream>
#include <fstream>
#include <algorithm>

#include <chrono>

#include "defs.h"
#include "AbstractAgent.h"
#include "GeneAgent.h"

using namespace std;

class RndAgent : public GeneAgent {
public:
    // int count;
    // double relativeFitness, absoluteFitness;
    // string thisGeneStr;

    // int *myGenes, numGenes;
    int theTracked;

    RndAgent() {
        printf("Default constructor shouldn't be used\n");
        exit(1);
    }

    RndAgent(string geneStr) {
        thisGeneStr = geneStr;
        if (geneStr == "") {
            // cout << "creating random TFTAgent" << endl;
            numGenes = predef_NUMGENES_RND;
            myGenes = new int[numGenes];
            for (int i = 0; i < numGenes; i++) {
                myGenes[i] = rand() % 101;
            }
        }
        else {
            // cout << "tft geneStr: " << geneStr << endl;
            vector<string> words = parse(geneStr);
            numGenes = words.size()-1;

            if (numGenes != predef_NUMGENES_RND) {
                printf("confusion about the number of genes I should have; %i vs %i\n", predef_NUMGENES_RND, numGenes);
                exit(1);
            }

            myGenes = new int[numGenes];
            for (int i = 1; i < numGenes+1; i++)    // // // put +1 back once generate it
                myGenes[i-1] = stoi(words[i]);
        }

        count = 0;
        relativeFitness = absoluteFitness = 0.0;
        whoami = getString();
        theTracked = getTracked();

        playedGenes = true;

        int total = myGenes[RND_Give] + myGenes[RND_Take] + myGenes[RND_Keep];
        givePercent = myGenes[RND_Give] / (double)total;
        takePercent = myGenes[RND_Take] / (double)total;

        // cout << "takePercent: " << takePercent << "; givePercent: " << givePercent << endl;

        //nPlayers = 0;
    }

    ~RndAgent() {
        delete[] myGenes;
    }

    void playRound(int numPlayers, int numTokens, int playerIdx, int roundNum, double *received, double *popularities, double **influence, int *allocations) {
        // cout << "*** playRound: " << playerIdx << endl;

        printT(playerIdx, vec2String(received, numPlayers));

        for (int i = 0; i < numPlayers; i++)
            allocations[i] = 0;

        if (theTracked != 99999)
            theTracked = getTracked();

        if (playerIdx == theTracked)
            printf("\n\n\nRound %i (Player %i)\n", roundNum, theTracked);

        for (int i = 0; i < numTokens; i++) {
            double val = (rand() / (double)RAND_MAX);
            // cout << "val: " << val << endl;

            int quien = rand() % numPlayers;
            while (quien == playerIdx)
                quien = rand() % numPlayers;

            // cout << "quien: " << quien << endl;

            if (val >= (givePercent + takePercent)) {
                allocations[playerIdx] ++;
            }
            else if (allocations[quien] == 0) {
                if (val < givePercent) {
                    allocations[quien] = 1;
                }
                else {
                    allocations[quien] = -1;
                }
            }
            else {
                if (allocations[quien] < 0)
                    allocations[quien] --;
                else
                    allocations[quien] ++;
            }

        }

        // cout << vec2String(allocations, numPlayers) << endl;
    }

    string getString() {
        string theStr = "tft";
        for (int i = 0; i < numGenes; i++) {
            theStr += "_" + to_string(myGenes[i]);
        }

        return theStr;
    }

    void postContract(int playerIdx) {}

// ************************************************************************
// 
//      Now all of the functions and data members that make it happen
// 
// ************************************************************************
private:
    double givePercent, takePercent;

    vector<string> parse(const string& s) {
        vector<string> tokens;
        string token;
        istringstream tokenStream(s);
        while (getline(tokenStream, token, '_'))
            tokens.push_back(token);
        return tokens;
    }

    void printT(int ind, string msg) {
        if (ind == theTracked)
            cout << msg << endl;
    }

    string vec2String(double *vec, int len) {
        string s;
        for (int i = 0; i < len; i++) {
            s += to_string(vec[i]) + " ";
        }

        return s;
    }

    string vec2String(int *vec, int len) {
        string s;
        for (int i = 0; i < len; i++)
            s += to_string(vec[i]) + " ";

        return s;
    }

    string vec2String(bool *vec, int len) {
        string s;
        for (int i = 0; i < len; i++)
            s += to_string((int)(vec[i])) + " ";

        return s;
    }

    int getTracked() {
        ifstream input("ScenarioIndicator/theTracked.txt");

        string line;
        getline(input, line);
        int val = stoi(line);

        input.close();

        return val;
    }


};

#endif