#ifndef SCRIPTED_H
#define SCRIPTED_H

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class Scripted : public AbstractAgent {
public:
    Scripted() {
        cout << "Scripted: no player number specified" << endl;
        exit(1);
    }

    Scripted(int playerIdx) {
        string fnombre = "Scripts/p" + to_string(playerIdx) + ".dat";
        fstream input(fnombre);
        string line;
        while (getline(input,line)) {
            // split the line into actions
            vector<string> words = split(line);

            // load it into a vector
            vector<int> v;
            for (int i = 0; i < words.size(); i++)
                v.push_back(stoi(words[i]));

            // add the vector to myAllocations
            myAllocations.push_back(v);
        }

        input.close();

        cout << playerIdx << ": rounds of play: " << myAllocations.size() << endl;
        for (int i = 0; i < myAllocations.size(); i++) {
            for (int j = 0; j < myAllocations[i].size(); j++) {
                cout << myAllocations[i][j] << " ";
            }
            cout << endl;
        }
    }

    ~Scripted() {}

    void playRound(int numPlayers, int numTokens, int playerIdx, int roundNum, double *received, double *popularities, double **influence, int *allocations) {
        for (int i = 0; i < numPlayers; i++) {
            allocations[i] = myAllocations[roundNum][i];
        }
    }

    void postContract(int playerIdx) {}

    vector<string> split(const string& s) {
        vector<string> tokens;
        string token;
        istringstream tokenStream(s);
        while (getline(tokenStream, token, ' '))
           tokens.push_back(token);
        return tokens;
     }     
    
    vector< vector<int> > myAllocations;
};

#endif