#ifndef GOVTRACKER_H
#define GOVTRACKER_H

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

#define GENE_TAX            0
#define GENE_REDIST         1
#define GENE_POWER          2
#define GENE_punEVASION     3
#define GENE_punTHEFT       4
#define GENE_remVICTIM      5
#define GENE_CRIMETHRESH    6
#define GENE_punCOEF        7

class GovTracker {
public:

    GovTracker() {
        cout << "incomplete GovTracker constructor" << endl;
        exit(1);
    }

    GovTracker(int numGenes) {
        // create a random govment
        for (int i = 0; i < numGenes; i++)
            genes.push_back(rand() % 101);

        fitness = 0.0;
    }

    GovTracker(string str) {
        vector<string> words = split(str);

        for (int i = 0; i < words.size(); i++)
            genes.push_back(stoi(words[i]));
    }

    GovTracker(GovTracker *g1, GovTracker *g2) {
        // evolve a new govment from these two padres
        for (int i = 0; i < g1->genes.size(); i++) {
            if (rand() % 2)
                genes.push_back(g1->genes[i]);
            else
                genes.push_back(g2->genes[i]);

            // decide whether to mutate it later
            genes[i] = mutateIt(genes[i]);
        }

        fitness = 0.0;
    }

    ~GovTracker() {}

    int mutateIt(int gene) {
        // int v = rand() % 100;
        int v = rand() % 100;
        if (v >= 15)
            return gene;
        else if (v < 3)
            return rand() % 101;
        else {
            int g = gene + (rand() % 11) - 5;
            if (g < 0)
                g = 0;
            if (g > 100)
                g = 100;
            return g;
        }
    }    

    void write2File() {
        ofstream output("Institutions/inevolution.txt");

        output << "Membership:Forced" << endl;

        if (genes[GENE_TAX] < 33)
            output << "Tax:Progressive" << endl;
        else if (genes[GENE_TAX] < 67)
            output << "Tax:Flat" << endl;
        else
            output << "Tax:Regressive" << endl;

        if (genes[GENE_REDIST] < 25)
            output << "Redistribution:Progressive" << endl;
        else if (genes[GENE_REDIST] < 50)
            output << "Redistribution:Proportional" << endl;
        else if (genes[GENE_REDIST] < 75)
            output << "Redistribution:Merit" << endl;
        else
            output << "Redistribution:Regressive" << endl;
        
        output << "Power:" << (genes[GENE_POWER] / 2.0) << endl;                            // values can be up to 50%

        if (genes[GENE_punEVASION] < 50)
            output << "PunishTaxEvasion:False" << endl;
        else
            output << "PunishTaxEvasion:True" << endl;

        if (genes[GENE_punTHEFT] < 50)
            output << "PunishStealing:False" << endl;
        else
            output << "PunishStealing:True" << endl;

        if (genes[GENE_remVICTIM] < 50)
            output << "RemunerateVictims:False" << endl;
        else
            output << "RemunerateVictims:True" << endl;

        output << "StealCrimeThreshold_percent:" << (genes[GENE_CRIMETHRESH] / 200.0) << endl; // values can be up to 0.50

        output << "PunishmentStrength:" << (genes[GENE_punCOEF] / 25.0) << endl;              // values can be up to 4.0

        output.close();
    }

    string toString() {
        string str = "";
        for (int i = 0; i < genes.size()-1; i++) {
            str += to_string(genes[i]) + "_";
        }
        str += to_string(genes[genes.size()-1]);

        return str;
    }

    vector<string> split(const string& s) {
        vector<string> tokens;
        string token;
        istringstream tokenStream(s);
        while (getline(tokenStream, token, '_'))
           tokens.push_back(token);
        return tokens;
    }    

    vector<int> genes;
    double fitness;
};

#endif
