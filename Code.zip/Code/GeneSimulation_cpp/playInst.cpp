#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>

#include "JHGEngine.h"

#include "AbstractAgent.h"
#include "Institution.h"
#include "Coop.h"
#include "CABAgent.h"
#include "GeneAgent.h"
#include "HumanAgent.h"
#include "assassinAgent.h"

#include "GovTracker.h"

using namespace std;

struct CoopGameMetrics {
    vector<int> plyrKeep, plyrTake, plyrGive;
    vector<double> endPop;
    vector<int> coopChoice;
    int coop1Keep, coop1Take, coop1Give;
    double coop1EndPop, coop1AvePop;
    int coop2Keep, coop2Take, coop2Give;
    double coop2EndPop, coop2AvePop;
};

struct PopularityMetrics {
    double avePop, endPop, relPop, growth;
    int keepCount, stealCount, giveCount;
    int taxPaid, taxOwed;
};

struct GameSummaryMetrics {
    double avePop, aveGrowth, giniIndex, percKeep, percTake, percGive, govPower, percGKeep, percGTake, percGGive, percTaxPaid;
};

struct PerfLog {
    int count;
    double score;
};

struct TaxScheme {
    int percentPay;
    int count;
    double increase;

    TaxScheme(int percent) {
        percentPay = percent;
        count = 0;
        increase = 0.0;
    }
};

PopularityMetrics *globalPmetrics;

vector<string> split(const string& s) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(s);
    while (getline(tokenStream, token, ','))
       tokens.push_back(token);
    return tokens;
}
 
CABAgent **loadPopulationFromFile(string fnombre, int popSize, int numGeneCopies) {
    string probPayTaxes;
    // allocate memory for theGenePools
    CABAgent **parameterizations = new CABAgent*[popSize];
    ifstream input(fnombre);
    for (int i = 0; i < popSize; i++) {
        string line;
        getline(input, line);
        vector<string> words = split(line);

        // theGenePools[i] = new CABAgent(words[0], numGeneCopies);
        if ((rand() % 3) == 0)
            probPayTaxes = to_string(50 + rand() % 51);
        else
            probPayTaxes = "100";
        parameterizations[i] = new CABAgent(words[0], numGeneCopies, probPayTaxes);

        parameterizations[i]->count = stoi(words[1]);
        parameterizations[i]->scaledFitness = stod(words[2]);
    }
    input.close();

    return parameterizations;
}

CABAgent **loadPopulationFromFile_inst(string fnombre, string clase, int popSize, int numGeneCopies, string instType) {
    string probPayTaxes;
    // allocate memory for theGenePools
    CABAgent **parameterizations = new CABAgent*[popSize];
    ifstream input(fnombre + "_" + clase + ".csv");
    for (int i = 0; i < popSize; i++) {
        string line;
        getline(input, line);
        // cout << line << endl;
        vector<string> words = split(line);

        // theGenePools[i] = new CABAgent(words[0], numGeneCopies);
        // if ((rand() % 3) == 0)
        //     probPayTaxes = to_string(50 + rand() % 51);
        // else
        //     probPayTaxes = "100";

        // cout << words[1] << endl;

        parameterizations[i] = new CABAgent(words[0], instType, stoi(words[1]));//stoi(words[1]), stoi(words[2]), stoi(words[3]));

        parameterizations[i]->count = stoi(words[2]);
        parameterizations[i]->scaledFitness = stod(words[3]);
    }
    input.close();

    return parameterizations;
}

TaxScheme **loadTaxSchemesFromFile(string fnombre, int popSize) {
    TaxScheme **schemes = new TaxScheme*[popSize];
    ifstream input(fnombre);
    for (int i = 0; i < 11; i++) {
        string line;
        getline(input, line);
        vector<string> words = split(line);
        schemes[i] = new TaxScheme(stoi(words[0]));
        schemes[i]->count = stoi(words[1]);
        schemes[i]->increase = stof(words[2]);
    }
    input.close();

    return schemes;
}

vector<double> readInitPops(string _fnombre) {
    string fnombre = "initPops/" + _fnombre + ".txt";

    ifstream input(fnombre);
    if (!input) {
        cout << "initial pops file not found: " << fnombre << endl;
        exit(1);
    }

    vector<double> pops;
    string line;
    while (getline(input, line)) {
        pops.push_back(stof(line));
    }

    input.close();

    return pops;
}

void recordState(int roundNum, JHGEngine *jhg, int humanInd, bool gameOver) {
    ofstream output("../State/state.tmp");

    if (!gameOver)
        output << "inprogress" << endl;
    else
        output << "fin" << endl;
    output << jhg->numPlayers << endl;
    output << humanInd << endl;
    output << roundNum << endl;

    // print out the popularities
    for (int i = 0; i < jhg->numPlayers; i++) {
        for (int r = 0; r < roundNum+1; r++)
            output << jhg->P[r][i] << " ";
        output << endl;
    }

    // print out the last round's token allocations
    for (int i = 0; i < jhg->numPlayers; i++) {
        for (int j = 0; j < jhg->numPlayers; j++) {
            if (jhg->T[roundNum][i][j] < 0)
                output << (int)(jhg->T[roundNum][i][j] * jhg->numTokens - 0.01) << " ";
            else
                output << (int)(jhg->T[roundNum][i][j] * jhg->numTokens + 0.01) << " ";
        }
        output << endl;
    }

    // print out the current tornadoValues
    // for (int i = 0; i < jhg->numPlayers; i++) {
    //     for (int j = 0; j < jhg->numPlayers; j++)
    //         output << jhg->I[roundNum][j][i] << " ";
    //     output << endl;
    // }

    for (int t = 0; t <= roundNum; t++) {
        for (int i = 0; i < jhg->numPlayers; i++) {
            for (int j = 0; j < jhg->numPlayers; j++)
                output << jhg->I[t][j][i] << " ";
            output << endl;
        }
    }

    // print out the previous tornadoValues
    // for (int i = 0; i < jhg->numPlayers; i++) {
    //     for (int j = 0; j < jhg->numPlayers; j++)
    //         if (roundNum > 0)
    //             output << jhg->I[roundNum-1][j][i] << " ";
    //         else
    //             output << jhg->I[0][j][i] << " ";
    //     output << endl;
    // }

    output.close();

    system("mv ../State/state.tmp ../State/state.txt");
}

vector<int> getTaxesOwed(int govInd) {
    vector<int> taxesOwed;

    ifstream input("Contracts/taxes_" + to_string(govInd) + ".txt");
    
    if (input) {
        string line;
        int i = 0;
        while (getline(input,line)) {
            // cout << "* " << line << endl;
            taxesOwed.push_back(stoi(line));
            i++;
        }

        input.close();
    }

    return taxesOwed;
}

PopularityMetrics *playGame(vector<AbstractAgent *> agents, int numRounds, int gener, int gamer, vector<double> initialPopularities, double povertyLine, bool forcedRandom) {
    double alpha = 0.2;
    double beta = 1.0; // only fortune, no fame
    double coefs[3] = {0.95, 1.3, 1.6};

    int numPlayers = agents.size();

    // delete all existing contracts
    system("rm Contracts/*");

    // tell agents the game parameters and give each the chance to post a contract
    for (int i = 0; i < numPlayers; i++) {
        agents[i]->setGameParams(coefs, alpha, beta, povertyLine, forcedRandom);
        // printf("%s\n", ((GeneAgent *)agents[i])->getString().c_str());
        agents[i]->postContract(i);
    }

    int humanInd = -1;
    for (int i = 0; i < numPlayers; i++) {
        if (agents[i]->whoami == "human") {
            humanInd = i;
            break;
        }
    }

    // int numTokens = numPlayers;
    int numTokens = 2 * numPlayers;

    // allocate some memory for transactions
    double *received = new double[numPlayers];
    int **transactions = new int*[numPlayers];
    for (int i = 0; i < numPlayers; i++)
        transactions[i] = new int[numPlayers];
    
    PopularityMetrics *pmetrics = new PopularityMetrics[numPlayers];
    for (int i = 0; i < numPlayers; i++) {
        pmetrics[i].avePop = 0.0;
        pmetrics[i].endPop = 0.0;
        pmetrics[i].keepCount = pmetrics[i].stealCount = pmetrics[i].giveCount = 0;
        pmetrics[i].taxPaid = pmetrics[i].taxOwed = 0;
    }

    // cout << "before game engine" << endl;

    // set up the game simulator
    JHGEngine *jhg = new JHGEngine(coefs, alpha, beta, povertyLine, numPlayers, numTokens, numRounds, initialPopularities);
    // cout << "after game engine" << endl;
    for (int r = 0; r < numRounds; r++) {
        if (humanInd >= 0)
            recordState(r, jhg, humanInd, false);


        vector<int> taxesOwed;
        // get each player's token allocations
        for (int i = 0; i < numPlayers; i++) {
            for (int j = 0; j < numPlayers; j++) {
                received[j] = jhg->T[r][j][i];
            }

            // cout << "\n(antes) Coop assignments: - - ";
            // for (int i = 2; i < 11; i++) {
            //     cout << ((CABAgent *)(agents[i]))->myCoop << " ";
            // }
            // cout << endl;    

            // printf("%i is %s\n", i, agents[i]->whoami.c_str()); fflush(stdout);
            agents[i]->playRound(numPlayers, numTokens, i, r, received, jhg->P[r], jhg->I[r], transactions[i]);

            // cout << "(despues) Coop assignments: - - ";
            // for (int i = 2; i < 11; i++) {
            //     cout << ((CABAgent *)(agents[i]))->myCoop << " ";
            // }
            // cout << endl;    
    
            if (i == 0) {
                // cout << "get taxes owed" << endl;
                taxesOwed = getTaxesOwed(0);
            }
            else if (taxesOwed.size() > 0) {
                // cout << i << " paid " << transactions[i][0] << " out of " << taxesOwed[i] << " in taxes" << endl;
                pmetrics[i].taxPaid += transactions[i][0];
                pmetrics[i].taxOwed += taxesOwed[i];
            }

            for (int j = 0; j < numPlayers; j++) {
                if (i == j)
                    pmetrics[i].keepCount += transactions[i][j];
                else if (transactions[i][j] > 0)
                    pmetrics[i].giveCount += transactions[i][j];
                else
                    pmetrics[i].stealCount -= transactions[i][j];
            }
        }

        // compute changes
        jhg->playRound(transactions);

        // record popularities
        for (int i = 0; i < numPlayers; i++) {
            pmetrics[i].avePop += jhg->P[jhg->t][i] / numRounds;
            pmetrics[i].endPop = jhg->P[jhg->t][i];
        }
    }

    // jhg->printP();

    if (humanInd >= 0)
        recordState(numRounds, jhg, humanInd, true);

    // log game
    string fnombre = "../Results/theGameLogs/log_" + to_string(gener) + "_" + to_string(gamer) + ".csv";
    jhg->save(fnombre);

    for (int i = 0; i < numPlayers; i++)
        delete[] transactions[i];
    delete[] transactions;
    delete[] received;
    delete jhg;

    double s = 0.0;
    for (int i = 0; i < numPlayers; i++)
        s += pmetrics[i].avePop;
    for (int i = 0; i < numPlayers; i++) {
        pmetrics[i].relPop = pmetrics[i].avePop / s;
        pmetrics[i].growth = pmetrics[i].endPop / initialPopularities[i];
    }

    return pmetrics;
}

vector<double> giveGovPower(vector<double> initialPopularities, int govInd, double poder) {
    double amount = 0.0;

    for (int i = 0; i < initialPopularities.size(); i++) {
        if (i != govInd) {
            double a = (poder / 100.0) * initialPopularities[i];
            initialPopularities[i] -= a;
            amount += a;
        }
    }

    initialPopularities[govInd] = amount;

    // cout << "revised popularities: ";
    // for (int i = 0; i < initialPopularities.size(); i++)
    //     cout << initialPopularities[i] << " ";
    // cout << endl;

    return initialPopularities;
}

PopularityMetrics *playRandomGame(CABAgent** hCABs, TaxScheme **taxSchemes, int numRounds, string initPopsFile, string configFile, string theGovment, bool update = true, int numhCABs = 100, bool conCoops = false) {
    vector<double> initialPopularities = readInitPops(initPopsFile);
    vector<double> initialPopularities2;

    double hCAB_mag = 0.0;
    for (int i = 0; i < numhCABs; i++)
        hCAB_mag += hCABs[i]->scaledFitness * hCABs[i]->scaledFitness * hCABs[i]->scaledFitness;

    double taxScheme_mag = 0.0;
    if (taxSchemes != NULL) {
        for (int i = 0; i < 11; i++)
            taxScheme_mag += taxSchemes[i]->increase * taxSchemes[i]->increase * taxSchemes[i]->increase;
    }

    // cout << "got here" << endl;

    // read in special players
    vector<AbstractAgent *> players;

    vector<int> plyrIdx;
    vector<int> taxIdx;

    int govInd = -1;
    string fnombre = "Players/";
    fnombre += configFile;
    fnombre += ".txt";
    ifstream in(fnombre);
    if (!in)
        cout << "config file not found: " << fnombre << endl;
    else {
        string line;
        while (!in.eof()) {
            getline(in, line);
            if (line == "hcab") {
                // select a random hcab based on fitness
                double num = rand() / (double)RAND_MAX;
                double s = 0.0;
                int idx = -1;
                for (int i = 0; i < numhCABs; i++) {
                    s += hCABs[i]->scaledFitness * hCABs[i]->scaledFitness * hCABs[i]->scaledFitness;
                    if (num <= (s / hCAB_mag)) {
                        idx = i;
                        break;
                    }
                }
                if (idx < 0) {
                    cout << "Shouldn't have happened 1" << endl;
                    idx = 99;
                }

                // cout << "picked hcab " << idx << endl;

                // players.push_back(hCABs[idx]);
                if (!conCoops) 
                    players.push_back(new CABAgent(hCABs[idx]->thisGeneStr, 1, "0,1,2,2"));
                else {
                    // cout << hCABs[idx]->myCoopPoor << endl;
                    players.push_back(new CABAgent(hCABs[idx]->thisGeneStr, "Coop", hCABs[idx]->myCoop));
                }

                int idx2 = -1;
                if (taxSchemes != NULL) {
                    // select a random taxScheme based on fitness
                    num = rand() / (double)RAND_MAX;
                    s = 0.0;
                    for (int i = 0; i < 11; i++) {
                        s += taxSchemes[i]->increase * taxSchemes[i]->increase * taxSchemes[i]->increase;
                        if (num <= (s / taxScheme_mag)) {
                            idx2 = i;
                            break;
                        }
                    }
                    if (idx2 < 0) {
                        cout << "Shouldn't have happened 2 -- num: " << num << "; s: " << s << "; taxScheme_mag: " << taxScheme_mag << endl;
                        idx2 = 100;
                    }

                    // cout << "percentPay: " << taxSchemes[idx2]->percentPay << endl;
                    // hCABs[idx]->payTaxes = taxSchemes[idx2]->percentPay;
                    ((CABAgent *)(players[players.size()-1]))->payTaxes = taxSchemes[idx2]->percentPay;
                }

                // cout << "hardwiring tax payment at 100%" << endl;
                // hCABs[idx]->payTaxes = 100.0;

                ((CABAgent *)(players[players.size()-1]))->payTaxes = 100.0;

                // cout << "selected " << idx << " with a tax payment rate of " << hCABs[idx]->payTaxes << " (" << taxSchemes[idx2]->percentPay << ")" << endl;
                plyrIdx.push_back(idx);
                taxIdx.push_back(idx2);
            }
            else if (line == "Human") {
                players.push_back(new HumanAgent());
                plyrIdx.push_back(-1);
                taxIdx.push_back(-1);
            }
            else if (line == "Assassin") {
                players.push_back(new assassinAgent());
                plyrIdx.push_back(-1);
                taxIdx.push_back(-1);
            }
            else if (line == "govment") {
                // cout << "found the govment: " << theGovment << endl;
                govInd = (int)(players.size());
                players.push_back(new Institution(theGovment));
                plyrIdx.push_back(-1);
                taxIdx.push_back(-1);
            }
            else if (line.substr(0,4) == "coop") {
                // cout << "found a coop: " << line << endl;
                players.push_back(new Coop(line));
                plyrIdx.push_back(-1);
                taxIdx.push_back(-1);
            }
        }
        in.close();
    }

    if (govInd != -1) {
        initialPopularities2 = giveGovPower(initialPopularities, govInd, ((Institution *)(players[govInd]))->poder);
    }
    else {
        for (int i = 0; i < players.size(); i++)
            initialPopularities2.push_back(initialPopularities[i]);
    }

    // cout << "num players: " << players.size() << endl;
    // cout << "types of players in the game:" << endl;
    // for (int i = 0; i < players.size(); i++) {
    //     cout << players[i]->whoami << endl;
    // }
    // cout << endl;

    if (players.size() != initialPopularities.size()) {
        cout << "number of agents in config and initpop files don't match: " << players.size() << " vs " << initialPopularities.size() << endl;
        exit(1);
    }

    // cout << "a" << endl;

    // play a game
    PopularityMetrics *pmetrics = playGame(players, numRounds, 1000, 1000, initialPopularities2, 0.0, false);

    // cout << "b" << endl;

    // delete and update fitnesses
    for (int i = 0; i < players.size(); i++) {
        if (players[i]->whoami != "govment") {
            if (initialPopularities[i] > 0.0)
                pmetrics[i].growth = (pmetrics[i].growth * initialPopularities2[i]) / initialPopularities[i];
            // cout << pmetrics[i].growth << endl;
        }

        if (update) {
            double fitness = pmetrics[i].endPop / initialPopularities[i];
            // double fitness = pmetrics[i].growth; // / initialPopularities[i];
            if (plyrIdx[i] >= 0) {
                // cout << "player " << i << " got an increase of " << fitness << endl;
                hCABs[plyrIdx[i]]->count ++;
                double lambda = max(0.05, 1.0 / (1.0 + hCABs[plyrIdx[i]]->count));
                hCABs[plyrIdx[i]]->scaledFitness = lambda * fitness + (1.0 - lambda) * hCABs[plyrIdx[i]]->scaledFitness;
            }
            if (taxSchemes != NULL) {
                if (taxIdx[i] >= 0) {
                    taxSchemes[taxIdx[i]]->count ++;
                    double lambda = max(0.05, 1.0 / (1.0 + taxSchemes[taxIdx[i]]->count));
                    taxSchemes[taxIdx[i]]->increase = lambda * fitness + (1.0 - lambda) * taxSchemes[taxIdx[i]]->increase;
                }
            }
        }

        if (players[i]->whoami == "govment")
            delete (Institution *)(players[i]);
        else if (players[i]->whoami == "human")
            delete (HumanAgent *)(players[i]);
        else if (players[i]->whoami == "Assassin")
            delete (assassinAgent *)(players[i]);
        else if (players[i]->whoami.substr(0,4) == "coop")
            delete (Coop *)(players[i]);
        else {
            // cout << "deleting CAB agent " << i << ": " << players[i]->whoami << endl;
            delete (CABAgent *)(players[i]);
        }
    }

    return pmetrics;
}

vector<int> getSocialClass(vector<double> popularities) {
    // cout << "numPlayers: " << numPlayers << endl;
    // cout << popularities[playerIdx] << endl;
    double mean = 0.0;
    int cnt = 0;
    for (int i = 0; i < popularities.size(); i++) {
        // cout << govPlayers[i]->govPlayer << endl;
        // if (!(govPlayers[i]->govPlayer)) {
        if (popularities[i] > 0.0) {
            mean += popularities[i];
            cnt ++;
        }
    }
    mean /= cnt;
    // cout << "mean popularity = " << mean << endl;

    // cout << "mean: " << mean << endl;
    vector<int> playerClasses;
    for (int i = 0; i < popularities.size(); i++) {
        if (popularities[i] < (0.5 * mean))
            playerClasses.push_back(0);   // poor
        else if (popularities[i] < (1.5 * mean))
            playerClasses.push_back(1);   // middle class
        else
            playerClasses.push_back(2);   // rich
    }

    return playerClasses;
}


// struct CoopGameMetrics {
//     vector<int> plyrKeep, plyrTake, plyrGive;
//     vector<double> endPop;
//     vector<int> coopChoice;
//     int coop1Keep, coop1Take, coop1Give;
//     double coop1EndPop, coop1AvePop;
//     int coop2Keep, coop2Take, coop2Give;
//     double coop2EndPop, coop2AvePop;
// };
CoopGameMetrics playRandomGame_choice(CABAgent** poorhCABs, CABAgent** middlehCABs, CABAgent** richhCABs, TaxScheme **taxSchemes, int numRounds, string initPopsFile, string configFile, string theGovment, bool update = true, int numhCABs = 100, string conCoops = "none") {

    // conCoops = "Coop";          // temporarily hardwiring this for one coop using play3

    vector<double> initialPopularities = readInitPops(initPopsFile);
    vector<double> initialPopularities2;

    vector<int> playerClasses = getSocialClass(initialPopularities);

    // for (int i = 0; i < playerClasses.size(); i++) {
    //     cout << "player " << i << ", which popularity = " << initialPopularities[i] << ", is in class " << playerClasses[i] << endl;
    // }

    double hCAB_mag_poor = 0.0;
    for (int i = 0; i < numhCABs; i++) {
        hCAB_mag_poor += poorhCABs[i]->scaledFitness * poorhCABs[i]->scaledFitness * poorhCABs[i]->scaledFitness;
    }
    double hCAB_mag_middle = 0.0;
    for (int i = 0; i < numhCABs; i++)
        hCAB_mag_middle += middlehCABs[i]->scaledFitness * middlehCABs[i]->scaledFitness * middlehCABs[i]->scaledFitness;
    double hCAB_mag_rich = 0.0;
    for (int i = 0; i < numhCABs; i++)
        hCAB_mag_rich += richhCABs[i]->scaledFitness * richhCABs[i]->scaledFitness * richhCABs[i]->scaledFitness;

    double taxScheme_mag = 0.0;
    if (taxSchemes != NULL) {
        for (int i = 0; i < 11; i++)
            taxScheme_mag += taxSchemes[i]->increase * taxSchemes[i]->increase * taxSchemes[i]->increase;
    }

    // cout << "a" << endl;

    // read in special players
    vector<AbstractAgent *> players;

    vector<int> plyrIdx;
    vector<int> taxIdx;

    int govInd = -1;
    string fnombre = "Players/";
    fnombre += configFile;
    fnombre += ".txt";
    ifstream in(fnombre);
    if (!in)
        cout << "config file not found: " << fnombre << endl;
    else {
        string line;
        while (!in.eof()) {
            getline(in, line);
            if (line == "hcab") {
                // figure out the starting class of this agent
                CABAgent **hCABs;
                double hCAB_mag;
                if (playerClasses[players.size()] == 0) {
                    hCABs = poorhCABs;
                    hCAB_mag = hCAB_mag_poor;
                    // cout << players.size() << " is poor" << endl;
                }
                else if (playerClasses[players.size()] == 1) {
                    hCABs = middlehCABs;
                    hCAB_mag = hCAB_mag_middle;
                    // cout << players.size() << " is middle class" << endl;
                }
                else if (playerClasses[players.size()] == 2) {
                    hCABs = richhCABs;
                    hCAB_mag = hCAB_mag_rich;
                    // cout << players.size() << " is rich" << endl;
                }

                // select a random hcab based on fitness
                double num = rand() / (double)RAND_MAX;
                double s = 0.0;
                int idx = -1;
                for (int i = 0; i < numhCABs; i++) {
                    s += hCABs[i]->scaledFitness * hCABs[i]->scaledFitness * hCABs[i]->scaledFitness;
                    if (num <= (s / hCAB_mag)) {
                        idx = i;
                        break;
                    }
                }
                if (idx < 0) {
                    cout << "Shouldn't have happened 1" << endl;
                    idx = 99;
                }

                // cout << "picked hcab " << idx << endl;

                // players.push_back(hCABs[idx]);
                // cout << hCABs[idx]->payTaxes << endl;
                if (conCoops == "none") 
                    players.push_back(new CABAgent(hCABs[idx]->thisGeneStr, 1, "0,1,2,2"));
                else if (conCoops == "Gov") {
                    players.push_back(new CABAgent(hCABs[idx]->thisGeneStr, "Gov", hCABs[idx]->payTaxes / 100));
                }
                else if (conCoops == "Coop") {
                    // cout << hCABs[idx]->myCoopPoor << endl;
                    // cout << "     " << idx << endl;
                    // cout << "got here" << endl;
                    players.push_back(new CABAgent(hCABs[idx]->thisGeneStr, "Coop", hCABs[idx]->myCoop));
                }
                else {
                    cout << "Estoy perdido" << endl;
                    exit(1);
                }

                int idx2 = -1;
                if (taxSchemes != NULL) {
                    // select a random taxScheme based on fitness
                    num = rand() / (double)RAND_MAX;
                    s = 0.0;
                    for (int i = 0; i < 11; i++) {
                        s += taxSchemes[i]->increase * taxSchemes[i]->increase * taxSchemes[i]->increase;
                        if (num <= (s / taxScheme_mag)) {
                            idx2 = i;
                            break;
                        }
                    }
                    if (idx2 < 0) {
                        cout << "Shouldn't have happened 2 -- num: " << num << "; s: " << s << "; taxScheme_mag: " << taxScheme_mag << endl;
                        idx2 = 100;
                    }

                    // cout << "percentPay: " << taxSchemes[idx2]->percentPay << endl;
                    // hCABs[idx]->payTaxes = taxSchemes[idx2]->percentPay;
                    ((CABAgent *)(players[players.size()-1]))->payTaxes = taxSchemes[idx2]->percentPay;
                }

                // cout << "hardwiring tax payment at 100%" << endl;
                // hCABs[idx]->payTaxes = 100.0;
                if (conCoops == "Coop")
                    ((CABAgent *)(players[players.size()-1]))->payTaxes = 100.0;
                // else
                //     ((CABAgent *)(players[players.size()-1]))->payTaxes = ;
                    // cout << (((CABAgent *)(players[players.size()-1]))->payTaxes) << endl;

                // cout << "selected " << idx << " with a tax payment rate of " << hCABs[idx]->payTaxes << " (" << taxSchemes[idx2]->percentPay << ")" << endl;
                plyrIdx.push_back(idx);
                taxIdx.push_back(idx2);
            }
            else if (line == "Human") {
                players.push_back(new HumanAgent());
                plyrIdx.push_back(-1);
                taxIdx.push_back(-1);
            }
            else if (line == "Assassin") {
                players.push_back(new assassinAgent());
                plyrIdx.push_back(-1);
                taxIdx.push_back(-1);
            }
            else if (line == "govment") {
                // cout << "found the govment: " << theGovment << endl;
                govInd = (int)(players.size());
                players.push_back(new Institution(theGovment));
                plyrIdx.push_back(-1);
                taxIdx.push_back(-1);
            }
            else if (line.substr(0,4) == "coop") {
                // cout << "found a coop: " << line << endl;
                players.push_back(new Coop(line));
                plyrIdx.push_back(-1);
                taxIdx.push_back(-1);
            }
        }
        in.close();
    }

    // cout << "govInd: " << govInd << endl;

    if (govInd != -1) {
        initialPopularities2 = giveGovPower(initialPopularities, govInd, ((Institution *)(players[govInd]))->poder);
    }
    else {
        for (int i = 0; i < players.size(); i++)
            initialPopularities2.push_back(initialPopularities[i]);
    }

    // cout << "a" << endl;

    // cout << "num players: " << players.size() << endl;
    // cout << "types of players in the game:" << endl;
    // for (int i = 0; i < players.size(); i++) {
    //     cout << players[i]->whoami << endl;
    // }
    // cout << endl;

    if (players.size() != initialPopularities.size()) {
        cout << "number of agents in config and initpop files don't match: " << players.size() << " vs " << initialPopularities.size() << endl;
        exit(1);
    }

    // cout << "b" << endl;

    // play a game
    PopularityMetrics *pmetrics = playGame(players, numRounds, 1000, 1000, initialPopularities2, 0.0, false);

    // cout << "c" << endl;

    CoopGameMetrics cgm;
    cgm.coop1EndPop = cgm.coop2EndPop = -1;
    vector<string> nombres;
    ifstream in2(fnombre);
    if (!in2) {
        cout << "config file not found: " << fnombre << endl;
    }
    else {
        string line;
        while (getline(in2, line))
            nombres.push_back(line);
        in2.close();
    }
    int c = 0;

    // cout << "d" << endl;

    // delete, update fitnesses, and fill in cgm
    for (int i = 0; i < players.size(); i++) {
        // cout << plyrIdx[i] << endl;
        if (players[i]->whoami != "govment") {
            if (initialPopularities[i] > 0.0)
                pmetrics[i].growth = (pmetrics[i].growth * initialPopularities2[i]) / initialPopularities[i];
            // cout << pmetrics[i].growth << endl;
        }

        CABAgent **hCABs;
        if (playerClasses[i] == 0) {
            hCABs = poorhCABs;
        }
        else if (playerClasses[i] == 1) {
            hCABs = middlehCABs;
        }
        else if (playerClasses[i] == 2) {
            hCABs = richhCABs;
        }

        if (nombres[i] == "coop1") {
            // this is coop1 stuff
            cgm.coop1EndPop = pmetrics[i].endPop;
            cgm.coop1AvePop = pmetrics[i].avePop;
            cgm.coop1Keep = pmetrics[i].keepCount;
            cgm.coop1Take = pmetrics[i].stealCount;
            cgm.coop1Give = pmetrics[i].giveCount;
            // cout << "coop1" << endl;
        }
        else if (nombres[i] == "coop2") {
            // this is coop2 stuff
            cgm.coop2EndPop = pmetrics[i].endPop;
            cgm.coop2AvePop = pmetrics[i].avePop;
            cgm.coop2Keep = pmetrics[i].keepCount;
            cgm.coop2Take = pmetrics[i].stealCount;
            cgm.coop2Give = pmetrics[i].giveCount;
        }
        else if (nombres[i] == "govment") {
            cgm.coop1EndPop = pmetrics[i].endPop;
            cgm.coop1AvePop = pmetrics[i].avePop;
            cgm.coop1Keep = pmetrics[i].keepCount;
            cgm.coop1Take = pmetrics[i].stealCount;
            cgm.coop1Give = pmetrics[i].giveCount;
        }
        else if ((nombres[i] == "hcab") || (nombres[i] == "Human")) {
            cgm.endPop.push_back(pmetrics[i].endPop);
            if (nombres[i] == "hcab")
                // cgm.coopChoice.push_back(hCABs[plyrIdx[i]]->myCoop);
                cgm.coopChoice.push_back(((CABAgent *)(players[i]))->myCoop);
            else
                cgm.coopChoice.push_back(-2);
            // cout << nombres[i] << ": " << cgm.coopChoice[cgm.coopChoice.size()-1] << endl;
            cgm.plyrKeep.push_back(pmetrics[i].keepCount);
            cgm.plyrTake.push_back(pmetrics[i].stealCount);
            cgm.plyrGive.push_back(pmetrics[i].giveCount);

            c++;
        }

        if (update) {
            // cout << "update" << endl;
            double fitness = pmetrics[i].endPop / initialPopularities[i];
            // double fitness = pmetrics[i].growth; // / initialPopularities[i];
            if (plyrIdx[i] >= 0) {
                // cout << "player " << i << " (" << plyrIdx[i] << "), who is " << playerClasses[i] << ", got an increase of " << fitness << endl;
                hCABs[plyrIdx[i]]->count ++;
                double lambda = max(0.05, 1.0 / (1.0 + hCABs[plyrIdx[i]]->count));
                hCABs[plyrIdx[i]]->scaledFitness = lambda * fitness + (1.0 - lambda) * hCABs[plyrIdx[i]]->scaledFitness;
            }
            if (taxSchemes != NULL) {
                if (taxIdx[i] >= 0) {
                    taxSchemes[taxIdx[i]]->count ++;
                    double lambda = max(0.05, 1.0 / (1.0 + taxSchemes[taxIdx[i]]->count));
                    taxSchemes[taxIdx[i]]->increase = lambda * fitness + (1.0 - lambda) * taxSchemes[taxIdx[i]]->increase;
                }
            }
            // cout << "done with update" << endl;
        }

        // cout << players[i]->whoami << endl;
        if ((players[i]->whoami.substr(0,3) == "gov") || (players[i]->whoami == "inevolution")) {
            // cout << "delete the govment" << endl;
            delete (Institution *)(players[i]);
        }
        else if (players[i]->whoami == "human")
            delete (HumanAgent *)(players[i]);
        else if ((players[i]->whoami == "assassin") || (players[i]->whoami == "Assassin"))
            delete (assassinAgent *)(players[i]);
        else if (players[i]->whoami.substr(0,4) == "coop")
            delete (Coop *)(players[i]);
        else {
            // cout << "deleting CAB agent " << i << ": " << players[i]->whoami << endl;
            delete (CABAgent *)(players[i]);
        }
        // cout << "done deleting" << endl;
    }

    globalPmetrics = pmetrics;

    return cgm;
}

GameSummaryMetrics deriveMetrics(PopularityMetrics *pmetrics, string configFile) {
    GameSummaryMetrics metrics;

    vector<string> nombres;
    string fnombre = "Players/";
    fnombre += configFile;
    fnombre += ".txt";
    ifstream in(fnombre);
    if (!in) {
        cout << "config file not found: " << fnombre << endl;
    }
    else {
        string line;
        while (getline(in, line))
            nombres.push_back(line);
        in.close();
    }

    // compute the average popularity
    double avePop = 0.0;
    int c = 0;
    metrics.govPower = 0;
    for (int i = 0; i < nombres.size(); i++) {
        if (nombres[i] != "govment") {
            // cout << "   " << pmetrics[i].endPop << endl;
            avePop += pmetrics[i].endPop;
            c++;
        }
        else {
            metrics.govPower = pmetrics[i].endPop;
        }
    }
    // cout << "Average popularity: " << (avePop / c) << endl;
    metrics.avePop = avePop / c;

    // compute the gini coefficient
    double numerator = 0.0, s = 0.0;
    for (int i = 0; i < nombres.size(); i++) {
        for (int j = 0; j < nombres.size(); j++) {
            if ((nombres[i] == "govment") || (nombres[j] == "govment"))
                continue;

            numerator += fabs(pmetrics[i].endPop - pmetrics[j].endPop);
        }
        if (nombres[i] != "govment")
            s += pmetrics[i].endPop;
    }
    metrics.giniIndex = numerator / (2.0 * c * s);
    // cout << "Gini index: " << gini << endl;

    // compute average economic behavior
    int take = 0, give = 0, keep = 0;
    int Gtake = 0, Ggive = 0, Gkeep = 0, tPaid = 0, tOwed = 0;
    for (int i = 0; i < nombres.size(); i++) {
        if (nombres[i] == "govment") {
            Gtake += pmetrics[i].stealCount;
            Ggive += pmetrics[i].giveCount;
            Gkeep += pmetrics[i].keepCount;
        }
        else {
            take += pmetrics[i].stealCount;
            give += pmetrics[i].giveCount;
            keep += pmetrics[i].keepCount;
            tPaid += pmetrics[i].taxPaid;
            tOwed += pmetrics[i].taxOwed;
        }
    }
    double total = take + give + keep;
    // cout << "Keep: " << ((double)keep / total) << "; Give: " << ((double)give / total) << "; Steal: " << ((double)take / total) << endl;
    metrics.percKeep = keep / total;
    metrics.percTake = take / total;
    metrics.percGive = give / total;

    if (tOwed > 0)
        metrics.percTaxPaid = tPaid / (double)tOwed;
    else
        metrics.percTaxPaid = -1.0;

    double Gtotal = Gtake + Ggive + Gkeep;
    if (Gtotal > 0.0) {
        metrics.percGKeep = Gkeep / Gtotal;
        metrics.percGTake = Gtake / Gtotal;
        metrics.percGGive = Ggive / Gtotal;
    }
    else {
        metrics.percGKeep = metrics.percGTake = metrics.percGGive = 0.0;
    }

    // compute average growth
    double growth = 0.0;
    for (int i = 0; i < nombres.size(); i++) {
        if (nombres[i] == "govment")
            continue;

        growth += pmetrics[i].growth;
    }
    metrics.aveGrowth = growth / c;

    return metrics;
}

int selectByFitness(vector<GovTracker *> theGovs) {
    double mag = 0.0;
    for (int i = 0; i < theGovs.size(); i++)
        mag += theGovs[i]->fitness;

    double num = rand() / ((double)RAND_MAX);

    double sum = 0.0;
    for (int i = 0; i < theGovs.size(); i++) {
        sum += theGovs[i]->fitness / mag;

        if (num <= sum)
            return i;
    }

    printf("didn't select; num = %lf; sum = %lf\n", num, sum);
    exit(1);

    return (int)(theGovs.size())-1;
}

vector<GovTracker *> evolveGovs(vector<GovTracker *> theGovs) {
    vector<GovTracker *> theNewGovs;
    int numGovs = theGovs.size();
    for (int i = 0; i < numGovs; i++) {
        int uno = selectByFitness(theGovs);
        int dos = selectByFitness(theGovs);

        theNewGovs.push_back(new GovTracker(theGovs[uno], theGovs[dos]));
    }

    return theNewGovs;
}

double scoreSociety(GameSummaryMetrics metrics, string objectivo) {
    double score;
    if (objectivo == "50-50") {     // balanced priorities
        double sw = metrics.avePop / 500.0;
        double gini = (0.5 - metrics.giniIndex) / 0.5;
        if (gini < 0.0)
            gini = 0.0;

        // score = (sw * sw) + (gini * gini);
        score = min(sw, gini);
        cout << "SW: " << metrics.avePop << "; " << "GiniIndex: " << metrics.giniIndex << " = " << score << endl;
    }
    else if (objectivo == "80-20") {  // prioritize average welfare of society members
        double sw = metrics.avePop / 500.0;
        double gini = (0.5 - metrics.giniIndex) / 0.5;
        if (gini < 0.0)
            gini = 0.0;

        score = 0.8 * (sw * sw) + 0.2 * (gini * gini);
        cout << "SW: " << metrics.avePop << "; " << "GiniIndex: " << metrics.giniIndex << " = " << score << endl;
    }
    else if (objectivo == "20-80") {. // prioritize balance
        double sw = metrics.avePop / 500.0;
        double gini = (0.5 - metrics.giniIndex) / 0.5;
        if (gini < 0.0)
            gini = 0.0;

        score = 0.2 * (sw * sw) + 0.8 * (gini * gini);
        cout << "SW: " << metrics.avePop << "; " << "GiniIndex: " << metrics.giniIndex << " = " << score << endl;
    }
    else if (objectivo == "govPower") { // prioritize government power
        score = metrics.govPower;
        // cout << "SW: " << metrics.avePop << "; " << "GiniIndex: " << metrics.giniIndex << " = " << score << endl;
        cout << "govPower: " << score << endl;
    }
    else {
        cout << "objectivo not found: " << objectivo << endl;
        exit(1);
    }

    return score;
}

// void addAgentInfo(vector<double> &combinedAgent, string str) {
//     ifstream input(str);

//     string line;
//     for (int i = 0; i < 100; i++) {
//         getline(input, line);
//         vector<string> words = split(line);
//         combinedAgent[i] += stof(words[3]);
//     }

//     input.close();
// }

// void addTaxInfo(vector<double> &combinedTax, string str) {
//     ifstream input(str);

//     string line;
//     for (int i = 0; i < 11; i++) {
//         getline(input, line);
//         vector<string> words = split(line);
//         combinedTax[i] += stof(words[3]);
//     }

//     input.close();
// }

CABAgent **createStrategicHCABs() {

    CABAgent **tmpCABs = loadPopulationFromFile("../Tuning/hcabs_raw.csv", 100, 1);

    // for each hCAB make 3 of them
    CABAgent **hCABs = new CABAgent*[300];
    int count = 0;
    for (int i = 0; i < 100; i++) {
        for (int choice = -1; choice < 2; choice++) {
            hCABs[count] = new CABAgent(tmpCABs[i]->thisGeneStr, "Coop", choice);
            hCABs[count]->scaledFitness = 30.0;
            count ++;
        }
    }

    // delete tmpCABs
    for (int i = 0; i < 100; i++) {
        delete tmpCABs[i];
    }
    delete[] tmpCABs;

    return hCABs;
}

CABAgent **createGovHCABs() {

    CABAgent **tmpCABs = loadPopulationFromFile("../Tuning/hcabs_raw.csv", 100, 1);

    // for each hCAB make 3 of them
    CABAgent **hCABs = new CABAgent*[200];
    int count = 0;
    for (int i = 0; i < 100; i++) {
        for (int choice = 0; choice < 2; choice++) {
            hCABs[count] = new CABAgent(tmpCABs[i]->thisGeneStr, "Gov", choice);
            hCABs[count]->scaledFitness = 2.0;
            count ++;
        }
    }

    // delete tmpCABs
    for (int i = 0; i < 100; i++) {
        delete tmpCABs[i];
    }
    delete[] tmpCABs;

    return hCABs;
} 

void randomizeCoopMembership(int numPlayers) {
    ofstream output("Coops/coopAssignments.txt");

    output << "0" << endl;      // this is for the coop
    for (int i = 0; i < numPlayers; i++) {
        if ((rand() % 4) == 0)
            output << "0" << endl;
        else
            output << "1" << endl;     // coop assignment of player i
    }

    output.close();
}

double computeInitialGini(string nombre) {
    vector<double> pops;

    string fnombre = "initPops/" + nombre + ".txt";
    cout << fnombre << endl;
    ifstream input(fnombre);
    if (!input) {
        cout << "que pasa" << endl;
    }
    int c = 0;
    for (int i = 0; i < 20; i++) {
        double val;
        input >> val;
        pops.push_back(val);
        c ++;
    }
    input.close();

    cout << c << endl;

    // compute the initial gini index
    double numerator = 0.0, s = 0.0;
    for (int i = 0; i < pops.size(); i++) {
        for (int j = 0; j < pops.size(); j++) {
            numerator += fabs(pops[i] - pops[j]);
        }
        s += pops[i];
    }
    return numerator / (2.0 * c * s);
}


// ***********************************************************************
//
//      ./jhginst play [numRounds] [initialPops] [hcabs] [taxpayment] [player_config] [govment] [numGames]
// 
//      ./jhginst tune [numRounds] [initialPops] [hcabs] [taxpayment] [player_config] [govment] [numGames]
//
//      ./jhginst evolve [sizeGenePool] [numGens] [gamesPerGov] [scenario_config]
// 
//      ./jhginst tune3 [numRounds] [initialPops] [hcabs] [player_config] [numGames]
// 
//      ./jhginst play3 [numRounds] [initialPops] [hcabs] [player_config] [numGames]
// 
//      ./jhginst tuneDuelingCoops [numRounds] [initialPops] [hcabs] [player_config] [numGames]
//
//      ./jhginst playDuelingCoops [numRounds] [initialPops] [hcabs] [player_config] [numGames]
// 
//      ./jhginst tuneGov [numRounds] [initialPops] [hcabs] [player_config] [govment] [numGames]
//
//      ./jhginst playGov [numRounds] [initialPops] [hcabs] [player_config] [govment] [numGames]
//
//      ./jhginst evolveGov [sizeGenePool] [numGens] [gamesPerGov] [scenario_config]
//
// ***********************************************************************
int main(int argc, char *argv[]) {
    srand(time(NULL));

    if (!strcmp(argv[1], "play")) {
        if (argc != 9) {
            printf("wrong number of parameters to specify how to *play*: %i\n", argc);
            return -1;
        }

        int numRounds = atoi(argv[2]);
        string argv4(argv[4]), argv5(argv[5]);
        string cabNombre = "../Tuning/" + argv4 + ".csv";
        string taxNombre = "../Tuning/" + argv5 + ".csv";
        int numGames = atoi(argv[8]);

        for (int g = 0; g < numGames; g++) {
            // read in the hCABs
            CABAgent** hCABs = loadPopulationFromFile(cabNombre, 100, 1);
            TaxScheme **taxSchemes = loadTaxSchemesFromFile(taxNombre, 11);

            PopularityMetrics *pmetrics = playRandomGame(hCABs, taxSchemes, numRounds, argv[3], argv[6], argv[7]);
            GameSummaryMetrics metrics = deriveMetrics(pmetrics, argv[6]);

            int nAgents = 20;
            cout << "Average Popularity: " << metrics.avePop << endl;
            cout << "Average Growth: " << metrics.aveGrowth << endl;
            cout << "Gini Index: " << metrics.giniIndex << endl;
            if (!strcmp(argv[7],"none")) {
                cout << "Government Power: " << pmetrics[0].endPop << endl;
                cout << "Total Power: " << ((metrics.avePop * 20) + pmetrics[0].endPop) << endl;
            }
            cout << "Keep: " << metrics.percKeep << endl;
            cout << "Take: " << metrics.percTake << endl;
            cout << "Give: " << metrics.percGive << endl;
            cout << "Tax paid: " << metrics.percTaxPaid << endl;
            if (strcmp(argv[7],"none")) {
                cout << "GKeep: " << metrics.percGKeep << endl;
                cout << "GTake: " << metrics.percGTake << endl;
                cout << "GGive: " << metrics.percGGive << endl;
            }
            
            ofstream log("../Results/resultsLog.csv", ios::app);
            if (!strcmp(argv[7],"none"))
                log << argv[7] << "," << argv[6] << "," << argv[3] << "," << argv[4] << "," << argv[5] << "," << metrics.avePop << "," << metrics.giniIndex << ",NaN," << (metrics.avePop * nAgents) << "," << metrics.percKeep << "," << metrics.percTake << "," << metrics.percGive << "," << metrics.percTaxPaid << ",NaN,NaN,NaN" << endl;
            else
                log << argv[7] << "," << argv[6] << "," << argv[3] << "," << argv[4] << "," << argv[5] << "," << metrics.avePop << "," << metrics.giniIndex << "," << pmetrics[0].endPop << "," << ((metrics.avePop * nAgents) + pmetrics[0].endPop) << "," << metrics.percKeep << "," << metrics.percTake << "," << metrics.percGive << "," << metrics.percTaxPaid << "," << metrics.percGKeep << "," << metrics.percGTake << "," << metrics.percGGive << endl;

            log.close();

            // ofstream log2("../Results/resultsLog_scale.csv", ios::app);

            // if (!strcmp(argv[7],"none")) {
            //     for (int i = 0; i < 20; i++) {
            //         log2 << argv[7] << ",p" << i << "," << pmetrics[i].endPop << endl;
            //     }
            // }
            // else {
            //     for (int i = 0; i < 20; i++) {
            //         log2 << argv[7] << ",p" << i << "," << pmetrics[i+1].endPop << endl;
            //     }
            // }

            // log2.close();

            for (int i = 0; i < 100; i++)
                delete hCABs[i];
            delete[] hCABs;

            for (int i = 0; i < 11; i++)
                delete taxSchemes[i];
            delete[] taxSchemes;

            delete[] pmetrics;
        }
    }
    else if (!strcmp(argv[1], "tune")) {
        if (argc != 9) {
            printf("wrong number of parameters to specify how to *tune*: %i\n", argc);
            return -1;
        }

        cout << "tuning" << endl;

        int numRounds = atoi(argv[2]);
        int numGames = atoi(argv[8]);

        // read in the raw hCABs and tax payment schemes
        CABAgent **hCABs = loadPopulationFromFile("../Tuning/hcabs_raw.csv", 100, 1);
        TaxScheme **taxSchemes = loadTaxSchemesFromFile("../Tuning/taxpay_raw.csv", 11);

        for (int i = 0; i < numGames; i++) {
            cout << "\ngame " << i << endl;
            PopularityMetrics *pmetrics = playRandomGame(hCABs, taxSchemes, numRounds, argv[3], argv[6], argv[7]);
            delete[] pmetrics;
        }

        string argv4(argv[4]), argv5(argv[5]);
        ofstream output("../Tuning/" + argv5 + ".csv");
        for (int i = 0; i < 11; i++) {
            output << i*10 << "," << taxSchemes[i]->count << "," << taxSchemes[i]->increase << "," << taxSchemes[i]->increase << endl;
        }
        output.close();

        ofstream output2("../Tuning/" + argv4 + ".csv");
        for (int i = 0; i < 100; i++) {
            output2 << hCABs[i]->whoami << "," << hCABs[i]->count << "," << hCABs[i]->scaledFitness << "," << hCABs[i]->scaledFitness << endl;
        }
        output2.close();

        for (int i = 0; i < 100; i++)
            delete hCABs[i];
        delete[] hCABs;

        for (int i = 0; i < 11; i++)
            delete taxSchemes[i];
        delete[] taxSchemes;
    }
    else if (!strcmp(argv[1], "evolve")) {
        if (argc != 6) {
            cout << "Wrong number of parameters for evolve" << endl;
            exit(1);
        }

        // [sizeGenePool] [numGens] [gamesPerGov] [scenario_config]
        int poolSize = atoi(argv[2]);
        int numGens = atoi(argv[3]);
        int gamesPerGov = atoi(argv[4]);

        // read in the scenario_config
        string configFile(argv[5]);
        string fnombre = "ScenarioConfigs/" + configFile + ".txt";
        string line, initPops, players, objectivo;
        ifstream input(fnombre);
        getline(input, line);
        int numRounds = stoi(line);
        getline(input, initPops);
        getline(input, players);
        getline(input, objectivo);
        input.close();

        cout << "numRounds: " << numRounds << endl;
        cout << "initPops file: " << initPops << endl;
        cout << "player file: " << players << endl;
        cout << "objectivo: " << objectivo << endl;

        // set up the gene pool
        vector<GovTracker *> theGovs;
        for (int i = 0; i < poolSize; i++) {
            theGovs.push_back(new GovTracker(8));
        }

        // initialize the hCABs, etc.
        CABAgent **hCABs = loadPopulationFromFile("../Tuning/hcabs_raw.csv", 100, 1);
        TaxScheme **taxSchemes = loadTaxSchemesFromFile("../Tuning/taxpay_raw.csv", 11);

        // vector<PerfLog> recordCABs, recordCABs2;
        // for (int i = 0; i < 100; i++) {
        //     PerfLog tmp;
        //     tmp.count = 1;
        //     tmp.score = 2.0;
        //     recordCABs.push_back(tmp);
        //     tmp.count = 0;
        //     tmp.score = 0.0;
        //     recordCABs2.push_back(tmp);
        // }
        // vector<PerfLog> recordTax, recordTax2;
        // for (int i = 0; i < 11; i++) {
        //     PerfLog tmp;
        //     tmp.count = 1;
        //     tmp.score = 2.0;
        //     recordTax.push_back(tmp);
        //     tmp.count = 0;
        //     tmp.score = 0.0;
        //     recordTax2.push_back(tmp);
        // }

        // cout << "taxScheme check:" << endl;
        // for (int k = 0; k < 11; k++)
        //     cout << "   " << (k*10) << "," << recordTax[k].score << endl;
        // cout << endl;

        int numTuningGames = 100;

        for (int gen = 0; gen < numGens; gen++) {
            cout << "\n\nGeneration " << gen << endl;

            ofstream genOutput("../Results/theGenerations/gen_" + to_string(gen) + ".csv");
            for (int i = 0; i < theGovs.size(); i++) {
                cout << "Gov " << i << endl;
                theGovs[i]->write2File();
                
                // tune hCABs to current gov (50 rounds)
                // cout << "tuning the hCABs" << endl;
                    
                // load in the base values for the hcabs and tax payment schemes
                for (int j = 0; j < 100; j++) {
                    hCABs[j]->count = 1;//recordCABs[j].count;
                    hCABs[j]->scaledFitness = 2.0; //recordCABs[j].score;
                }
                for (int j = 0; j < 11; j++) {
                    taxSchemes[j]->count = 1; //recordTax[j].count;
                    taxSchemes[j]->increase = 2.0; //recordTax[j].score;
                }

                for (int g = 0; g < numTuningGames; g++) {
                    // cout << "\ntuning game " << g << endl;
                    PopularityMetrics *pmetrics = playRandomGame(hCABs, taxSchemes, numRounds, initPops, players, "inevolution");
                    delete[] pmetrics;
                }

                // update
                // for (int j = 0; j < 100; j++) {
                //     recordCABs2[j].count += hCABs[j]->count;
                //     recordCABs2[j].score += hCABs[j]->scaledFitness / poolSize;
                // }

                // for (int j = 0; j < 11; j++) {
                //     recordTax2[j].count += taxSchemes[j]->count;
                //     recordTax2[j].score += taxSchemes[j]->increase / poolSize;
                // }

                // cout << "taxScheme comparison check:" << endl;
                // for (int k = 0; k < 11; k++)
                //     cout << "   " << taxSchemes[k]->percentPay << "," << taxSchemes[k]->increase << " vs (" << recordTax2[k].score << ")" << endl;
                // cout << endl;

                // now, score gov over gamePerGov games -> fitness based on the supplied objective function
                int numero = gamesPerGov;
                if (gen == numGens-1)
                    numero *= 4;
                for (int g = 0; g < numero; g++) {
                    // cout << "\ntest game " << g << endl;
                    PopularityMetrics *pmetrics = playRandomGame(hCABs, taxSchemes, numRounds, initPops, players, "inevolution", false);
                    GameSummaryMetrics metrics = deriveMetrics(pmetrics, players);

                    double score = scoreSociety(metrics, objectivo);

                    // double sw = metrics.avePop / 500.0;
                    // double gini = (0.5 - metrics.giniIndex) / 0.5;
                    // if (gini < 0.0)
                    //     gini = 0.0;

                    // double score = (sw * sw) + (gini * gini);
                    // cout << "SW: " << metrics.avePop << "; " << "GiniIndex: " << metrics.giniIndex << " = " << score << endl;

                    theGovs[i]->fitness += score;

                    delete[] pmetrics;
                }

                genOutput << theGovs[i]->toString() << "," << theGovs[i]->fitness << endl;
            }
            genOutput.close();

            // evolve the govment gene pool
            vector<GovTracker *> theNewGovs = evolveGovs(theGovs);
            // delete the old govs and copy in the new govs
            for (int i = 0; i < theGovs.size(); i++) {
                delete theGovs[i];
                theGovs[i] = theNewGovs[i];
            }

            // check to see if it is learning
            // cout << "taxScheme check:" << endl;
            // for (int k = 0; k < 11; k++)
            //     cout << "   " << taxSchemes[k]->percentPay << "," << recordTax2[k].score << endl;
            // cout << endl;
            // for (int k = 0; k < 100; k++) {
            //     recordCABs[k].count = 5;
            //     recordCABs[k].score = recordCABs2[k].score;
            //     recordCABs2[k].count = 0;
            //     recordCABs2[k].score = 0.0;
            // }

            // for (int k = 0; k < 11; k++) {
            //     recordTax[k].count = 5;
            //     recordTax[k].score = recordTax2[k].score;
            //     recordTax2[k].count = 0;
            //     recordTax2[k].score = 0.0;
            // }
        }

        for (int i = 0; i < 100; i++)
            delete hCABs[i];
        delete[] hCABs;

        for (int i = 0; i < 11; i++)
            delete taxSchemes[i];
        delete[] taxSchemes;

        for (int i = 0; i < theGovs.size(); i++)
            delete theGovs[i];
        
        return 0;
    }
    else if (!strcmp(argv[1], "tune3")) {
        if (argc != 7) {
            printf("wrong number of parameters to specify how to *tune*: %i\n", argc);
            return -1;
        }

        int numRounds = atoi(argv[2]);
        int numGames = atoi(argv[6]);

        // read in the raw hCABs and tax payment schemes
        CABAgent **poorhCABs = loadPopulationFromFile("../Tuning/hcabs_raw.csv", 100, 1);
        CABAgent **middlehCABs = loadPopulationFromFile("../Tuning/hcabs_raw.csv", 100, 1);
        CABAgent **richhCABs = loadPopulationFromFile("../Tuning/hcabs_raw.csv", 100, 1);

        for (int i = 0; i < 100; i++) {
            // 30 for longer (80 round) games
            // poorhCABs[i]->scaledFitness = middlehCABs[i]->scaledFitness = richhCABs[i]->scaledFitness = 30.0;

            // 2 for shorter (30 round) games
            poorhCABs[i]->scaledFitness = middlehCABs[i]->scaledFitness = richhCABs[i]->scaledFitness = 2.0;
        }

        for (int i = 0; i < numGames; i++) {
            cout << "\ngame " << i << endl;
            playRandomGame_choice(poorhCABs, middlehCABs, richhCABs, NULL, numRounds, argv[3], argv[5], "none");
            delete[] globalPmetrics;
        }

        string argv4(argv[4]);
        ofstream output2("../Tuning/" + argv4 + "_poor.csv");
        for (int i = 0; i < 100; i++) {
            output2 << poorhCABs[i]->whoami << "," << poorhCABs[i]->count << "," << poorhCABs[i]->scaledFitness << endl;
        }
        output2.close();

        ofstream output3("../Tuning/" + argv4 + "_middle.csv");
        for (int i = 0; i < 100; i++) {
            output3 << middlehCABs[i]->whoami << "," << middlehCABs[i]->count << "," << middlehCABs[i]->scaledFitness << endl;
        }
        output3.close();

        ofstream output4("../Tuning/" + argv4 + "_rich.csv");
        for (int i = 0; i < 100; i++) {
            output4 << richhCABs[i]->whoami << "," << richhCABs[i]->count << "," << richhCABs[i]->scaledFitness << endl;
        }
        output4.close();

        for (int i = 0; i < 100; i++)
            delete poorhCABs[i];
        delete[] poorhCABs;

        for (int i = 0; i < 100; i++)
            delete middlehCABs[i];
        delete[] middlehCABs;

        for (int i = 0; i < 100; i++)
            delete richhCABs[i];
        delete[] richhCABs;
    }
    else if (!strcmp(argv[1], "play3")) {
        if (argc != 7) {
            printf("wrong number of parameters to specify how to *tune*: %i\n", argc);
            return -1;
        }

        int numRounds = atoi(argv[2]);
        int numGames = atoi(argv[6]);

        // read in the hCABs
        string argv4(argv[4]);
        CABAgent **poorhCABs = loadPopulationFromFile("../Tuning/" + argv4 + "_poor.csv", 100, 1);
        CABAgent **middlehCABs = loadPopulationFromFile("../Tuning/" + argv4 + "_middle.csv", 100, 1);
        CABAgent **richhCABs = loadPopulationFromFile("../Tuning/" + argv4 + "_rich.csv", 100, 1);
        
        for (int g = 0; g < numGames; g++) {
            cout << "\ngame " << g << endl;

            // Randomly choose who joins the coop and who doesn't (write to coopAssignments)
            // randomizeCoopMembership(20);

            CoopGameMetrics cgm = playRandomGame_choice(poorhCABs, middlehCABs, richhCABs, NULL, numRounds, argv[3], argv[5], "none");

            ofstream log("../Results/coopLog.csv", ios::app);
            if (!log) {
                cout << "csv not found" << endl;
                exit(1);
            }
            log << "none,none," << argv[4];

            // record player stuff
            for (int i = 0; i < 20; i++) {
                double total = cgm.plyrKeep[i] + cgm.plyrTake[i] + cgm.plyrGive[i];
                log << "," << cgm.endPop[i] << "," << cgm.coopChoice[i] << "," << (cgm.plyrKeep[i] / total) << "," << (cgm.plyrTake[i] / total) << "," << (cgm.plyrGive[i] / total);
            }
    
            // record coop stuff
            if (cgm.coop1EndPop >= 0.0) {
                double t1 = cgm.coop1Keep + cgm.coop1Take + cgm.coop1Give;
                log << "," << cgm.coop1EndPop << "," << cgm.coop1AvePop << "," << (cgm.coop1Keep / t1) << "," << (cgm.coop1Take / t1) << "," << (cgm.coop1Give / t1);
            }
            else {
                log << ",NA,NA,NA,NA,NA";
            }
            
            if (cgm.coop2EndPop >= 0.0) {
                double t2 = cgm.coop2Keep + cgm.coop2Take + cgm.coop2Give;
                log << "," << cgm.coop2EndPop << "," << cgm.coop2AvePop << "," << (cgm.coop2Keep / t2) << "," << (cgm.coop2Take / t2) << "," << (cgm.coop2Give / t2);
            }
            else {
                log << ",NA,NA,NA,NA,NA";
            }

            log << endl;
    
            log.close();
            
            string cmd("mv ../Results/theGameLogs/log_1000_1000.csv ../Results/theGameLogs/game" + to_string(g) + ".txt");
            system(cmd.c_str());

            // ./jhginst play3 [numRounds] [initialPops] [hcabs] [player_config] [numGames]
            GameSummaryMetrics metrics = deriveMetrics(globalPmetrics, argv[5]);
            ofstream log2("../Results/resultsLog.csv", ios::app);
            log2 << "none," << argv[5] << "," << argv[3] << "," << argv[4] << "," << metrics.avePop << "," << metrics.giniIndex << ",NaN," << (metrics.avePop * 20) << "," << metrics.percKeep << "," << metrics.percTake << "," << metrics.percGive << "," << metrics.percTaxPaid << ",NaN,NaN,NaN" << endl;
            log2.close();

            // ofstream log3("../Results/resultsLog_scale.csv", ios::app);
            
            // for (int i = 0; i < 20; i++) {
            //     log3 << "none,p" << i << "," << globalPmetrics[i].endPop << endl;
            // }

            // log3.close();

            ofstream log4("../Results/gini_growth.csv", ios::app);

        

            log4 << computeInitialGini(argv[3]) << "," << metrics.giniIndex << "," << metrics.avePop << endl;

            log4.close();

            delete[] globalPmetrics;
        }

        for (int i = 0; i < 100; i++)
            delete poorhCABs[i];
        delete[] poorhCABs;

        for (int i = 0; i < 100; i++)
            delete middlehCABs[i];
        delete[] middlehCABs;

        for (int i = 0; i < 100; i++)
            delete richhCABs[i];
        delete[] richhCABs;
    }
    else if (!strcmp(argv[1], "tuneDuelingCoops")) {
        if (argc != 7) {
            printf("wrong number of parameters to specify how to *tune*: %i\n", argc);
            return -1;
        }

        cout << "tuning coop strategies" << endl;

        int numRounds = atoi(argv[2]);
        int numGames = atoi(argv[6]);

        // read in the raw hCABs
        CABAgent **poorhCABs = createStrategicHCABs();
        CABAgent **middlehCABs = createStrategicHCABs();
        CABAgent **richhCABs = createStrategicHCABs();

        for (int i = 0; i < numGames; i++) {
            cout << "\ngame " << i << endl;
            playRandomGame_choice(poorhCABs, middlehCABs, richhCABs, NULL, numRounds, argv[3], argv[5], "none", true, 300, "Coop");
            delete[] globalPmetrics;
        }

        // cout << "print out strategies" << endl;

        string argv4(argv[4]);
        ofstream output2("../TuningConCoops/" + argv4 + "_poor.csv");
        for (int i = 0; i < 300; i++) {
            output2 << poorhCABs[i]->whoami << "," << poorhCABs[i]->myCoop << "," << poorhCABs[i]->count << "," << poorhCABs[i]->scaledFitness << endl;
        }
        output2.close();

        ofstream output3("../TuningConCoops/" + argv4 + "_middle.csv");
        for (int i = 0; i < 300; i++) {
            output3 << middlehCABs[i]->whoami << "," << middlehCABs[i]->myCoop << "," << middlehCABs[i]->count << "," << middlehCABs[i]->scaledFitness << endl;
        }
        output3.close();

        ofstream output4("../TuningConCoops/" + argv4 + "_rich.csv");
        for (int i = 0; i < 300; i++) {
            output4 << richhCABs[i]->whoami << "," << richhCABs[i]->myCoop << "," << richhCABs[i]->count << "," << richhCABs[i]->scaledFitness << endl;
        }
        output4.close();

        for (int i = 0; i < 300; i++)
            delete poorhCABs[i];
        delete[] poorhCABs;
        for (int i = 0; i < 300; i++)
            delete middlehCABs[i];
        delete[] middlehCABs;
        for (int i = 0; i < 300; i++)
            delete richhCABs[i];
        delete[] richhCABs;
    }
    else if (!strcmp(argv[1], "playDuelingCoops")) {
        if (argc != 7) {
            printf("wrong number of parameters to specify how to *play*: %i\n", argc);
            return -1;
        }

        int numRounds = atoi(argv[2]);
        string argv4(argv[4]), argv5(argv[5]);
        string cabNombre = "../TuningConCoops/" + argv4;
        int numGames = atoi(argv[6]);

        // read in the hCABs
        CABAgent** poorhCABs = loadPopulationFromFile_inst(cabNombre, "poor", 300, 1, "Coop");
        CABAgent** middlehCABs = loadPopulationFromFile_inst(cabNombre, "middle", 300, 1, "Coop");
        CABAgent** richhCABs = loadPopulationFromFile_inst(cabNombre, "rich", 300, 1, "Coop");
        
        for (int g = 0; g < numGames; g++) {
            cout << "game: " << g << endl;

            CoopGameMetrics cgm = playRandomGame_choice(poorhCABs, middlehCABs, richhCABs, NULL, numRounds, argv[3], argv[5], "none", true, 300, "Coop");
            delete[] globalPmetrics;

            ofstream log("../Results/coopLog.csv", ios::app);
            if (!log) {
                cout << "csv not found" << endl;
                exit(1);
            }
            log << "cp1,cp2," << argv[4];

            // record player stuff
            for (int i = 0; i < 20; i++) {
                double total = cgm.plyrKeep[i] + cgm.plyrTake[i] + cgm.plyrGive[i];
                log << "," << cgm.endPop[i] << "," << cgm.coopChoice[i] << "," << (cgm.plyrKeep[i] / total) << "," << (cgm.plyrTake[i] / total) << "," << (cgm.plyrGive[i] / total);
            }
    
            // record coop stuff
            if (cgm.coop1EndPop >= 0.0) {
                double t1 = cgm.coop1Keep + cgm.coop1Take + cgm.coop1Give;
                log << "," << cgm.coop1EndPop << "," << cgm.coop1AvePop << "," << (cgm.coop1Keep / t1) << "," << (cgm.coop1Take / t1) << "," << (cgm.coop1Give / t1);
            }
            else {
                log << ",NA,NA,NA,NA,NA";
            }
            
            if (cgm.coop2EndPop >= 0.0) {
                double t2 = cgm.coop2Keep + cgm.coop2Take + cgm.coop2Give;
                log << "," << cgm.coop2EndPop << "," << cgm.coop2AvePop << "," << (cgm.coop2Keep / t2) << "," << (cgm.coop2Take / t2) << "," << (cgm.coop2Give / t2);
            }
            else {
                log << ",NA,NA,NA,NA,NA";
            }

            log << endl;
    
            log.close();    

            string cmd("mv ../Results/theGameLogs/log_1000_1000.csv ../Results/theGameLogs/game" + to_string(g) + ".txt");
            system(cmd.c_str());
        }

        for (int i = 0; i < 300; i++)
            delete poorhCABs[i];
        delete[] poorhCABs;

        for (int i = 0; i < 300; i++)
            delete middlehCABs[i];
        delete[] middlehCABs;

        for (int i = 0; i < 300; i++)
            delete richhCABs[i];
        delete[] richhCABs;
    }
    else if (!strcmp(argv[1], "tuneGov")) {
        if (argc != 8) {
            printf("wrong number of parameters to specify how to *tune*: %i\n", argc);
            return -1;
        }

        cout << "tuning coop strategies" << endl;

        int numRounds = atoi(argv[2]);
        int numGames = atoi(argv[7]);

        // read in the raw hCABs
        CABAgent **poorhCABs = createGovHCABs();
        CABAgent **middlehCABs = createGovHCABs();
        CABAgent **richhCABs = createGovHCABs();

        for (int i = 0; i < numGames; i++) {
            cout << "\ngame " << i << endl;
            playRandomGame_choice(poorhCABs, middlehCABs, richhCABs, NULL, numRounds, argv[3], argv[5], argv[6], true, 200, "Gov");
            delete[] globalPmetrics;
            // cout << "never return" << endl;
        }

        // cout << "print out strategies" << endl;

        string argv4(argv[4]);
        ofstream output2("../TuningConGov/" + argv4 + "_poor.csv");
        for (int i = 0; i < 200; i++) {
            output2 << poorhCABs[i]->whoami << "," << (poorhCABs[i]->payTaxes / 100) << "," << poorhCABs[i]->count << "," << poorhCABs[i]->scaledFitness << endl;
        }
        output2.close();

        ofstream output3("../TuningConGov/" + argv4 + "_middle.csv");
        for (int i = 0; i < 200; i++) {
            output3 << middlehCABs[i]->whoami << "," << (middlehCABs[i]->payTaxes / 100) << "," << middlehCABs[i]->count << "," << middlehCABs[i]->scaledFitness << endl;
        }
        output3.close();

        ofstream output4("../TuningConGov/" + argv4 + "_rich.csv");
        for (int i = 0; i < 200; i++) {
            output4 << richhCABs[i]->whoami << "," << (richhCABs[i]->payTaxes / 100) << "," << richhCABs[i]->count << "," << richhCABs[i]->scaledFitness << endl;
        }
        output4.close();

        for (int i = 0; i < 200; i++)
            delete poorhCABs[i];
        delete[] poorhCABs;
        for (int i = 0; i < 200; i++)
            delete middlehCABs[i];
        delete[] middlehCABs;
        for (int i = 0; i < 200; i++)
            delete richhCABs[i];
        delete[] richhCABs;
    }
    else if (!strcmp(argv[1], "playGov")) {
        if (argc != 8) {
            printf("wrong number of parameters to specify how to *play*: %i\n", argc);
            return -1;
        }

        int numRounds = atoi(argv[2]);
        string argv4(argv[4]), argv5(argv[5]);
        string cabNombre = "../TuningConGov/" + argv4;
        int numGames = atoi(argv[7]);

        // read in the hCABs
        CABAgent** poorhCABs = loadPopulationFromFile_inst(cabNombre, "poor", 200, 1, "Gov");
        CABAgent** middlehCABs = loadPopulationFromFile_inst(cabNombre, "middle", 200, 1, "Gov");
        CABAgent** richhCABs = loadPopulationFromFile_inst(cabNombre, "rich", 200, 1, "Gov");

        for (int g = 0; g < numGames; g++) {
            cout << "game: " << g << endl;

            CoopGameMetrics cgm = playRandomGame_choice(poorhCABs, middlehCABs, richhCABs, NULL, numRounds, argv[3], argv[5], argv[6], true, 200, "Gov");
            
            // ./jhginst playGov [numRounds] [initialPops] [hcabs] [player_config] [govment] [numGames]
            // Government,Players,InitPops,hcabs,AvePop,GiniIndex,GovWealth,TotalWealth,Keep,Take,Give,percTaxes,GKeep,GTake,GGive
            GameSummaryMetrics metrics = deriveMetrics(globalPmetrics, argv[5]);
            ofstream log2("../Results/resultsLog.csv", ios::app);
            log2 << argv[6] << "," << argv[5] << "," << argv[3] << "," << argv[4] << "," << metrics.avePop << "," << metrics.giniIndex << "," << globalPmetrics[0].endPop << "," << ((metrics.avePop * 20) + globalPmetrics[0].endPop) << "," << metrics.percKeep << "," << metrics.percTake << "," << metrics.percGive << "," << metrics.percTaxPaid  << "," << metrics.percGKeep << "," << metrics.percGTake << "," << metrics.percGGive << endl;
            log2.close();

            // ofstream log3("../Results/resultsLog_scale.csv", ios::app);
            
            // for (int i = 0; i < 20; i++) {
            //     log3 << "Balanced priorities,p" << i << "," << globalPmetrics[i+1].endPop << endl;
            // }

            // log3.close();

            delete[] globalPmetrics;

            string cmd("mv ../Results/theGameLogs/log_1000_1000.csv ../Results/theGameLogs/game" + to_string(g) + ".txt");
            system(cmd.c_str());

            // int nAgents = 20;
            // cout << "Average Popularity: " << metrics.avePop << endl;
            // cout << "Average Growth: " << metrics.aveGrowth << endl;
            // cout << "Gini Index: " << metrics.giniIndex << endl;
            // if (!strcmp(argv[7],"none")) {
            //     cout << "Government Power: " << globalPmetrics[0].endPop << endl;
            //     cout << "Total Power: " << ((metrics.avePop * 20) + globalPmetrics[0].endPop) << endl;
            // }
            // cout << "Keep: " << metrics.percKeep << endl;
            // cout << "Take: " << metrics.percTake << endl;
            // cout << "Give: " << metrics.percGive << endl;
            // cout << "Tax paid: " << metrics.percTaxPaid << endl;
            // if (strcmp(argv[7],"none")) {
            //     cout << "GKeep: " << metrics.percGKeep << endl;
            //     cout << "GTake: " << metrics.percGTake << endl;
            //     cout << "GGive: " << metrics.percGGive << endl;
            // }

            // ofstream log("../Results/coopLog.csv", ios::app);
            // if (!log) {
            //     cout << "csv not found" << endl;
            //     exit(1);
            // }
            // log << "cp1,cp2," << argv[4];

            // // record player stuff
            // for (int i = 0; i < 20; i++) {
            //     double total = cgm.plyrKeep[i] + cgm.plyrTake[i] + cgm.plyrGive[i];
            //     log << "," << cgm.endPop[i] << "," << cgm.coopChoice[i] << "," << (cgm.plyrKeep[i] / total) << "," << (cgm.plyrTake[i] / total) << "," << (cgm.plyrGive[i] / total);
            // }
    
            // // record coop stuff
            // if (cgm.coop1EndPop >= 0.0) {
            //     double t1 = cgm.coop1Keep + cgm.coop1Take + cgm.coop1Give;
            //     log << "," << cgm.coop1EndPop << "," << cgm.coop1AvePop << "," << (cgm.coop1Keep / t1) << "," << (cgm.coop1Take / t1) << "," << (cgm.coop1Give / t1);
            // }
            // else {
            //     log << ",NA,NA,NA,NA,NA";
            // }
            
            // if (cgm.coop2EndPop >= 0.0) {
            //     double t2 = cgm.coop2Keep + cgm.coop2Take + cgm.coop2Give;
            //     log << "," << cgm.coop2EndPop << "," << cgm.coop2AvePop << "," << (cgm.coop2Keep / t2) << "," << (cgm.coop2Take / t2) << "," << (cgm.coop2Give / t2);
            // }
            // else {
            //     log << ",NA,NA,NA,NA,NA";
            // }

            // log << endl;
    
            // log.close();    

            // string cmd("mv ../Results/theGameLogs/log_1000_1000.csv ../Results/theGameLogs/game" + to_string(g) + ".txt");
            // system(cmd.c_str());
        }

        for (int i = 0; i < 200; i++)
            delete poorhCABs[i];
        delete[] poorhCABs;

        for (int i = 0; i < 200; i++)
            delete middlehCABs[i];
        delete[] middlehCABs;

        for (int i = 0; i < 200; i++)
            delete richhCABs[i];
        delete[] richhCABs;
    }
    else if (!strcmp(argv[1], "evolveGov")) {
        if (argc != 6) {
            cout << "Wrong number of parameters for evolveGov" << endl;
            exit(1);
        }

        // [sizeGenePool] [numGens] [gamesPerGov] [scenario_config]
        int poolSize = atoi(argv[2]);
        int numGens = atoi(argv[3]);
        int gamesPerGov = atoi(argv[4]);

        // read in the scenario_config
        string configFile(argv[5]);
        string fnombre = "ScenarioConfigs/" + configFile + ".txt";
        string line, initPops, players, objectivo;
        ifstream input(fnombre);
        getline(input, line);
        int numRounds = stoi(line);
        getline(input, initPops);
        getline(input, players);
        getline(input, objectivo);
        input.close();

        cout << "numRounds: " << numRounds << endl;
        cout << "initPops file: " << initPops << endl;
        cout << "player file: " << players << endl;
        cout << "objectivo: " << objectivo << endl;

        // set up the gene pool
        vector<GovTracker *> theGovs;
        for (int i = 0; i < poolSize; i++) {
            theGovs.push_back(new GovTracker(8));
        }

        // initialize the hCABs
        string cabNombre = "../TuningConGov/hcabs_test";
        CABAgent** poorhCABs = loadPopulationFromFile_inst(cabNombre, "poor", 200, 1, "Gov");
        CABAgent** middlehCABs = loadPopulationFromFile_inst(cabNombre, "middle", 200, 1, "Gov");
        CABAgent** richhCABs = loadPopulationFromFile_inst(cabNombre, "rich", 200, 1, "Gov");

        int numTuningGames = 100;
        // cout << configFile.substr(0,3) << endl;
        if (configFile.substr(0,3) == "exp") {
            numTuningGames = 600;
        }

        for (int gen = 0; gen < numGens; gen++) {
            cout << "\n\nGeneration " << gen << endl;

            ofstream genOutput("../Results/theGenerations/gen_" + to_string(gen) + ".csv");
            for (int i = 0; i < theGovs.size(); i++) {
                cout << "Gov " << i << endl;
                theGovs[i]->write2File();
                
                // tune hCABs to current gov
                // cout << "tuning the hCABs" << endl;
                    
                // load in the base values for the hcabs and tax payment schemes
                for (int j = 0; j < 200; j++) {
                    poorhCABs[j]->count = middlehCABs[j]->count = richhCABs[j]->count = 1;
                    poorhCABs[j]->scaledFitness = middlehCABs[j]->scaledFitness = richhCABs[j]->scaledFitness = 2.0;
                }

                for (int g = 0; g < numTuningGames; g++) {
                    cout << "tuning game " << g << endl;
                    // playRandomGame(hCABs, taxSchemes, numRounds, initPops, players, "inevolution");
                    playRandomGame_choice(poorhCABs, middlehCABs, richhCABs, NULL, numRounds, initPops, players, "inevolution", true, 200, "Gov");
                    // cout << "a" << endl;
                    delete[] globalPmetrics;
                    // cout << "b" << endl; 
                }

                // now, score gov over gamePerGov games -> fitness based on the supplied objective function
                int numero = gamesPerGov;
                if (gen == numGens-1)
                    numero *= 4;
                for (int g = 0; g < numero; g++) {
                    // cout << "\ntest game " << g << endl;
                    // PopularityMetrics *pmetrics = playRandomGame(hCABs, taxSchemes, numRounds, initPops, players, "inevolution", false);
                    playRandomGame_choice(poorhCABs, middlehCABs, richhCABs, NULL, numRounds, initPops, players, "inevolution", false, 200, "Gov");
                    GameSummaryMetrics metrics = deriveMetrics(globalPmetrics, players);

                    double score = scoreSociety(metrics, objectivo);

                    // double sw = metrics.avePop / 500.0;
                    // double gini = (0.5 - metrics.giniIndex) / 0.5;
                    // if (gini < 0.0)
                    //     gini = 0.0;

                    // double score = (sw * sw) + (gini * gini);
                    // cout << "SW: " << metrics.avePop << "; " << "GiniIndex: " << metrics.giniIndex << " = " << score << endl;

                    theGovs[i]->fitness += score;

                    delete[] globalPmetrics;
                }

                genOutput << theGovs[i]->toString() << "," << theGovs[i]->fitness << endl;
            }
            genOutput.close();

            // evolve the govment gene pool
            vector<GovTracker *> theNewGovs = evolveGovs(theGovs);
            // delete the old govs and copy in the new govs
            for (int i = 0; i < theGovs.size(); i++) {
                delete theGovs[i];
                theGovs[i] = theNewGovs[i];
            }
        }

        for (int i = 0; i < 200; i++) {
            delete poorhCABs[i];
            delete middlehCABs[i];
            delete richhCABs[i];
        }
        delete[] poorhCABs;
        delete[] middlehCABs;
        delete[] richhCABs;

        for (int i = 0; i < theGovs.size(); i++)
            delete theGovs[i];
        
        return 0;
    }
    else {
        cout << "command " << argv[1] << " not found" << endl;
    }

    ofstream cmdLog("../Results/cmdLog.csv", ios::app);
    for (int i = 0; i < argc; i++)
        cmdLog << argv[i] << " ";
    cmdLog << endl;
    cmdLog.close();

    return 0;
}