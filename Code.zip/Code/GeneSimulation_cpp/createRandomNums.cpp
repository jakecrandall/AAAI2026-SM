#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char *argv[]) {
    ofstream output("../State/rnums.txt");
    for (int i = 0; i < 10000; i++) {
        output << rand() % 1001 << endl;
    }

    output.close();

    return 0;
}