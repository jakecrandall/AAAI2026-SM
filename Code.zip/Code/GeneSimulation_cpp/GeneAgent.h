#ifndef GENEAGENT_H
#define GENEAGENT_H

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <sstream>
#include <fstream>

#include <chrono>

#include "defs.h"
#include "AbstractAgent.h"

using namespace std;

class GeneAgent : public AbstractAgent {
public:
    GeneAgent() {}
    // ~GeneAgent() {}
    virtual ~GeneAgent() {}

    int count;
    double scaledFitness;
    string thisGeneStr;

    int *myGenes, numGenes;
    bool playedGenes;

    void playRound(int numPlayers, int numTokens, int playerIdx, int roundNum, double *received, double *popularities, double **influence, int *allocations) = 0;

    void postContract(int playerIdx) = 0;

    virtual string getString() = 0;
};

#endif