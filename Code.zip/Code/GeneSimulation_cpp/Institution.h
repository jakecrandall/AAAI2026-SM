#ifndef INSTITUTION_H
#define INSTITUTION_H

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <sstream>
#include <fstream>

#include "AbstractAgent.h"

using namespace std;

struct aCurve {
    double first[2], second[2];
};

class Institution : public AbstractAgent {
public:
    double poder, stealCrimeThreshold_percent, punishmentStrength;
    bool punishTaxEvasion, punishStealing, remunerateVictims;
    string membershipType, taxCurve, redistributionCurve;

    bool verbose;

    Institution() {
        cout << "default CoOpAgent constructor" << endl;
        exit(1);
    }

    Institution(string _fnombre) {
        string fnombre = "Institutions/" + _fnombre + ".txt";
        readInstSpecs(fnombre);
        whoami = _fnombre;

        setCurves();

        isInitialized = false;

        verbose = false;
    }

    ~Institution() {
        if (isInitialized) {
            delete[] prevPopularities;
            delete[] prev2Popularities;
            for (int i = 0; i < nPlayers; i++) {
                delete[] prevInfluence[i];
            }
            delete[] prevInfluence;
        }
    }

    void playRound(int numPlayers, int numTokens, int playerIdx, int roundNum, double *received, double *popularities, double **influence, int *allocations) {
        if (verbose)
            cout << endl << "Round: " << roundNum << endl << endl;

        // initialize token allocations to 0
        for (int i = 0; i < numPlayers; i++)
            allocations[i] = 0;

        computePopularityShares(numPlayers, playerIdx, popularities);

        if (roundNum == 0) {
            initVars(numPlayers, playerIdx, popularities);
        }
        else {            
            // update punishment values based on degree to which attacks were successful
            updatePunishmentValues(numPlayers, playerIdx, popularities, influence);

            // investigate tax payments
            investigateTaxPayments(numPlayers, playerIdx, numTokens, received);

            // investigate theft
            investigateTheft(numPlayers, playerIdx, numTokens, roundNum, popularities, influence);
        }

        allocateTokens(numPlayers, numTokens, playerIdx, roundNum, popularities, received, influence, allocations);

        // // update some variables
        for (int i = 0; i < numPlayers; i++) {
            prevPopularities[i] = popularities[i];
            prev2Popularities[i] = prevPopularities[i];
            for (int j = 0; j < numPlayers; j++) {
                prevInfluence[i][j] = influence[i][j];
            }
        }

        broadcastNextTaxes(numPlayers, playerIdx, numTokens, popularities);

        if (verbose) {
            cout << "allocations: ";
            for (int p = 0; p < numPlayers; p++)
                cout << allocations[p] << " ";
            cout << endl;
        }
    }

    void postContract(int playerIdx) {
        string fnombre = "Contracts/contract_" + to_string(playerIdx) + ".txt";
        ofstream output(fnombre);

        output << "Membership:" << membershipType << endl;
        output << "Tax:" << taxCurve << endl;
        output << "Redistribution:" << redistributionCurve << endl;
        output << "Power:" << poder << endl;
        output << "PunishTaxEvasion:" << punishTaxEvasion << endl;
        output << "PunishStealing:" << punishStealing << endl;
        output << "RemunerateVictims:" << remunerateVictims << endl;
        output << "StealCrimeThreshold_percent:" << stealCrimeThreshold_percent << endl;
        output << "PunishmentStrength:" << punishmentStrength << endl;

        output.close();
    }

private:
    aCurve taxIndex, redistributionIndex;

    vector<double> taxesOwed, taxOverpay, remunerateList, stealer, gotLess, popularityShareAtSteal, meritTaxTotal, meritTaxPaid;
    vector<bool> punishableList;

    vector<double> popularityShares, prevPopularityShares, taxRates, trueTaxes, reimbursementRates;

    double **prevInfluence, *prevPopularities, *prev2Popularities;
    bool isInitialized;
    int nPlayers;
    double attackPower;

    vector<string> parse(const string& s, char delim = ' ') {
        vector<string> tokens;
        string token;
        istringstream tokenStream(s);
        while (getline(tokenStream, token, delim))
            tokens.push_back(token);
        return tokens;
    }

    void readInstSpecs(string fnombre) {
        ifstream input(fnombre);
        string line;
        vector<string> words;

        while (getline(input, line)) {
            words = parse(line, ':');

            if (words[0] == "Membership")
                membershipType = words[1];
            else if (words[0] == "Tax")
                taxCurve = words[1];
            else if (words[0] == "Redistribution")
                redistributionCurve = words[1];
            else if (words[0] == "Power")
                poder = stof(words[1]);
            else if (words[0] == "PunishTaxEvasion") {
                if (words[1] == "True")
                    punishTaxEvasion = true;
                else
                    punishTaxEvasion = false; 
            }
            else if (words[0] == "PunishStealing") {
                if (words[1] == "True")
                    punishStealing = true;
                else
                    punishStealing = false; 
            }
            else if (words[0] == "RemunerateVictims") {
                if (words[1] == "True")
                    remunerateVictims = true;
                else
                    remunerateVictims = false;
            }
            else if (words[0] == "StealCrimeThreshold_percent")
                stealCrimeThreshold_percent = stof(words[1]);
            else if (words[0] == "PunishmentStrength")
                punishmentStrength = stof(words[1]);
        }

        input.close();
    }

    void setCurves() {
        if (taxCurve == "Progressive") {
            taxIndex.first[0] = 0.0;
            taxIndex.first[1] = 0.0;
            taxIndex.second[0] = 1.0;
            taxIndex.second[1] = 0.25;
        }
        else if (taxCurve == "Regressive") {
            taxIndex.first[0] = 0.0;
            taxIndex.first[1] = 0.25;
            taxIndex.second[0] = 1.0;
            taxIndex.second[1] = 0.0;
        }
        else if (taxCurve == "Flat") {
            taxIndex.first[0] = 0.0;
            taxIndex.first[1] = 0.125;
            taxIndex.second[0] = 1.0;
            taxIndex.second[1] = 0.125;
        }
        else {
            cout << "taxCurve " << taxCurve << " not found" << endl;
            exit(1);
        }

        if (redistributionCurve == "Progressive") {
            redistributionIndex.first[0] = 0.0;
            redistributionIndex.first[1] = 1.0;
            redistributionIndex.second[0] = 1.0;
            redistributionIndex.second[1] = 0.0;
        }
        else if (redistributionCurve == "Regressive") {
            redistributionIndex.first[0] = 0.0;
            redistributionIndex.first[1] = 0.0;
            redistributionIndex.second[0] = 1.0;
            redistributionIndex.second[1] = 1.0;
        }
        else if ((redistributionCurve == "Proportional") || (redistributionCurve == "Merit")) {
            // this isn't actually correct -- fix it later
            redistributionIndex.first[0] = 0.0;
            redistributionIndex.first[1] = 0.5;
            redistributionIndex.second[0] = 1.0;
            redistributionIndex.second[1] = 0.5;
        }
        else {
            cout << "redistributionCurve " << redistributionCurve << " not found" << endl;
            exit(1);
        }
    }

    void initVars(int numPlayers, int playerIdx, double *popularities) {
        if (!isInitialized) {
            prevInfluence = new double*[numPlayers];
            for (int i = 0; i < numPlayers; i++) {
                prevInfluence[i] = new double[numPlayers];
                taxesOwed.push_back(0.0);
                taxOverpay.push_back(0.0);
                remunerateList.push_back(0.0);
                stealer.push_back(0.0);
                gotLess.push_back(0.0);
                popularityShareAtSteal.push_back(-1.0);
                if (i != playerIdx) {
                    punishableList.push_back(true);
                }
                else {
                    punishableList.push_back(false);
                }
                taxRates.push_back(0.0);
                trueTaxes.push_back(0.0);
                reimbursementRates.push_back(0.0);
                meritTaxTotal.push_back(0.0);
                meritTaxPaid.push_back(0.0);
            }
            prevPopularities = new double[numPlayers];
            prev2Popularities = new double[numPlayers];
        }
        for (int i = 0; i < numPlayers; i++) {
            taxesOwed[i] = 0.0;
            taxOverpay[i] = 0.0;
            remunerateList[i] = 0.0;
            stealer[i] = 0.0;
            gotLess[i] = 0.0;
            popularityShareAtSteal[i] = 0.0;
            meritTaxPaid[i] = 0.0;
            meritTaxTotal[i] = 0.0;
            if (i != playerIdx) {
                punishableList[i] = true;
            }
            else {
                punishableList[i] = false;
            }
            prevPopularities[i] = 0.0;
            prev2Popularities[i] = 0.0;
            for (int j = 0; j < numPlayers; j++) {
                prevInfluence[i][j] = 0.0;
            }
        }

        isInitialized = true;
        nPlayers = numPlayers;
        attackPower = 0.0;
    }

    void computePopularityShares(int numPlayers, int playerIdx, double *popularities) {
        if (popularityShares.size() > 0) {
            prevPopularityShares.clear();
            for (int i = 0; i < numPlayers; i++)
                prevPopularityShares.push_back(popularityShares[i]);
        }

        popularityShares.clear();

        double sum = 0.0;
        for (int i = 0; i < numPlayers; i++) {
            sum += popularities[i];
        }

        for (int i = 0; i < numPlayers; i++) {
            popularityShares.push_back(popularities[i] / sum);
        }
    }

    double lookUpTax(double value) {
        return (1.0 - value) * taxIndex.first[1] + value * taxIndex.second[1];
    }

    void broadcastNextTaxes(int numPlayers, int playerIdx, int numTokens, double *popularities) {
        // compute normalized pops
        double theMin = 99999, theMax = -99999;
        for (int i = 0; i < numPlayers; i++) {
            if (i == playerIdx)
                continue;

            if (popularities[i] < theMin)
                theMin = popularities[i];
            if (popularities[i] > theMax)
                theMax = popularities[i];
        }

        double buf = 0.05 * theMax;
        theMax += buf;
        theMin -= buf;

        if (theMin < 0.0)
            theMin = 0.0;

        for (int i = 0; i < numPlayers; i++) {
            if (i == playerIdx)
                taxRates[i] = 0.0;
            else {
                double value = (popularities[i] - theMin) / (theMax - theMin);
                taxRates[i] = lookUpTax(value);
            }
        }

        if (verbose) {
            cout << "initial tax rate: ";
            for (int i = 0; i < numPlayers; i++) {
                cout << taxRates[i] << " ";
            }
            cout << endl;
        }

        // adjust taxRate for poder (raise the right amount of revenue)
        double increment = getIncrement(numPlayers, playerIdx, popularities);
        for (int i = 0; i < numPlayers; i++) {
            if (i == playerIdx)
                continue;

            taxRates[i] += increment;
            if (taxRates[i] < 0.0)
                taxRates[i] = 0.0;
            if (taxRates[i] > 1.0)
                taxRates[i] = 1.0;
        }

        if (verbose) {
            cout << "modified tax rate: ";
            for (int i = 0; i < numPlayers; i++) {
                cout << taxRates[i] << " ";
            }
            cout << endl;
        }

        if (verbose) {
            cout << "projected tax: ";
            for (int i = 0; i < numPlayers; i++) {
                cout << ceil(taxRates[i] * numTokens) << " ";
            }
            cout << endl;
        }

        // deal with overpayments
        for (int i = 0; i < numPlayers; i++) {
            if (i == playerIdx)
                trueTaxes[i] = 0.0;
            else if (ceil(taxRates[i] * numTokens) >= 1) {
                double minus = 0.0;
                if (taxOverpay[i] >= 1.0) {
                    minus = 1.0;
                    taxOverpay[i] -= 1.0;
                    if (verbose)
                        cout << "subtracting off 1 token for " << i << endl;
                }
                trueTaxes[i] = ceil(taxRates[i] * numTokens) - minus;
            }
            else {
                trueTaxes[i] = 0;
            }
        }

        // announce the taxes
        string fnombre = "Contracts/taxes_" + to_string(playerIdx) + ".txt";
        ofstream output(fnombre);

        if (verbose)
            cout << "******* taxes due in next round: ";
        for (int i = 0; i < numPlayers; i++) {
            output << trueTaxes[i] << endl;
            if (verbose)
                cout << trueTaxes[i] << " ";
        }
        if (verbose)
            cout << endl;

        output.close();
    }

    double getIncrement(int numPlayers, int playerIdx, double *popularities) {
        double totalP = 0.0, curRev = 0.0;
        for (int i = 0; i < numPlayers; i++) {
            if (i == playerIdx)
                continue;

            totalP += popularities[i];
            curRev += taxRates[i] * popularities[i];
        }

        double increment = ((poder / 100.0) * totalP - curRev) / totalP;

        if (verbose)
            cout << "taxRate Increment: " << increment << endl;

        return increment;
    }

    void updatePunishmentValues(int numPlayers, int playerIdx, double *popularities, double **influence) {
        for (int i = 0; i < numPlayers; i++) {
            if (i == playerIdx)
                continue;

            if (popularities[i] <= 5.0)
                punishableList[i] = false;
            else 
                punishableList[i] = true;

            if ((taxesOwed[i] > 0) || (stealer[i] > 0)) {
                double infliction = influence[playerIdx][i] - (prevInfluence[playerIdx][i] * (1.0 - alpha));

                if (infliction < 0) {
                    if (verbose)
                        cout << "inflicted " << infliction << " on " << i << " in this round" << endl;
                    taxesOwed[i] = taxesOwed[i] + infliction;
                    if (taxesOwed[i] < 0.0) {
                        stealer[i] = stealer[i] + taxesOwed[i];
                        taxesOwed[i] = 0.0;
                        if (stealer[i] <= 0.0) {
                            stealer[i] = 0.0;
                            popularityShareAtSteal[i] = -1.0;
                        }
                    }
                }

                if ((stealer[i] > 0.0) && ((popularityShares[i] + 0.01) < popularityShareAtSteal[i])) {
                    if (verbose)
                        cout << "forgiving the stealer debt of " << i << " because they have dropped in popularity share" << endl;
                    stealer[i] = 0.0;
                    popularityShareAtSteal[i] = -1.0;
                }
            }
        }
    }

    void investigateTaxPayments(int numPlayers, int playerIdx, int numTokens, double *received) {
        for (int p = 0; p < numPlayers; p++) {
            if (p == playerIdx)
                continue;

            meritTaxTotal[p] += trueTaxes[p];
            meritTaxPaid[p] += (int)((received[p] * numTokens) + 0.5);

            double shortfall = ((trueTaxes[p] / (double)numTokens) - (received[p])) * coefs[GIVE_IDX] * (prevPopularities[p] * alpha);
            if (verbose)
                cout << "tax shortfall for " << p << ": " << shortfall << endl;
            if (shortfall > 0.001) {
                taxesOwed[p] = taxesOwed[p] + shortfall;
            }
            else {
                taxOverpay[p] += ceil(taxRates[p] * numTokens) - (taxRates[p] * numTokens);
            }
        }
    }

    void investigateTheft(int numPlayers, int playerIdx, int numTokens, int roundNum, double *popularities, double **influence) {
        for (int pSender = 0; pSender < numPlayers; pSender++) {
            if (pSender == playerIdx)
                continue;

            for (int pReceiver = 0; pReceiver < numPlayers; pReceiver++) {
                if (pSender == pReceiver)
                    continue;

                double diff = influence[pSender][pReceiver] - (prevInfluence[pSender][pReceiver] * (1.0 - alpha));
                double delta = max(stealCrimeThreshold_percent * prevPopularities[pReceiver], 7.0);

                bool hasGained = false;
                if (roundNum > 2) {
                    if (popularities[pSender] > prev2Popularities[pSender])
                        hasGained = true;
                }
                else {
                    if (popularities[pSender] > prevPopularities[pSender])
                        hasGained = true;
                }
            
                if ((diff < -delta) && verbose) {
                    cout << "A potential attack by " << pSender << " on " << pReceiver << " has been detected" << endl;
                    cout << "    has " << pSender << " gained? " << hasGained << endl;
                    cout << "    is " << pReceiver << " a stealer? " << stealer[pReceiver] << endl;
                    if (influence[pSender][pReceiver] < influence[pReceiver][pSender])
                        cout << "    attack appears to be unjustified" << endl;
                    else
                        cout << "    but attack appears to be justified" << endl;
                }

                if ((diff < -delta) && hasGained && (stealer[pReceiver] == 0) && (influence[pSender][pReceiver] < influence[pReceiver][pSender])) {
                    if (verbose) {
                        cout << "____________________________________________________" << endl;
                        cout << "A punishable attack by " << pSender << " on " << pReceiver << " has been detected" << endl;
                    }
                    if ((influence[pReceiver][pSender] >= -0.00000001) && (pReceiver != playerIdx)) {
                        if (verbose)
                            cout << pReceiver << " should be remunerated by the govment if they arent a stealer" << endl;
                        remunerateList[pReceiver] -= diff;
                    }
                    if (verbose)
                        cout << "---------------------------------------------------" << endl;

                    stealer[pSender] -= diff;
                    if (popularityShareAtSteal[pSender] < 0.0) {
                        popularityShareAtSteal[pSender] = prevPopularityShares[pSender];
                    }
                }
            }
        }

        // take stealer out of planned remunerations
        for (int p = 0; p < numPlayers; p++) {
            if (p == playerIdx)
                continue;

            if ((remunerateList[p] > 0) && (stealer[p] > 0.0)) {
                if (stealer[p] < remunerateList[p]) {
                    if (verbose)
                        cout << "reduce " << p << "'s remunerations because of stealing" << endl;
                    remunerateList[p] -= stealer[p];
                    stealer[p] = 0.0;
                    popularityShareAtSteal[p] = -1.0;
                }
                else {
                    if (verbose)
                        cout << "eliminate " << p << "'s remunerations because of stealing" << endl;
                    stealer[p] -= remunerateList[p];
                    remunerateList[p] = 0.0;
                }
            }
        }
    }

    void allocateTokens(int numPlayers, int numTokens, int playerIdx, int roundNum, double *popularities, double *received, double **influence, int *allocations) {
        int tokensRemaining = numTokens;

        if (verbose)
            cout << "tokensRemaining before it all begins: " << tokensRemaining << endl;

        int cuantoGuardo = defendSelf(numPlayers, playerIdx, numTokens, roundNum, received, popularities, tokensRemaining);
        if (verbose)
            cout << "keep " << cuantoGuardo << " tokens" << endl;
        allocations[playerIdx] = cuantoGuardo;
        tokensRemaining -= cuantoGuardo;

        // punishCrimes
        vector<int> crimePunishments = punishCrimesFunc(numPlayers, numTokens, playerIdx, roundNum, popularities, influence, tokensRemaining);
        if (verbose) {
            cout << "crimePunishments for this round: ";
            for (int i = 0; i < numPlayers; i++) {
                if (crimePunishments[i] > 0)
                    cout << "(" << i << ", " << crimePunishments[i] << "); ";
            }
            cout << endl;
        }

        for (int p = 0; p < numPlayers; p++) {
            if (crimePunishments[p] > 0) {
                allocations[p] = -1 * crimePunishments[p];
                tokensRemaining += allocations[p];
                //cout << "    " << tokensRemaining << endl;
            }
        }

        if (verbose)
            cout << "tokensRemaining after punishing crimes: " << tokensRemaining << endl;

        // remunerate
        if (remunerateVictims) {
            vector<int> remunerations = remunerateVictimsFunc(numPlayers, numTokens, playerIdx, popularities, tokensRemaining);
            if (verbose) {
                cout << "proposed remunerations for this round: ";
                for (int i = 0; i < numPlayers; i++) {
                    if (remunerations[i] > 0)
                        cout << "(" << i << ", " << remunerations[i] << "); ";
                }
                cout << endl;
            }

            for (int p = 0; p < numPlayers; p++) {
                if ((allocations[p] >= 0) && (remunerations[p] > 0)) {  // don't remunerate someone with unresolved crimes
                    allocations[p] = 1.0 * remunerations[p];
                    tokensRemaining = tokensRemaining - allocations[p];
                    remunerateList[p] -= ((allocations[p] * popularities[playerIdx] * alpha * coefs[GIVE_IDX]) / numTokens);

                    if (remunerateList[p] < 0.0)
                        remunerateList[p] = 0.0;
                }
            }
        }
        if (verbose)
            cout << "tokensRemaining after remunerations: " << tokensRemaining << endl;

        // reimburse
        double pSum = 0.0;
        for (int p = 0; p < numPlayers; p++)
            pSum += popularities[p];

        double tokens2Give = 0.0;
        if (popularities[playerIdx] > 0.0) {
            double sizeRate = popularities[playerIdx] / pSum;
            double thrshhld = poder / 100.0;
            if (sizeRate > thrshhld) {
                if (verbose)
                    cout << "reimburse freely" << endl;
                tokens2Give = tokensRemaining;
            }
            else if (sizeRate > (0.75 * thrshhld)) {
                if (verbose)
                    cout << "reimburse partially" << endl;
                tokens2Give = (int)((((sizeRate - (0.75 * thrshhld)) / (0.25 * thrshhld)) * tokensRemaining) + 0.5);
            }
        }

        vector<int> reimbursements = doReimbursementsFunc(numPlayers, numTokens, playerIdx, popularities, influence, tokens2Give);
        if (verbose) {
            cout << "proposed reimbursements for this round: ";
            for (int i = 0; i < numPlayers; i++) {
                if (reimbursements[i] > 0)
                    cout << "(" << i << ", " << reimbursements[i] << "); ";
            }
            cout << endl;
        }
        
        for (int p = 0; p < numPlayers; p++) {
            allocations[p] += reimbursements[p];
            tokensRemaining -= reimbursements[p];
        }

        if (verbose)
            cout << "tokensRemaining after reimbursements: " << tokensRemaining << endl;

        allocations[playerIdx] += tokensRemaining;
    }

    int defendSelf(int numPlayers, int playerIdx, int numTokens, int roundNum, double *received, double *popularities, int tokensRemaining) {
        if (popularities[playerIdx] <= 0.0)
            return 0.0;

        double attacksThisRound = 0.0;
        if (roundNum > 0) {
            for (int i = 0; i < numPlayers; i++) {
                if (i == playerIdx)
                    continue;

                if (received[i] < 0.0)
                    attacksThisRound -= received[i] * numTokens * popularities[i];
            }
        }

        if (verbose)
            cout << "gov attacked by " << attacksThisRound << " in power" << endl;

        attackPower = (attackPower + attacksThisRound) / 2.0;
        double raw = attackPower / popularities[playerIdx];

        if (verbose)
            cout << "use " << raw << " to defend" << endl;

        return ceil(raw);
    }

    vector<int> punishCrimesFunc(int numPlayers, int numTokens, int playerIdx, int roundNum, double *popularities, double **influence,int tokensRemaining) {
        vector<int> punishments;
        for (int p = 0; p < numPlayers; p++)
            punishments.push_back(0);

        if (popularities[playerIdx] < 0.001) {
            return punishments;
        }

        set<int> punishList;
        int totalPunishTokens = 0;
        for (int p = 0; p < numPlayers; p++) {
            if ((p == playerIdx) || !punishableList[p])
                continue;

            double amount2Recuperate = 0.0;
            if (punishTaxEvasion)
                amount2Recuperate += taxesOwed[p];
            if (punishStealing)
                amount2Recuperate += stealer[p];

            if (amount2Recuperate > popularities[p])
                amount2Recuperate = popularities[p];

            double takeEm = amount2Recuperate / (coefs[STEAL_IDX] * popularities[playerIdx] * alpha);

            if (verbose)
                cout << "take " << amount2Recuperate << " from " << p << " using " << takeEm << " raw tokens" << endl;

            if (takeEm > 0.0) {
                double k = isKeeping(p, numPlayers, influence);
                takeEm += k * popularities[p] / popularities[playerIdx];
                if (verbose)
                    cout << p << " is keeping " << k << " tokens, so add in " << (k * popularities[p] / popularities[playerIdx]) << " tokens" << endl;

                punishments[p] = ceil(takeEm * numTokens * punishmentStrength);
                punishList.insert(p);

                if (punishments[p] > numTokens)
                    punishments[p] = numTokens;

                totalPunishTokens += punishments[p];
            }
        }

        while (totalPunishTokens > tokensRemaining) {
            if (verbose)
                cout << "cannot punish all" << endl;

            if (punishList.empty())
                break;

            int idx = rand() % punishList.size();
            set<int>::iterator itr = punishList.begin();
            for (int i = 0; i < idx; i++, itr++);
            int key = *itr;
            while ((punishments[key] > 0) && (totalPunishTokens > tokensRemaining)) {
                punishments[key] --;
                totalPunishTokens --;
            }
            if (punishments[key] == 0) {
                punishList.erase(key);
            }
        }

        return punishments;
    }

    double isKeeping(int otherIdx, int numPlayers, double **influence) {
        double meAmount = 0.0;
        double totalAmount = 0.0;
        for (int i = 0; i < numPlayers; i++) {
            if (i == otherIdx)
                continue;

            if (influence[otherIdx][i] < 0.0) {
                totalAmount += -influence[otherIdx][i] / coefs[STEAL_IDX];
                meAmount -= -influence[otherIdx][i];
            }
            else {
                totalAmount += influence[otherIdx][i] / coefs[GIVE_IDX];
            }
        }

        meAmount = (meAmount + influence[otherIdx][otherIdx]) / coefs[KEEP_IDX];
        totalAmount += meAmount;

        if (totalAmount > 0.0)
            return meAmount / totalAmount;
        else
            return 1.0;
    }

    vector<int> remunerateVictimsFunc(int numPlayers, int numTokens, int playerIdx, double *popularities, int tokensRemaining) {
        vector<int> remunerations;
        for (int p = 0; p < numPlayers; p++)
            remunerations.push_back(0);

        if (popularities[playerIdx] < 0.001)
            return remunerations;

        set<int> remList;
        double totalRemunerations = 0.0;
        for (int p = 0; p < numPlayers; p++) {
            if (p == playerIdx)
                continue;

            if (remunerateList[p] > 0.0) {
                double amount = remunerateList[p] / (coefs[GIVE_IDX] * popularities[playerIdx] * alpha);

                remunerations[p] = ceil(amount * numTokens);
                totalRemunerations += remunerations[p];
                remList.insert(p);
            }
        }

        while (totalRemunerations > tokensRemaining) {
            if (verbose)
                cout << "cannot remunerate all" << endl;

            if (remList.empty())
                break;

            int idx = rand() % remList.size();
            set<int>::iterator itr = remList.begin();
            for (int i = 0; i < idx; i++, itr++);
            int key = *itr;
            while ((remunerations[key] > 0) && (totalRemunerations > tokensRemaining)) {
                remunerations[key] --;
                totalRemunerations --;
            }
            if (remunerations[key] == 0) {
                remList.erase(key);
            }
        }

        return remunerations;
    }

    vector<int> doReimbursementsFunc(int numPlayers, int numTokens, int playerIdx, double *popularities, double **influence, int tokensRemaining) {
        vector<int> reimbursements;
        vector<double> remainder;
        vector<double> rates;
        for (int p = 0; p < numPlayers; p++) {
            reimbursements.push_back(0);
            remainder.push_back(0.0);
            rates.push_back(0.0);
        }

        if (verbose)
            cout << "tokens2Give: " << tokensRemaining << endl;

        if ((popularities[playerIdx] < 0.001) || (tokensRemaining == 0))
            return reimbursements;

        if (verbose)
            cout << "there are tokens to give" << endl;

        getReimbursementRates(numPlayers, playerIdx, popularities, influence);

        double sum = 0.0;
        for (int p = 0; p < numPlayers; p++) {
            rates[p] = reimbursementRates[p];
            if (verbose)
                cout << "rates " << p << ": " << rates[p] << endl;
            if (p == playerIdx)
                continue;

            if (((taxesOwed[p] != 0.0) && punishTaxEvasion) || ((stealer[p] != 0.0) && punishStealing))
                rates[p] = 0.0;
            else
                sum += rates[p];
        }

        if (sum == 0.0)
            return reimbursements;

        // cout << "b" << endl;

        int totalReimbursements = 0;
        double capacity = 0.0;
        for (int p = 0; p < numPlayers; p++) {
            if (p == playerIdx)
                continue;

            rates[p] /= sum;
            if (rates[p] > 0.0) {
                double due = rates[p] * tokensRemaining;
                if (due > 0.0) {
                    reimbursements[p] = (int)(due);
                    remainder[p] = (due - reimbursements[p]) + gotLess[p];
                }
                else {
                    reimbursements[p] = 0;
                    remainder[p] = gotLess[p];
                }

                capacity += max(0.0, remainder[p]);

                totalReimbursements += reimbursements[p];
            }
        }

        if (verbose) {
            cout << "capacity: " << capacity << endl;
            cout << "totalReimbursements: " << totalReimbursements << endl;
        }

        while ((totalReimbursements < tokensRemaining) && (capacity > 0.00001)) {
            double num = (rand() / (double)(RAND_MAX)) * capacity;
            double sum = 0.0;
            int sel = -1;
            int last = -1;
            for (int p = 0; p < numPlayers; p++) {
                sum += max(0.0, remainder[p]);
                if (num < sum) {
                    sel = p;
                    break;
                }
                last = p;
            }
            if (sel == -1) {
                if (verbose)
                    cout << "***************************** unlikely chance" << endl;
                sel = last;
            }

            // add to totalReimbursements and reimbursements
            // remove from capacity and remainder
            if (sel != -1) {
                if (verbose)
                    cout << "adding 1 to " << sel << endl;
                reimbursements[sel] ++;
                totalReimbursements ++;
                if (remainder[sel] > 1)
                    capacity -= 1.0;
                else
                    capacity -= remainder[sel];
                remainder[sel] --;
            }
            else {
                cout << "got majory problems" << endl;
                exit(1);
            }
            if (verbose) {
                cout << "capacity: " << capacity << endl;
                cout << "totalReimbursements: " << totalReimbursements << endl;
            }
        }

        for (int p = 0; p < numPlayers; p++) {
            if (p != playerIdx)
                gotLess[p] = remainder[p];
        }

        return reimbursements;
    }

    double lookUpReimbursement(double value) {
        return (1.0 - value) * redistributionIndex.first[1] + value * redistributionIndex.second[1];
    }

    void getReimbursementRates(int numPlayers, int playerIdx, double *popularities, double **influence) {
        if (redistributionCurve == "Proportional") {
            for (int i = 0; i < numPlayers; i++) {
                if (i == playerIdx)
                    reimbursementRates[i] = 0.0;
                else
                    reimbursementRates[i] = taxRates[i] * popularities[i];
            }
            return;
        }
        else if (redistributionCurve == "Merit") {
            if (verbose)
                cout << "Merit reimbursementRates: ";
            for (int i = 0; i < numPlayers; i++) {
                if (i == playerIdx)
                    reimbursementRates[i] = 0.0;
                else {
                    double doneGood = 0.0, totalWeight = 0.0;
                    for (int j = 0; j < numPlayers; j++) {
                        if (j == playerIdx)
                            continue;

                        totalWeight += fabs(influence[i][j]);

                        if (i != j)
                            doneGood += influence[i][j];    // if influence[i][j] < 0, doneGood will go down
                    }
                    if (totalWeight == 0.0) {
                        // just add in the tax payment part
                        double w = 0.5;
                        if (meritTaxTotal[i] > 0.0)
                            w = meritTaxPaid[i] / meritTaxTotal[i];
                        reimbursementRates[i] = w * w;
                    }
                    else {
                        double w = 0.5 * (doneGood / totalWeight);
                        // add in the tax payment part too
                        if (meritTaxTotal[i] > 0.0)
                            w += 0.5 * (meritTaxPaid[i] / meritTaxTotal[i]);
                        else
                            w *= 2.0;
                        reimbursementRates[i] = max(0.0, w * w);
                    }
                }

                if (verbose)
                    cout << reimbursementRates[i] << " ";
            }
            if (verbose)
                cout << endl;
            return;
        }

        // compute normalized pops
        double theMin = 99999, theMax = -99999;
        for (int i = 0; i < numPlayers; i++) {
            if (i == playerIdx)
                continue;

            if (popularities[i] < theMin)
                theMin = popularities[i];
            if (popularities[i] > theMax)
                theMax = popularities[i];
        }

        double buf = 0.05 * theMax;
        theMax += buf;
        theMin -= buf;

        if (theMin < 0.0)
            theMin = 0.0;

        for (int i = 0; i < numPlayers; i++) {
            if (i == playerIdx)
                reimbursementRates[i] = 0.0;
            else {
                double value = (popularities[i] - theMin) / (theMax - theMin);
                reimbursementRates[i] = lookUpReimbursement(value);
            }
        }
    }

};

#endif