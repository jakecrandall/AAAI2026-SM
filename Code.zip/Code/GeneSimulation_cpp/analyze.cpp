#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <set>
#include <map>

#include "defs.h"
// #include "GeneAgent.h"

#include "GovTracker.h"

using namespace std;

#define MAX_PLAYERS     22

struct KeepProfile {
    double pobres, middles, ricos;

    KeepProfile() {
        pobres = middles = ricos = 0.0;
    }
};

struct ExtractionProfile {
    double extractions[5][5];

    ExtractionProfile() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                extractions[i][j] = 0.0;
            }
        }
    }

    void add(ExtractionProfile *ep) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                extractions[i][j] += ep->extractions[i][j];
            }
        }
    }

    void print() {
        cout << "\nExtraction profile:" << endl;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                cout << extractions[i][j] << "   ";
            }
            cout << endl;
        }
    }
};

struct GroupPrefs {
    GroupPrefs(int _i, int _j, int _numPlayers, double _G[MAX_PLAYERS][MAX_PLAYERS], vector<double> _mag) {
        for (int k = 0; k < _numPlayers; k++) {
            for (int m = 0; m < _numPlayers; m++) {
                G[k][m] = _G[k][m];
            }
        }
        // G = _G;
        i = _i;
        j = _j;
        numPlayers = _numPlayers;
        mag = _mag;
        total = 0.0;
        samesame = 0.0;
        polarization = 0.0;
        groupWeight_i = groupWeight_j = groupWeight_neutral = minWeightScale = 0.0;

        getPrefs();
    }

    ~GroupPrefs() {}

    void getPrefs() {
        for (int k = 0; k < numPlayers; k++) {
            if (k == i)
                for_i.insert(k);
            else if (k == j)
                for_j.insert(k);
            else {
                double threshold = 0.04 * mag[k];
                if (G[i][k] > (G[j][k] + threshold))
                    for_i.insert(k);
                else if (G[j][k] > (G[i][k] + threshold))
                    for_j.insert(k);
                else
                    neutral.insert(k);
            }
        }
    }
    
    void compare(GroupPrefs *other, int i, int j, vector<double> w) {
        // cout << "     ******* ";
        // other->print();
        double totalEste = 0;
        double samesameEste = 0.0;
        for (set<int>::iterator itr = for_i.begin(); itr != for_i.end(); itr++) {
            totalEste += w[*itr];
            if (i < j) {
                if (other->for_i.find(*itr) != other->for_i.end())
                    samesameEste += 1.0 * w[*itr];
                else if (other->neutral.find(*itr) != other->neutral.end())
                    samesameEste += 0.5 * w[*itr];
            }
            else {
                if (other->for_j.find(*itr) != other->for_j.end())
                    samesameEste += 1.0 * w[*itr];
                else if (other->neutral.find(*itr) != other->neutral.end())
                    samesameEste += 0.5 * w[*itr];
            }
        }

        for (set<int>::iterator itr = for_j.begin(); itr != for_j.end(); itr++) {
            totalEste += w[*itr];
            if (i < j) {
                if (other->for_j.find(*itr) != other->for_j.end())
                    samesameEste += 1.0 * w[*itr];
                else if (other->neutral.find(*itr) != other->neutral.end())
                    samesameEste += 0.5 * w[*itr];
            }
            else {
                if (other->for_i.find(*itr) != other->for_i.end())
                    samesameEste += 1.0 * w[*itr];
                else if (other->neutral.find(*itr) != other->neutral.end())
                    samesameEste += 0.5 * w[*itr];
            }
        }

        for (set<int>::iterator itr = neutral.begin(); itr != neutral.end(); itr++) {
            totalEste += w[*itr];// / 2.0;
        }

        // cout << "    " << i << "," << j << ": " << samesameEste << " / " << totalEste << endl;

        total += totalEste;
        samesame += samesameEste;

        // cout << "    " << i << "," << j << ": " << samesame << " / " << total << endl;

        polarization = (((samesame * minWeightScale) / total) - 0.5) / 0.5;

        // cout << "minWeightScale: " << minWeightScale << endl;
        // cout << "polarization: " << polarization << endl;
    }

    void computeWeights(vector<double> w) {
        for (set<int>::iterator itr = for_i.begin(); itr != for_i.end(); itr++)
            groupWeight_i += w[*itr];
        for (set<int>::iterator itr = for_j.begin(); itr != for_j.end(); itr++)
            groupWeight_j += w[*itr];
        for (set<int>::iterator itr = neutral.begin(); itr != neutral.end(); itr++)
            groupWeight_neutral += w[*itr];

        double minWeight = groupWeight_i;
        if (groupWeight_j < groupWeight_i)
            minWeight = groupWeight_j;
        if (minWeight < 0.2)
            minWeightScale = minWeight / 0.2;
        else
            minWeightScale = 1.0;
    }

    void print() {
        cout << "for_" << i << ": ";
        for (set<int>::iterator itr = for_i.begin(); itr != for_i.end(); itr++)
            cout << *itr << ", ";
        cout << " (" << groupWeight_i << "); for_" << j << ": ";
        for (set<int>::iterator itr = for_j.begin(); itr != for_j.end(); itr++)
            cout << *itr << ", ";
        cout << " (" << groupWeight_j << "); neutral: ";
        for (set<int>::iterator itr = neutral.begin(); itr != neutral.end(); itr++)
            cout << *itr << ", ";
        cout << " (" << groupWeight_neutral << ") -> " << polarization << endl;
    }

    set<int> for_i, for_j, neutral;
    int i, j, numPlayers;
    double G[MAX_PLAYERS][MAX_PLAYERS], polarization;
    vector<double> mag;
    double total, samesame;
    double groupWeight_i, groupWeight_j, groupWeight_neutral, minWeightScale;
};

struct EconAction {
    double givePerc, takePerc, keepPerc;
    int giveCount, takeCount, keepCount;

    EconAction() {
        giveCount = takeCount = keepCount = 0;
    }
};

struct RoundInfo {
    int numPlayers;
    int round;
    double alpha, beta, give, keep, steal;
    double popularities[MAX_PLAYERS];
    double transactions[MAX_PLAYERS][MAX_PLAYERS];
    double influences[MAX_PLAYERS][MAX_PLAYERS];
    string playerTypes[MAX_PLAYERS];
};

vector<string> parse(const string& s) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(s);
    while (getline(tokenStream, token, ','))
        tokens.push_back(token);
    return tokens;
}


RoundInfo readRound(string line, int numPlayers, bool flip) {
    RoundInfo rnd;
    vector<string> words = parse(line);

    rnd.numPlayers = numPlayers;
    rnd.round = stoi(words[0]);
    rnd.alpha = stof(words[1]);
    rnd.beta = stof(words[2]);
    rnd.give = stof(words[3]);
    rnd.keep = stof(words[4]);
    rnd.steal = stof(words[5]);

    for (int i = 0; i < numPlayers; i++) {
        rnd.popularities[i] = stof(words[i+6]);
    }

    int ind = 6 + numPlayers;
    for (int i = 0; i < numPlayers; i++) {
        for (int j = 0; j < numPlayers; j++) {
            rnd.transactions[i][j] = stof(words[ind]);
            ind ++;
        }
    }

    for (int i = 0; i < numPlayers; i++) {
        for (int j = 0; j < numPlayers; j++) {
            if (!flip)
                rnd.influences[i][j] = stof(words[ind]);
            else
                rnd.influences[j][i] = stof(words[ind]);
            ind ++;
        }
    }

    // bring this back in if it is for the human-bot studies
    // for (int i = 0; i < numPlayers; i++) {
    //     rnd.playerTypes[i] = words[ind];
    //     ind ++;
    // }

    return rnd;
}

int getNumPlayers(string line) {
    vector<string> words = parse(line);
    int i = 6;
    while (words[i][0] == 'p') {
        i++;
    }

    return i - 6;
}

vector<RoundInfo> readGame(string fnombre, bool flip) {
    cout << fnombre << endl;
    ifstream input(fnombre);

    if (!input) {
        cout << "Could not read file " << fnombre << endl;
        exit(-1);
    }

    vector<RoundInfo> v;

    string line;

    getline(input, line);  // read header
    int numPlayers = getNumPlayers(line);
    int c = 0;
    while (!input.eof()) {
        getline(input, line);
        // cout << c << ": " << line << " is it?" << endl;
        if (line.length() > 2) {
            v.push_back(readRound(line, numPlayers, flip));
            c++;
        }

        // if (c == 1) {
        //     cout << "Types for game: " << fnombre << endl;
        //     for (int i = 0; i < 8; i++) {
        //         cout << "  " << v[c-1].playerTypes[i] << endl;
        //         // cout << "  " << v[0].playerTypes[i] << endl;
        //     }
        // }
    }

    input.close();

    return v;
}

double getAveReciprocity(vector<RoundInfo> esto) {
    int numEdges = 0;
    int both = 0;
    for (int r = 1; r < esto.size(); r++) {
        for (int i = 0; i < esto[0].numPlayers; i++) {
            for (int j = i; j < esto[0].numPlayers; j++) {
                if (i == j) continue;
                if ((esto[r].transactions[j][i] > 0) && (esto[r].transactions[i][j] > 0))
                    both ++;
                if (esto[r].transactions[i][j] > 0)
                    numEdges ++;
                if (esto[r].transactions[j][i] > 0)
                    numEdges ++;
            }
        }
    }

    // cout << "numEdges: " << numEdges << endl;
    // cout << "numReciprocations: " << both << endl;

    return (2.0 * both) / numEdges;
}

double getAveDegree(vector<RoundInfo> esto) {
    double overallAverage = 0.0;
    for (int r = 1; r < esto.size(); r++) {
        double aveDegree = 0.0;
        for (int i = 0; i < esto[0].numPlayers; i++) {
            int numConnections = 0;
            for (int j = 0; j < esto[0].numPlayers; j++) {
                // cout << (int)(esto[r].transactions[i][j]*numTokens) << ", ";
                if (i == j) continue;
                if ((esto[r].transactions[i][j] > 0) && (esto[r].transactions[j][i] > 0))
                    numConnections ++;
            }
            aveDegree += numConnections / (double)(esto[0].numPlayers-1);
        }
        aveDegree /= esto[0].numPlayers;
        // cout << "Degree in round " << r << " is " << aveDegree << endl;
        overallAverage += aveDegree;
    }

    return overallAverage / (esto.size()-1);
}

EconAction getEconomicActionPercentages(vector<RoundInfo> esto) {
    EconAction econ;
    int numTokens = 2 * esto[0].numPlayers;
    for (int r = 1; r < esto.size(); r++) {
        for (int i = 0; i < esto[0].numPlayers; i++) {
            for (int j = 0; j < esto[0].numPlayers; j++) {
                if (i == j)
                    econ.keepCount += (int)(esto[r].transactions[i][j] * numTokens);
                else if (esto[r].transactions[i][j] > 0)
                    econ.giveCount += (int)(esto[r].transactions[i][j] * numTokens);
                else
                    econ.takeCount -= (int)(esto[r].transactions[i][j] * numTokens);
            }
        }
    }

    int total = econ.takeCount + econ.keepCount + econ.giveCount;
    econ.takePerc = econ.takeCount / (double)total;
    econ.keepPerc = econ.keepCount / (double)total;
    econ.givePerc = econ.giveCount / (double)total;

    return econ;
}

double getClusterCoef(vector<RoundInfo> esto) {
    int numPlayers = esto[0].numPlayers;
    // create the friend graph
    int **amigos = new int*[numPlayers];
    for (int i = 0; i < numPlayers; i++)
        amigos[i] = new int[numPlayers];

    int numPossible = 0;
    int numFound = 0;
    for (int r = 1; r < esto.size(); r++) {
        // // get the amigo graph
        int nuevoPossible = 0;
        int nuevoFound = 0;
        for (int i = 0; i < numPlayers; i++) {
            for (int j = 0; j < numPlayers; j++) {
                if ((esto[r].transactions[i][j] > 0) && (i != j)) {
                    for (int k = 0; k < numPlayers; k++) {
                        if ((j == k) || (i == k)) continue;
                        if (esto[r].transactions[i][k] > 0) {
                            nuevoPossible ++;
                            if (esto[r].transactions[j][k])
                                nuevoFound ++;
                        }
                    }
                }
            }
        }
        cout << (nuevoFound / (double)nuevoPossible) << endl;
        // cout << "nuevoPossibe after " << r << ": " << nuevoPossible << endl;

        numFound += nuevoFound;
        numPossible += nuevoPossible;

        // cout << "T:" << endl;
        // for (int i = 0; i < numPlayers; i++) {
        //     for (int j = 0; j < numPlayers; j++) {
        //         cout << (int)(esto[r].transactions[i][j]*2*numPlayers) << ", ";
        //     }
        //     cout << endl;
        // }

        // cout << endl << "Amigos: " << endl;
        // for (int i = 0; i < numPlayers; i++) {
        //     for (int j = 0; j < numPlayers; j++) {
        //         cout << amigos[i][j] << ", ";
        //     }
        //     cout << endl;
        // }


        // see how many of my friends are connected to each other

        // for (int i = 0; i < numPlayers; i++) {
        //     for (int j = 0; j < numPlayers; j++) {
        //         if (amigos[i][j] == 1) {
        //             for (int k = j+1; k < numPlayers; k++) {
        //                 if (amigos[i][k] == 1) {
        //                     numPossible ++;
        //                     if (amigos[j][k] == 1)
        //                         numFound ++;       
        //                 }        
        //             }
        //         }
        //     }
        // }
    }

    cout << "numFound: " << numFound << endl;
    cout << "numPossible: " << numPossible << endl;

    for (int i = 0; i < numPlayers; i++)
        delete[] amigos[i];
    delete[] amigos;

    return numFound / (double)numPossible;
}

double computePolarization(RoundInfo theRound) {
    vector<double> mag;
    vector<double> weights1, weights2;
    double totalWeight = 0.0;
    for (int k = 0; k < theRound.numPlayers; k++) {
        double s = 0.0;
        for (int m = 0; m < theRound.numPlayers; m++)
            s += fabs(theRound.influences[m][k]);
        mag.push_back(s);
        totalWeight += s;
    }
    // cout << "totalWeight: " << totalWeight << " -> ";
    for (int k = 0; k < theRound.numPlayers; k++) {
        weights1.push_back(1.0);
        weights2.push_back(mag[k] / totalWeight);
        // cout << weights2[k] << ", ";
    }
    // cout << endl;

    map<int, GroupPrefs *> groupings;
    for (int i = 0; i < theRound.numPlayers; i++) {
        for (int j = i+1; j < theRound.numPlayers; j++) {
            // determine sets specifying preferences for i or j (indifferent, for_i, for_j)
            GroupPrefs *group = new GroupPrefs(i, j, theRound.numPlayers, theRound.influences, mag);
            group->computeWeights(weights2);
            int index = i * theRound.numPlayers + j;
            // cout << index << endl;
            groupings[index] = group;
        }
    }

    // cout << "now compute polarization" << endl;

    double maxPolarization = 0.0;
    for (int i = 0; i < theRound.numPlayers; i++) {
        for (int j = i+1; j < theRound.numPlayers; j++) {
            int indexOrig = i * theRound.numPlayers + j;
            // groupings[indexOrig]->print();

            // compute polarization here
            for (set<int>::iterator itr_i = groupings[indexOrig]->for_i.begin(); itr_i != groupings[indexOrig]->for_i.end(); itr_i++) {
                for (set<int>::iterator itr_j = groupings[indexOrig]->for_j.begin(); itr_j != groupings[indexOrig]->for_j.end(); itr_j++) {
                    int index;
                    if (*itr_i > *itr_j)
                        index = *itr_j * theRound.numPlayers + *itr_i;
                    else
                        index = *itr_i * theRound.numPlayers + *itr_j;
                    // cout << *itr_i << " and " << *itr_j << " compare: " << index << endl;
                    groupings[indexOrig]->compare(groupings[index], *itr_i, *itr_j, weights1);
                }
            }

            // groupings[indexOrig]->print();
            // if (((groupings[indexOrig]->for_i.size() + groupings[indexOrig]->for_j.size()) > numPlayers * 0.7) && (groupings[indexOrig]->for_i.size() > 1) && (groupings[indexOrig]->for_j.size() > 1)) {
            // if ((groupings[indexOrig]->groupWeight_i > 0.2) && (groupings[indexOrig]->groupWeight_j > 0.2)) {
                if (groupings[indexOrig]->polarization > maxPolarization)
                    maxPolarization = groupings[indexOrig]->polarization;
            // }
        }
    }

    cout << "Polarization: " << maxPolarization << endl;
    return maxPolarization;
}

double getPolarizationCoef(vector<RoundInfo> esto) {
    double polarizationCoef = 0.0;
    for (int r = 1; r < esto.size(); r++) {
        polarizationCoef += computePolarization(esto[r]);
    }

    return polarizationCoef / esto.size();
}

vector<string> split(const string& s) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(s);
    while (getline(tokenStream, token, ','))
       tokens.push_back(token);
    return tokens;
}

void computeGameSummaryMetrics() {

    // produces a wealth gini coefficient of 0.5893 (UK wealth gini coefficient was about 0.59 from 2020 to 2022)
    // vector<double> startingPops;
    // startingPops.push_back(7);
    // startingPops.push_back(8);
    // startingPops.push_back(10);
    // startingPops.push_back(12);
    // startingPops.push_back(14);
    // startingPops.push_back(16);
    // startingPops.push_back(21);
    // startingPops.push_back(25);
    // startingPops.push_back(32);
    // startingPops.push_back(39);
    // startingPops.push_back(49);
    // startingPops.push_back(62);
    // startingPops.push_back(78);
    // startingPops.push_back(99);
    // startingPops.push_back(126);
    // startingPops.push_back(160);
    // startingPops.push_back(205);
    // startingPops.push_back(263);
    // startingPops.push_back(338);
    // startingPops.push_back(436);
    // // compute gini
    // double numerator = 0.0, s = 0.0;
    // for (int i = 0; i < startingPops.size(); i++) {
    //     for (int j = 0; j < startingPops.size(); j++) {
    //         numerator += fabs(startingPops[i] - startingPops[j]);
    //     }
    // }
    // double startingGiniIndex = numerator / (2.0 * 20.0 * 2000);
    // cout << "starting giniIndex: " << startingGiniIndex << endl;


    // ifstream input("../Results/coopLog_combined.csv");
    ifstream input("../Results/coopLog_Merit2.csv");
    if (!input) {
        cout << "file not found" << endl;
        exit(1);
    }

    // compute the social welfare
    // ofstream output("../Results/summary_combined.csv");
    ofstream output("../Results/summary_Merit.csv");

    output << "Condition,SW,Gini,poor1,poor2,poorInd,middle1,middle2,middleInd,rich1,rich2,richInd,aveCoop1,aveCoop2,totalSW" << endl;

    string line;
    getline(input,line);
    int c = 0;
    while (getline(input, line)) {
        // cout << line << endl;
        vector<string> words = split(line);
        double socialWelfare = 0.0;
        vector<double> endPops;
        vector<int> coopChoice;
        for (int i = 0; i < 20; i++) {
            endPops.push_back(stod(words[3+i*5]));
            socialWelfare += endPops[endPops.size()-1];

            coopChoice.push_back(stoi(words[4+i*5]));
        }
        double totalWelfare = socialWelfare;
        if ((words[2] == "With Coops") || (words[2] != "No")) {
            totalWelfare += stod(words[3+20*5]) + stod(words[3+21*5]);
        }

        // compute gini
        double numerator = 0.0, s = 0.0;
        for (int i = 0; i < endPops.size(); i++) {
            for (int j = 0; j < endPops.size(); j++) {
                numerator += fabs(endPops[i] - endPops[j]);
            }
        }
        double giniIndex = numerator / (2.0 * 20.0 * socialWelfare);

        int poor1 = 0, poor2 = 0, poorInd = 0;
        int middle1 = 0, middle2 = 0, middleInd = 0;
        int rich1 = 0, rich2 = 0, richInd = 0;
        // if (c >= 100) {
            for (int i = 0; i < 11; i++) {
                if (coopChoice[i] == 0)
                    poor1 ++;
                else if (coopChoice[i] == 1)
                    poor2 ++;
                else
                    poorInd ++;
            }

            for (int i = 11; i < 15; i++) {
                if (coopChoice[i] == 0)
                    middle1 ++;
                else if (coopChoice[i] == 1)
                    middle2 ++;
                else
                    middleInd ++;
            }

            for (int i = 15; i < 20; i++) {
                if (coopChoice[i] == 0)
                    rich1 ++;
                else if (coopChoice[i] == 1)
                    rich2 ++;
                else
                    richInd ++;
            }
        // }    

        if (words[2] == "Untuned")
            output << "Untuned," << (socialWelfare / 20.0) << "," << giniIndex << ",NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA," << totalWelfare << endl;
        else if (words[2] == "Tuned")
            output << "Tuned," << (socialWelfare / 20.0) << "," << giniIndex << ",NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA," << totalWelfare << endl;
        else if  (words[2] == "No")
            output << "No," << (socialWelfare / 20.0) << "," << giniIndex << ",NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA," << totalWelfare << endl;
        else { //if (words[2] == "With Coops") {
            // output << "With Coops," << (socialWelfare / 20.0) << "," << giniIndex 
            output << words[2] << "," << (socialWelfare / 20.0) << "," << giniIndex 
            << "," << poor1 << "," << poor2 << "," << poorInd
            << "," << middle1 << "," << middle2 << "," << middleInd
            << "," << rich1 << "," << rich2 << "," << richInd
            << "," << words[104] << "," << words[109] << "," << totalWelfare
            << endl;
        }

        c++;
    }

    output.close();
    input.close();
}

void computeGameSummaryStuff() {
    double initPop[20] = {7,8,10,12,14,16,21,25,32,39,49,62,78,99,126,160,205,263,338,436};

    ifstream input("../Results/coopLog_2.csv");
    if (!input) {
        cout << "file not found" << endl;
        exit(1);
    }

    // compute the social welfare
    ofstream output("../Results/summary_2.csv");

    output << "Condition,SW,Gini,poorM,poorMCount,poorNM,poorNMCount,middleM,middleMCount,middleNM,middleNMCount,richM,richMCount,richNM,richNMCount,aveCoop1,totalSW" << endl;

    string line;
    getline(input,line);
    while (getline(input, line)) {
        vector<string> words = split(line);
        double socialWelfare = 0.0;
        vector<double> endPops;
        vector<int> coopChoice;
        for (int i = 0; i < 20; i++) {
            endPops.push_back(stod(words[3+i*5]));
            socialWelfare += endPops[endPops.size()-1];

            coopChoice.push_back(stoi(words[4+i*5]));
        }
        double totalWelfare = socialWelfare;
        if (words[2] == "1coop50") {
            totalWelfare += stod(words[3+20*5]);
        }

        // compute gini
        double numerator = 0.0, s = 0.0;
        for (int i = 0; i < endPops.size(); i++) {
            for (int j = 0; j < endPops.size(); j++) {
                numerator += fabs(endPops[i] - endPops[j]);
            }
        }
        double giniIndex = numerator / (2.0 * 20.0 * socialWelfare);

        double poorM = 0.0, poorNM = 0.0;
        double middleM = 0.0, middleNM = 0.0;
        double richM = 0.0, richNM = 0.0;
        int cpM, cpNM, cmM, cmNM, crM, crNM;
        cpM = cpNM = cmM = cmNM = crM = crNM = 0;
        for (int i = 0; i < 11; i++) {
            // cout << endPops[i] << ": ";
            if (coopChoice[i] == 0) {
                cpM ++;
                poorM += endPops[i] / initPop[i];
                // cout << i << " is member: " << (endPops[i] / initPop[i]) << " -> " << poorM << endl;
            }
            else {
                cpNM ++;
                poorNM += endPops[i] / initPop[i];
                // cout << i << " is nonmember: " << (endPops[i] / initPop[i]) << " -> " << poorNM << endl;
            }
        }
        for (int i = 11; i < 15; i++) {
            // cout << endPops[i] << ": ";
            if (coopChoice[i] == 0) {
                cmM ++;
                middleM += endPops[i] / initPop[i];
                // cout << i << " is member: " << (endPops[i] / initPop[i]) << " -> " << middleM <<  endl;
            }
            else {
                cmNM ++;
                middleNM += endPops[i] / initPop[i];
                // cout << i << " is nonmember: " << (endPops[i] / initPop[i]) << " -> " << middleNM << endl;
            }
        }
        for (int i = 15; i < 20; i++) {
            // cout << endPops[i] << ": ";
            if (coopChoice[i] == 0) {
                crM ++;
                richM += endPops[i] / initPop[i];
                // cout << i << " is member: " << (endPops[i] / initPop[i]) << " -> " << richM << endl;
            }
            else {
                crNM ++;
                richNM += endPops[i] / initPop[i];
                // cout << i << " is nonmember: " << (endPops[i] / initPop[i]) << " -> " << richNM << endl;
            }
        }

        output << "1coop50," << (socialWelfare / 20.0) << "," << giniIndex 
        << "," << poorM << "," << cpM << "," << poorNM << "," << cpNM
        << "," << middleM << "," << cmM << "," << middleNM << "," << cmNM
        << "," << richM << "," << crM << "," << richNM << "," << crNM
        << "," << words[104] << "," << totalWelfare
        << endl;

        // break;
    }

    output.close();
    input.close();
}

void computeAveCoopSize() {
    double aveCoop1 = 0.0;
    double aveCoop2 = 0.0;
    for (int v = 0; v < 10; v++) {
        for (int g = 0; g < 100; g++) {
            double coop1 = 0.0;
            double coop2 = 0.0;
            vector<RoundInfo> esto = readGame("../Results/theGameLogs/MeritTest/v" + to_string(v) + "/game" + to_string(g) + ".txt", false);
            for (int r = 0; r < esto.size(); r++) {
                double mag = 0.0;
                for (int i = 0; i < esto[r].numPlayers; i++) {
                    mag += esto[r].popularities[i];
                }
                coop1 += esto[r].popularities[0] / mag;
                coop2 += esto[r].popularities[1] / mag;
                // cout << (esto[r].popularities[0] / mag) << "," << (esto[r].popularities[1] / mag) << endl;
            }
            coop1 /= esto.size();
            coop2 /= esto.size();

            cout << coop1 << "\t" << coop2 << endl;

            aveCoop1 += coop1;
            aveCoop2 += coop2;
        }
    }

    cout << endl;
    cout << "coop1: " << (aveCoop1 / 1000.0) << endl;
    cout << "coop2: " << (aveCoop2 / 1000.0) << endl;
}

KeepProfile computeKeeps(vector<RoundInfo> esto, int rounds2Analyze) {
    set<int> losPobres;
    set<int> losMiddles;
    set<int> losRicos;
    if (esto[0].numPlayers == 20) {
        for (int i = 0; i < 11; i++)
            losPobres.insert(i);
        for (int i = 11; i < 15; i++)
            losMiddles.insert(i);
        for (int i = 15; i < 20; i++)
            losRicos.insert(i);
    }
    else {
        for (int i = 2; i < 13; i++)
            losPobres.insert(i);
        for (int i = 13; i < 17; i++)
            losMiddles.insert(i);
        for (int i = 17; i < 22; i++)
            losRicos.insert(i);
    }

    KeepProfile kp;
    for (int r = 1; r < rounds2Analyze+1; r++) {
        for (set<int>::iterator itr = losPobres.begin(); itr != losPobres.end(); itr++) {
            kp.pobres += esto[r].transactions[*itr][*itr];
        }
        for (set<int>::iterator itr = losMiddles.begin(); itr != losMiddles.end(); itr++) {
            kp.middles += esto[r].transactions[*itr][*itr];
        }
        for (set<int>::iterator itr = losRicos.begin(); itr != losRicos.end(); itr++) {
            kp.ricos += esto[r].transactions[*itr][*itr];
        }
    }

    // cout << "pobres: " << (kp.pobres / (losPobres.size() * rounds2Analyze)) << endl;
    // cout << "middles: " << (kp.middles / (losMiddles.size() * rounds2Analyze)) << endl;
    // cout << "ricos: " << (kp.ricos / (losRicos.size() * rounds2Analyze)) << endl;

    kp.pobres /= (losPobres.size() * rounds2Analyze);
    kp.middles /= (losMiddles.size() * rounds2Analyze);
    kp.ricos /= (losRicos.size() * rounds2Analyze);

    return kp;
}

void computeKeepingNumbers() {
    int rounds2Analyze = 80;
    int numGames = 100;
    KeepProfile tally;
    for (int v = 0; v < 10; v++) {
        for (int g = 0; g < numGames; g++) {
            // vector<RoundInfo> esto = readGame("../Results/theGameLogs/Tuned/game" + to_string(g) + ".txt", false);
            vector<RoundInfo> esto = readGame("../Results/theGameLogs/MeritTest/v" + to_string(v) + "/game" + to_string(g) + ".txt", false);
            KeepProfile kp = computeKeeps(esto, rounds2Analyze);
            tally.pobres += kp.pobres;
            tally.middles += kp.middles;
            tally.ricos += kp.ricos;
        }
    }

    cout << endl << endl;
    cout << "pobres: " << (tally.pobres / (numGames * 10.0)) << endl;;
    cout << "middles: " << (tally.middles / (numGames * 10.0)) << endl;
    cout << "ricos: " << (tally.ricos / (numGames * 10.0)) << endl;
}

ExtractionProfile computeSteals(vector<RoundInfo> esto, int rounds2Analyze) {
    set<int> losPobres;
    set<int> losMiddles;
    set<int> losRicos;
    int coop1Index;
    int coop2Index;
    if (esto[0].numPlayers == 20) {
        for (int i = 0; i < 11; i++)
            losPobres.insert(i);
        for (int i = 11; i < 15; i++)
            losMiddles.insert(i);
        for (int i = 15; i < 20; i++)
            losRicos.insert(i);
        coop1Index = coop2Index = -1;
    }
    else {
        for (int i = 2; i < 13; i++)
            losPobres.insert(i);
        for (int i = 13; i < 17; i++)
            losMiddles.insert(i);
        for (int i = 17; i < 22; i++)
            losRicos.insert(i);

        coop1Index = 0;
        coop2Index = 1;
    }

    ExtractionProfile ep;
    double amount;
    for (int r = 1; r < rounds2Analyze+1; r++) {
        // see how much pobres try to extract
        for (set<int>::iterator itr = losPobres.begin(); itr != losPobres.end(); itr++) {
            // from other pobres
            amount = 0.0;
            for (set<int>::iterator itr2 = losPobres.begin(); itr2 != losPobres.end(); itr2++) {
                if (*itr == *itr2)
                    continue;

                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[0][0] += amount;

            // from middles
            amount = 0.0;
            for (set<int>::iterator itr2 = losMiddles.begin(); itr2 != losMiddles.end(); itr2++) {
                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[0][1] += amount;


            // from ricos
            amount = 0.0;
            for (set<int>::iterator itr2 = losRicos.begin(); itr2 != losRicos.end(); itr2++) {
                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[0][2] += amount;

            // by and from coops
            if (coop1Index >= 0) {
                amount = 0.0;
                if (esto[r].transactions[*itr][coop1Index] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][coop1Index] * esto[r].alpha;
                ep.extractions[0][3] += amount;    

                amount = 0.0;
                if (esto[r].transactions[coop1Index][*itr] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[coop1Index] * esto[r].transactions[coop1Index][*itr] * esto[r].alpha;
                ep.extractions[3][0] += amount;    
            }

            if (coop2Index >= 0) {
                amount = 0.0;
                if (esto[r].transactions[*itr][coop2Index] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][coop2Index] * esto[r].alpha;
                ep.extractions[0][4] += amount;    

                amount = 0.0;
                if (esto[r].transactions[coop2Index][*itr] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[coop2Index] * esto[r].transactions[coop2Index][*itr] * esto[r].alpha;
                ep.extractions[4][0] += amount;    
            }
        }

        // see how much middles try to extract
        for (set<int>::iterator itr = losMiddles.begin(); itr != losMiddles.end(); itr++) {
            // from other pobres
            amount = 0.0;
            for (set<int>::iterator itr2 = losPobres.begin(); itr2 != losPobres.end(); itr2++) {
                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[1][0] += amount;

            // from middles
            amount = 0.0;
            for (set<int>::iterator itr2 = losMiddles.begin(); itr2 != losMiddles.end(); itr2++) {
                if (*itr == *itr2)
                    continue;

                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[1][1] += amount;


            // from ricos
            amount = 0.0;
            for (set<int>::iterator itr2 = losRicos.begin(); itr2 != losRicos.end(); itr2++) {
                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[1][2] += amount;

            // by and from coops
            if (coop1Index >= 0) {
                amount = 0.0;
                if (esto[r].transactions[*itr][coop1Index] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][coop1Index] * esto[r].alpha;
                ep.extractions[1][3] += amount;    

                amount = 0.0;
                if (esto[r].transactions[coop1Index][*itr] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[coop1Index] * esto[r].transactions[coop1Index][*itr] * esto[r].alpha;
                ep.extractions[3][1] += amount;    
            }

            if (coop2Index >= 0) {
                amount = 0.0;
                if (esto[r].transactions[*itr][coop2Index] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][coop2Index] * esto[r].alpha;
                ep.extractions[1][4] += amount;    

                amount = 0.0;
                if (esto[r].transactions[coop2Index][*itr] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[coop2Index] * esto[r].transactions[coop2Index][*itr] * esto[r].alpha;
                ep.extractions[4][1] += amount;    
            }
        }

        // see how much ricos try to extract
        for (set<int>::iterator itr = losRicos.begin(); itr != losRicos.end(); itr++) {
            // from other pobres
            amount = 0.0;
            for (set<int>::iterator itr2 = losPobres.begin(); itr2 != losPobres.end(); itr2++) {
                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[2][0] += amount;

            // from middles
            amount = 0.0;
            for (set<int>::iterator itr2 = losMiddles.begin(); itr2 != losMiddles.end(); itr2++) {
                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[2][1] += amount;

            // from ricos
            amount = 0.0;
            for (set<int>::iterator itr2 = losRicos.begin(); itr2 != losRicos.end(); itr2++) {
                if (*itr == *itr2)
                    continue;

                if (esto[r].transactions[*itr][*itr2] < 0) {
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][*itr2] * esto[r].alpha;
                }
            }
            ep.extractions[2][2] += amount;

            // by and from coops
            if (coop1Index >= 0) {
                amount = 0.0;
                if (esto[r].transactions[*itr][coop1Index] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][coop1Index] * esto[r].alpha;
                ep.extractions[2][3] += amount;    

                amount = 0.0;
                if (esto[r].transactions[coop1Index][*itr] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[coop1Index] * esto[r].transactions[coop1Index][*itr] * esto[r].alpha;
                ep.extractions[3][2] += amount;    
            }

            if (coop2Index >= 0) {
                amount = 0.0;
                if (esto[r].transactions[*itr][coop2Index] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[*itr] * esto[r].transactions[*itr][coop2Index] * esto[r].alpha;
                ep.extractions[2][4] += amount;    

                amount = 0.0;
                if (esto[r].transactions[coop2Index][*itr] < 0)
                    amount += esto[r].steal * esto[r-1].popularities[coop2Index] * esto[r].transactions[coop2Index][*itr] * esto[r].alpha;
                ep.extractions[4][2] += amount;    
            }
        }

        // see how much cooperatives steal from each other
        if (coop1Index >= 0) {
            amount = 0.0;
            if (esto[r].transactions[coop1Index][coop2Index] < 0)
                amount += esto[r].steal * esto[r-1].popularities[coop1Index] * esto[r].transactions[coop1Index][coop2Index] * esto[r].alpha;
            ep.extractions[3][4] += amount;    

            amount = 0.0;
            if (esto[r].transactions[coop2Index][coop1Index] < 0)
                amount += esto[r].steal * esto[r-1].popularities[coop2Index] * esto[r].transactions[coop2Index][coop1Index] * esto[r].alpha;
            ep.extractions[4][3] += amount;    
        }
    }    

    return ep;
}

void computeExtractionNumbers() {
    int rounds2Analyze = 80;
    int numGames = 100;

    ExtractionProfile tally;


    for (int v = 0; v < 10; v++) {
        for (int g = 0; g < numGames; g++) {
            vector<RoundInfo> esto = readGame("../Results/theGameLogs/Tuned/game" + to_string(g) + ".txt", false);
            // vector<RoundInfo> esto = readGame("../Results/theGameLogs/MeritTest/v" + to_string(v) + "/game" + to_string(g) + ".txt", false);
            ExtractionProfile ep = computeSteals(esto, rounds2Analyze);
            tally.add(&ep);
        }
    }

    // divide by the number of games
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            tally.extractions[i][j] /= numGames * 10;
        }
    }

    tally.print();
}

ExtractionProfile computeTrades(vector<RoundInfo> esto, int rounds2Analyze, double toCoop[3]) {
    set<int> losPobres;
    set<int> losMiddles;
    set<int> losRicos;
    if (esto[0].numPlayers == 20) {
        for (int i = 0; i < 11; i++)
            losPobres.insert(i);
        for (int i = 11; i < 15; i++)
            losMiddles.insert(i);
        for (int i = 15; i < 20; i++)
            losRicos.insert(i);
    }
    else {
        for (int i = 2; i < 13; i++)
            losPobres.insert(i);
        for (int i = 13; i < 17; i++)
            losMiddles.insert(i);
        for (int i = 17; i < 22; i++)
            losRicos.insert(i);
    }

    ExtractionProfile tp;
    for (int r = 1; r < rounds2Analyze+1; r++) {
        // see how much pobres give
        for (set<int>::iterator itr = losPobres.begin(); itr != losPobres.end(); itr++) {
            for (int i = 0; i < esto[r].numPlayers; i++) {
                if (*itr == i)
                    continue;

                if (esto[r].transactions[*itr][i] > 0) {
                    if (losPobres.find(i) != losPobres.end()) {
                        tp.extractions[0][0] += esto[r].transactions[*itr][i];
                    }
                    else if (losMiddles.find(i) != losMiddles.end()) {
                        tp.extractions[0][1] += esto[r].transactions[*itr][i];
                    }
                    else if (losRicos.find(i) != losRicos.end()) {
                        tp.extractions[0][2] += esto[r].transactions[*itr][i];
                    }
                    else {
                        toCoop[0] += esto[r].transactions[*itr][i];
                    }
                }
            }
        }

        // see how much middles give
        for (set<int>::iterator itr = losMiddles.begin(); itr != losMiddles.end(); itr++) {
            for (int i = 0; i < esto[r].numPlayers; i++) {
                if (*itr == i)
                    continue;

                if (esto[r].transactions[*itr][i] > 0) {
                    if (losPobres.find(i) != losPobres.end()) {
                        tp.extractions[1][0] += esto[r].transactions[*itr][i];
                    }
                    else if (losMiddles.find(i) != losMiddles.end()) {
                        tp.extractions[1][1] += esto[r].transactions[*itr][i];
                    }
                    else if (losRicos.find(i) != losRicos.end()) {
                        tp.extractions[1][2] += esto[r].transactions[*itr][i];
                    }
                    else {
                        toCoop[1] += esto[r].transactions[*itr][i];
                    }
                }
            }
        }

        // see how much ricos give
        for (set<int>::iterator itr = losRicos.begin(); itr != losRicos.end(); itr++) {
            for (int i = 0; i < esto[r].numPlayers; i++) {
                if (*itr == i)
                    continue;

                if (esto[r].transactions[*itr][i] > 0) {
                    if (losPobres.find(i) != losPobres.end()) {
                        tp.extractions[2][0] += esto[r].transactions[*itr][i];
                    }
                    else if (losMiddles.find(i) != losMiddles.end()) {
                        tp.extractions[2][1] += esto[r].transactions[*itr][i];
                    }
                    else if (losRicos.find(i) != losRicos.end()) {
                        tp.extractions[2][2] += esto[r].transactions[*itr][i];
                    }
                    else {
                        toCoop[2] += esto[r].transactions[*itr][i];
                    }
                }
            }
        }
    }

    for (int i = 0; i < 3; i++) {
        double total = tp.extractions[i][0] + tp.extractions[i][1] + tp.extractions[i][2] + toCoop[i];
        tp.extractions[i][0] /= total; 
        tp.extractions[i][1] /= total; 
        tp.extractions[i][2] /= total;
        toCoop[i] /= total;
    }

    return tp;
}

ExtractionProfile computeTradeAmounts(vector<RoundInfo> esto, int rounds2Analyze, double toCoop[3]) {
    set<int> losPobres;
    set<int> losMiddles;
    set<int> losRicos;
    if (esto[0].numPlayers == 20) {
        for (int i = 0; i < 11; i++)
            losPobres.insert(i);
        for (int i = 11; i < 15; i++)
            losMiddles.insert(i);
        for (int i = 15; i < 20; i++)
            losRicos.insert(i);
    }
    else {
        for (int i = 2; i < 13; i++)
            losPobres.insert(i);
        for (int i = 13; i < 17; i++)
            losMiddles.insert(i);
        for (int i = 17; i < 22; i++)
            losRicos.insert(i);
    }

    ExtractionProfile tp;
    for (int r = 1; r < rounds2Analyze+1; r++) {
        // see how much pobres give
        for (set<int>::iterator itr = losPobres.begin(); itr != losPobres.end(); itr++) {
            for (int i = 0; i < esto[r].numPlayers; i++) {
                if (*itr == i)
                    continue;

                if (esto[r].transactions[*itr][i] > 0) {
                    if (losPobres.find(i) != losPobres.end()) {
                        tp.extractions[0][0] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else if (losMiddles.find(i) != losMiddles.end()) {
                        tp.extractions[0][1] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else if (losRicos.find(i) != losRicos.end()) {
                        tp.extractions[0][2] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else {
                        toCoop[0] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                }
            }
        }

        // see how much middles give
        for (set<int>::iterator itr = losMiddles.begin(); itr != losMiddles.end(); itr++) {
            for (int i = 0; i < esto[r].numPlayers; i++) {
                if (*itr == i)
                    continue;

                if (esto[r].transactions[*itr][i] > 0) {
                    if (losPobres.find(i) != losPobres.end()) {
                        tp.extractions[1][0] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else if (losMiddles.find(i) != losMiddles.end()) {
                        tp.extractions[1][1] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else if (losRicos.find(i) != losRicos.end()) {
                        tp.extractions[1][2] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else {
                        toCoop[1] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                }
            }
        }

        // see how much ricos give
        for (set<int>::iterator itr = losRicos.begin(); itr != losRicos.end(); itr++) {
            for (int i = 0; i < esto[r].numPlayers; i++) {
                if (*itr == i)
                    continue;

                if (esto[r].transactions[*itr][i] > 0) {
                    if (losPobres.find(i) != losPobres.end()) {
                        tp.extractions[2][0] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else if (losMiddles.find(i) != losMiddles.end()) {
                        tp.extractions[2][1] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else if (losRicos.find(i) != losRicos.end()) {
                        tp.extractions[2][2] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                    else {
                        toCoop[2] += esto[r].transactions[*itr][i] * esto[r-1].popularities[*itr];
                    }
                }
            }
        }
    }

    // for (int i = 0; i < 3; i++) {
    //     double total = tp.extractions[i][0] + tp.extractions[i][1] + tp.extractions[i][2] + toCoop[i];
    //     tp.extractions[i][0] /= total; 
    //     tp.extractions[i][1] /= total; 
    //     tp.extractions[i][2] /= total;
    //     toCoop[i] /= total;
    // }

    return tp;
}

void computeTradePercentages() {
    int rounds2Analyze = 80;
    int numGames = 500;
    ExtractionProfile tally;
    double toCoopTally[3] = {0.0, 0.0, 0.0};
    for (int v = 0; v < 1; v++) {
        for (int g = 0; g < numGames; g++) {
            vector<RoundInfo> esto = readGame("../Results/theGameLogs/Tuned/game" + to_string(g) + ".txt", false);
            // vector<RoundInfo> esto = readGame("../Results/theGameLogs/PropvProgTest/v" + to_string(v) + "/game" + to_string(g) + ".txt", false);
            double toCoop[3] = {0.0, 0.0, 0.0};
            // ExtractionProfile tp = computeTrades(esto, rounds2Analyze, toCoop);
            ExtractionProfile tp = computeTradeAmounts(esto, rounds2Analyze, toCoop);
            tally.add(&tp);
            for (int j = 0; j < 3; j++)
                toCoopTally[j] += toCoop[j];
        }
    }

    // divide by the number of games
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            tally.extractions[i][j] /= numGames * 1;
        }
        toCoopTally[i] /= numGames * 1;
    }

    // tally.print();
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << tally.extractions[i][j] << "   ";
        }
        cout << toCoopTally[i] << endl;
    }
}

vector< vector<double> > computeInOutTrading(vector<RoundInfo> esto, vector<int> coopChoices) {
    vector< vector<double> > numeros;
    vector<double> coop1, coop2, indy;
    for (int i = 0; i < 3; i++) {
        coop1.push_back(0.0);
        coop2.push_back(0.0);
        indy.push_back(0.0);
    }
    numeros.push_back(coop1);
    numeros.push_back(coop2);
    numeros.push_back(indy);

    for (int r = 1; r < 81; r++) {
        for (int i = 2; i < esto[r].numPlayers; i++) {
            for (int j = 0; j < esto[r].numPlayers; j++) {
                if (esto[r].transactions[i][j] > 0.0) {
                    numeros[coopChoices[i]][coopChoices[j]] += esto[r].transactions[i][j];
                }
            }
        }
    }

    return numeros;
}

void considerGroupTrading() {
    // ifstream input("../Results/coopLog_first.csv");
    ifstream input("../Results/coopLog_PropvProg.csv");
    if (!input) {
        cout << "file not found" << endl;
        exit(1);
    }

    vector< vector<double> > tally;
    vector<double> coop1, coop2, indy;
    for (int i = 0; i < 3; i++) {
        coop1.push_back(0.0);
        coop2.push_back(0.0);
        indy.push_back(0.0);
    }
    tally.push_back(coop1);
    tally.push_back(coop2);
    tally.push_back(indy);

    string line;
    getline(input,line);
    int c = 0;
    while (getline(input, line)) {
        vector<string> words = split(line);
        vector<int> coopChoices;
        coopChoices.push_back(0);
        coopChoices.push_back(1);    
        for (int i = 0; i < 20; i++) {
            coopChoices.push_back(stoi(words[4+i*5]));
            if (coopChoices[coopChoices.size()-1] == -1)
                coopChoices[coopChoices.size()-1] = 2;
        }

        // open up the game file and compute in and out group giving
        // string gameFile;
        // if (c < 500)
        //     gameFile = "../Results/theGameLogs/Untuned/game" + to_string(c) + ".txt";
        // else if (c < 1000)
        //     gameFile = "../Results/theGameLogs/Tuned/game" + to_string(c-500) + ".txt";
        // if (c >= 1000) {
            // string gameFile = "../Results/theGameLogs/WithCoops/game" + to_string(c-1000) + ".txt";
            string gameFile = "../Results/theGameLogs/PropvProgTest/v" + to_string(c / 100) + "/game" + to_string(c%100) + ".txt";
            vector<RoundInfo> esto = readGame(gameFile, false);
            vector< vector<double> > numeros = computeInOutTrading(esto, coopChoices);

            for (int i = 0; i < 3; i++) {
                // double total = numeros[i][0] + numeros[i][1] + numeros[i][2];
                // if (total == 0.0) {
                //     cout << i << endl;
                //     exit(1);
                // }   
                for (int j = 0; j < 3; j++) {
                    tally[i][j] += numeros[i][j];
                    // numeros[i][j] /= total;
                    // cout << numeros[i][j] << " ";
                }
                // cout << endl;
            }
        // }


        c++;
    }

    double totalTotal = 0.0;
    for (int i = 0; i < 3; i++) {
        double total = tally[i][0] + tally[i][1] + tally[i][2];
        totalTotal += total;
        for (int j = 0; j < 3; j++) {
            cout << tally[i][j] / total << " ";
        }
        cout << endl;
    }

    cout << "Percentage within group: " << ((tally[0][0] + tally[1][1] + tally[2][2]) / totalTotal) << endl;
}


int main(int argc, char *argv[]) {
    // get best government
    // ifstream input("../DataGatheringCopies/Institutions11/Results/theGenerations/gen_19.csv");
    // ifstream input("../Results/theGenerations/gen_19.csv");
    // if (!input) {
    //     cout << "file not found" << endl;
    //     exit(1);
    // }
    // string line;
    // double mx = 0.0;
    // string mxGenes = "";
    // for (int i = 0; i < 25; i++) {
    //     getline(input, line);
    //     vector<string> words = split(line);
    //     if (stof(words[1]) > mx) {
    //         mx = stof(words[1]);
    //         mxGenes = words[0];
    //     }
    // }
    // cout << "Max found: " << mxGenes << " with " << mx << endl;

    // input.close();

    // GovTracker g(mxGenes);
    // g.write2File();
    // cout << "donzer" << endl;


    // 1 coop: figure out social welfare, gini index, and the percentages that each coop is chosen
    // computeGameSummaryStuff();

    // 2 coops: figure out social welfare, gini index, and the percentages that each coop is chosen
    computeGameSummaryMetrics();

    // computeAveCoopSize();

    // computeKeepingNumbers();

    // computeExtractionNumbers();

    // computeTradePercentages();

    // considerGroupTrading();

    // vector<RoundInfo> esto = readGame("../Results/theGameLogs/log_1000_1000.csv", false);

    // Human test set (experienced)
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_BKFV.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_CHLN.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_DWMG.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_KRJP.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_LWRB.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_MCQF.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_MQCK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_NMDQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_NZKH.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_RWFL.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_SNCR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_TDRP.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_VWJH.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_WTMR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/testing_set_experienced/jhg_ZQXV.csv", true);


    // Human training set (experienced)
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BPMQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BQKP.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BZQK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_CXJR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_CZWN.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DKRV.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DNQX.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DTHW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DZJR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_FVSP.csv", true);

    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GCLQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GHBK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GJDV.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GJFD.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GSCW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GSDH.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GXVS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_HLCK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_HNCQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KBRW.csv", true);

    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KCSF.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KWMG.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KXRJ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_LZFC.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MCDL.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MCZG.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MDJS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MXGN.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_NRFS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_NTLM.csv", true);

    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_QLHS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_RPLW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_RSGK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_SHFC.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_SMBD.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TDGM.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TKRW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TSJW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VBLN.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VCNK.csv", true);

    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VSJQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VSKR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WBHQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WCJQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WQDS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WQJR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XQRT.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XTWS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XWHK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_ZRHK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_ZSLG.csv", true);


    // cout << esto.size() << endl;

    // double degree = getAveDegree(esto);
    // cout << "Average degree was " << degree << endl;

    // EconAction econ = getEconomicActionPercentages(esto);

    // cout << "Percent keep: " << (econ.keepPerc * 100.0) << endl;
    // cout << "Percent take: " << (econ.takePerc * 100.0) << endl;
    // cout << "Percent give: " << (econ.givePerc * 100.0) << endl;

    // double recip = getAveReciprocity(esto);

    // cout << "Reciprocity: " << recip << endl;

    // double clusterCoef = getClusterCoef(esto);

    // cout << "clusterCoef: " << clusterCoef << endl;

    // double polarizationCoef = getPolarizationCoef(esto);

    // cout << "polarizationCoef: " << polarizationCoef << endl;

    return 0;
}
