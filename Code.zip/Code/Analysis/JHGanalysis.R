

library('ggplot2')
require(grid)

##################

## Summarizes data.
## Gives count, mean, standard deviation, standard error of the mean, and confidence interval (default 95%).
##   data: a data frame.
##   measurevar: the name of a column that contains the variable to be summariezed
##   groupvars: a vector containing names of columns that contain grouping variables
##   na.rm: a boolean that indicates whether to ignore NA's
##   conf.interval: the percent range of the confidence interval (default is 95%)
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
                      conf.interval=.95, .drop=TRUE) {
    library(plyr)

    # New version of length which can handle NA's: if na.rm==T, don't count them
    length2 <- function (x, na.rm=FALSE) {
        if (na.rm) sum(!is.na(x))
        else       length(x)
    }

    # This does the summary. For each group's data frame, return a vector with
    # N, mean, and sd
    datac <- ddply(data, groupvars, .drop=.drop,
      .fun = function(xx, col) {
        c(N    = length2(xx[[col]], na.rm=na.rm),
          mean = mean   (xx[[col]], na.rm=na.rm),
          sd   = sd     (xx[[col]], na.rm=na.rm)
        )
      },
      measurevar
    )

    # Rename the "mean" column    
    datac <- rename(datac, c("mean" = measurevar))

    datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean

    # Confidence interval multiplier for standard error
    # Calculate t-statistic for confidence interval: 
    # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
    ciMult <- qt(conf.interval/2 + .5, datac$N-1)
    datac$ci <- datac$se * ciMult

    return(datac)
}



results_equal = read.csv('resultsLog_uniform.csv')
results_equal$Government <- factor(results_equal$Government, levels = c("None", "Prioritize equality", "Balanced priorities", "Prioritize ave. wealth", "Prioritize gov. wealth"))
p <- ggplot(results_equal, aes(x=AvePop, y=GiniIndex, color=Government, shape=Government)) +
  geom_point() + 
  theme_bw() +
  scale_shape_manual(values = c(4, 15, 16, 17, 23)) +
  scale_color_manual(values = c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00"))+
	xlab("Average Wealth") +
	ylab("Gini Index") +
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +
  scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.1)) +
  scale_x_continuous(lim=c(0,535),breaks=seq(0,500,by=100))
  # geom_point() +
  # theme_bw() 
  # stat_ellipse(type = "norm", aes(fill = Govment), geom = "polygon", alpha = 0.5)

pdf("uniform.pdf",width=5.5,height=3.3)
p
dev.off()


results_unequal = read.csv('resultsLog_unequal.csv')
results_unequal$Government <- factor(results_unequal$Government, levels = c("None", "Prioritize equality", "Balanced priorities", "Prioritize ave. wealth", "Prioritize gov. wealth"))
p <- ggplot(results_unequal, aes(x=AvePop, y=GiniIndex, color=Government, shape=Government)) +
  geom_point() + 
  theme_bw() +
  scale_shape_manual(values = c(4, 15, 16, 17, 23)) +
  scale_color_manual(values = c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00"))+
	xlab("Average Wealth") +
	ylab("Gini Index") +
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +
  scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.1)) +
  scale_x_continuous(lim=c(0,510),breaks=seq(0,500,by=100))

pdf("unequal.pdf",width=5.5,height=3.3)
p
dev.off()


results_cats = read.csv('resultsLog_cats.csv')
results_cats$Government <- factor(results_cats$Government, levels = c("None", "Prioritize equality", "Balanced priorities", "Prioritize ave. wealth", "Prioritize gov. wealth"))
p <- ggplot(results_cats, aes(x=AvePop, y=GiniIndex, color=Government, shape=Government)) +
  geom_point() + 
  theme_bw() +
  scale_shape_manual(values = c(4, 15, 16, 17, 23)) +
  scale_color_manual(values = c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00"))+
	xlab("Average Wealth") +
	ylab("Gini Index") +
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +
  scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.1)) +
  scale_x_continuous(lim=c(0,510),breaks=seq(0,500,by=100))

# p <- ggplot(results_cats, aes(x=AvePop, y=GiniIndex, color=Govment)) +
#   geom_point() + 
#   theme_bw()
  #stat_ellipse(type = "norm", aes(fill = Govment), geom = "polygon", alpha = 0.5)

pdf("cats.pdf",width=5.5,height=3.3)
p
dev.off()


results_cats = read.csv('resultsLog_cats.csv')
results_cats$total = (results_cats$AvePop*20) + results_cats$GovWealth
catsPop = summarySE(results_cats, measurevar="AvePop", groupvars=c("Government"))
catsGov = summarySE(results_cats, measurevar="GovWealth", groupvars=c("Government"))
catsTotal = summarySE(results_cats, measurevar="total", groupvars=c("Government"))
catsGini = summarySE(results_cats, measurevar="GiniIndex", groupvars=c("Government"))
catsKeep = summarySE(results_cats, measurevar="Keep", groupvars=c("Government"))
catsTake = summarySE(results_cats, measurevar="Take", groupvars=c("Government"))
catsGive = summarySE(results_cats, measurevar="Give", groupvars=c("Government"))
catsTaxes = summarySE(results_cats, measurevar="percTaxes", groupvars=c("Government"))
catsGKeep = summarySE(results_cats, measurevar="GKeep", groupvars=c("Government"))
catsGTake = summarySE(results_cats, measurevar="GTake", groupvars=c("Government"))
catsGGive = summarySE(results_cats, measurevar="GGive", groupvars=c("Government"))

results_equal = read.csv('resultsLog_uniform.csv')
results_equal$total = (results_equal$AvePop*20) + results_equal$GovWealth
equalPop = summarySE(results_equal, measurevar="AvePop", groupvars=c("Government"))
equalGov = summarySE(results_equal, measurevar="GovWealth", groupvars=c("Government"))
equalTotal = summarySE(results_equal, measurevar="total", groupvars=c("Government"))
equalGini = summarySE(results_equal, measurevar="GiniIndex", groupvars=c("Government"))
equalKeep = summarySE(results_equal, measurevar="Keep", groupvars=c("Government"))
equalTake = summarySE(results_equal, measurevar="Take", groupvars=c("Government"))
equalGive = summarySE(results_equal, measurevar="Give", groupvars=c("Government"))
equalTaxes = summarySE(results_equal, measurevar="percTaxes", groupvars=c("Government"))
equalGKeep = summarySE(results_equal, measurevar="GKeep", groupvars=c("Government"))
equalGTake = summarySE(results_equal, measurevar="GTake", groupvars=c("Government"))
equalGGive = summarySE(results_equal, measurevar="GGive", groupvars=c("Government"))

results_unequal = read.csv('resultsLog_unequal.csv')
results_unequal$total = (results_unequal$AvePop*20) + results_unequal$GovWealth
unequalPop = summarySE(results_unequal, measurevar="AvePop", groupvars=c("Government"))
unequalGov = summarySE(results_unequal, measurevar="GovWealth", groupvars=c("Government"))
unequalTotal = summarySE(results_unequal, measurevar="total", groupvars=c("Government"))
unequalGini = summarySE(results_unequal, measurevar="GiniIndex", groupvars=c("Government"))
unequalKeep = summarySE(results_unequal, measurevar="Keep", groupvars=c("Government"))
unequalTake = summarySE(results_unequal, measurevar="Take", groupvars=c("Government"))
unequalGive = summarySE(results_unequal, measurevar="Give", groupvars=c("Government"))
unequalTaxes = summarySE(results_unequal, measurevar="percTaxes", groupvars=c("Government"))
unequalGKeep = summarySE(results_unequal, measurevar="GKeep", groupvars=c("Government"))
unequalGTake = summarySE(results_unequal, measurevar="GTake", groupvars=c("Government"))
unequalGGive = summarySE(results_unequal, measurevar="GGive", groupvars=c("Government"))


scale = read.csv('resultsLog_scale.csv')
scale$Government <- factor(scale$Government, levels = c("None", "Balanced priorities"))
scale$Player <- factor(scale$Player, levels = c("p0", "p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "p10", "p11", "p12", "p13", "p14", "p15", "p16", "p17", "p18", "p19"))
scale_sum = summarySE(scale, measurevar="Popularity", groupvars=c("Government","Player"))
p <- ggplot(scale_sum, aes(x=Player, y=Popularity, fill=Government)) +
  geom_bar(position="dodge", stat = "identity") +
  geom_errorbar( aes(x=Player, ymin=Popularity-se, ymax=Popularity+se), width=0.3, position =  position_dodge(width = 0.88)) +
  theme_bw() +
	theme(axis.title.x = element_text(size = 10, face="bold"), axis.title.y = element_text(size = 10, face="bold"))+
	theme(axis.text.x = element_text(size = 6), axis.text.y = element_text(size = 7))+
	theme(legend.title = element_text(size = 9, face="bold"), legend.text = element_text(size = 9))+
  theme(legend.position="top") + 
  #scale_fill_manual(values = c("#fc8d59", "#91bfdb")) +
  # scale_fill_manual(values = c("#e41a1c","#4daf4a"))+
  scale_fill_manual(values = c("#d8b365","#5ab4ac"))+
  ylab("Final Wealth") +
  scale_y_continuous(lim=c(0,1400),breaks=seq(0,1400,by=200))

pdf("gov_impact_unequal.pdf",width=3.7,height=2.2)
p
dev.off()


coop = read.csv('coopLog_combined.csv')
#coop$total = coop$EndPop1 + coop$EndPop2 + coop$EndPop3 + coop$EndPop4 + coop$EndPop5 + coop$EndPop6 + coop$EndPop7 + coop$EndPop8 + coop$EndPop9 + coop$EndPop10 + coop$EndPop11 + coop$EndPop12 + coop$EndPop13 + coop$EndPop14 + coop$EndPop15 + coop$EndPop16 + coop$EndPop17 + coop$EndPop18 + coop$EndPop19 + coop$EndPop20 + coop$EndPopC1 + coop$EndPopC2
coop$total = coop$EndPop1 + coop$EndPop2 + coop$EndPop3 + coop$EndPop4 + coop$EndPop5 + coop$EndPop6 + coop$EndPop7 + coop$EndPop8 + coop$EndPop9 + coop$EndPop10 + coop$EndPop11 + coop$EndPop12 + coop$EndPop13 + coop$EndPop14 + coop$EndPop15 + coop$EndPop16 + coop$EndPop17 + coop$EndPop18 + coop$EndPop19 + coop$EndPop20
tot = summarySE(coop, measurevar="total", groupvars=c("hcabs"))

coop = read.csv('summary_combined.csv')
tot = summarySE(coop, measurevar="totalSW", groupvars=c("Condition"))
gini = summarySE(coop, measurevar="Gini", groupvars=c("Condition"))



# coop = read.csv('coopLog_combined.csv')
coop = read.csv('coopLog_Merit.csv')
coop$poorEndPop = coop$EndPop1 + coop$EndPop2 + coop$EndPop3 + coop$EndPop4 + coop$EndPop5 + coop$EndPop6 + coop$EndPop7 + coop$EndPop8 + coop$EndPop9 + coop$EndPop10 + coop$EndPop11 
poorEndPop = summarySE(coop, measurevar="poorEndPop", groupvars=c("hcabs"))
poorEndPop$EndPop = poorEndPop$poorEndPop / 233
poorEndPop$se = poorEndPop$se / 233
poorEndPop$poorEndPop = NULL
poorEndPop$Class = "Lower"
poorEndPop$Condition = poorEndPop$hcabs
poorEndPop$hcabs = NULL

coop$middleEndPop = coop$EndPop12 + coop$EndPop13 + coop$EndPop14 + coop$EndPop15
middleEndPop = summarySE(coop, measurevar="middleEndPop", groupvars=c("hcabs"))
middleEndPop$EndPop = middleEndPop$middleEndPop / 365
middleEndPop$se = middleEndPop$se / 365
middleEndPop$middleEndPop = NULL
middleEndPop$Class = "Middle"
middleEndPop$Condition = middleEndPop$hcabs
middleEndPop$hcabs = NULL

coop$richEndPop = coop$EndPop16 + coop$EndPop17 + coop$EndPop18 + coop$EndPop19 + coop$EndPop20
richEndPop = summarySE(coop, measurevar="richEndPop", groupvars=c("hcabs"))
richEndPop$EndPop = richEndPop$richEndPop / 1402
richEndPop$se = richEndPop$se / 1402
richEndPop$richEndPop = NULL
richEndPop$Class = "Upper"
richEndPop$Condition = richEndPop$hcabs
richEndPop$hcabs = NULL


coop = rbind(poorEndPop,middleEndPop,richEndPop)
coop$Class = factor(coop$Class, levels = c("Lower", "Middle", "Upper"))
# coop$Condition = factor(coop$Condition, levels = c("Untuned", "Tuned", "With Coops"))
coop$Condition = factor(coop$Condition, levels = c("No", "Yes"))
p <- ggplot(coop, aes(x=Class, y=EndPop, fill=Condition)) +
  geom_bar(position="dodge", stat = "identity") +
  geom_errorbar( aes(x=Class, ymin=EndPop-se, ymax=EndPop+se), width=0.3, position =  position_dodge(width = 0.88)) +
  theme_bw() +
  guides(fill=guide_legend(title="Institutions?")) +
  scale_fill_manual(values = c("#ef8a62", "#67a9cf")) +
  ylab("Economic Growth") +
  xlab("Class") +
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +  
  scale_y_continuous(lim=c(0,80),breaks=seq(0,80,by=10))

# pdf("Coop_value.pdf",width=4.0,height=2.0)
pdf("Coop_Merit.pdf",width=4.0,height=2.0)
p
dev.off()

# remove the coop stuff
nocoop = rbind(poorEndPop,middleEndPop,richEndPop)
nocoop <- subset(nocoop, Condition!="With Coops")
nocoop$Class = factor(nocoop$Class, levels = c("Lower", "Middle", "Upper"))
nocoop$Condition = factor(nocoop$Condition, levels = c("Untuned", "Tuned"))
p <- ggplot(nocoop, aes(x=Condition, y=EndPop, fill=Class)) +
  geom_bar(position="dodge", stat = "identity") +
  geom_errorbar( aes(x=Condition, ymin=EndPop-se, ymax=EndPop+se), width=0.3, position =  position_dodge(width = 0.88)) +
  theme_bw() +
  # scale_fill_manual(values = c("#1b9e77", "#d95f02")) +
  scale_fill_manual(values = c("#abd9e9", "#fdae61", "#d7191c")) +
  ylab("Growth Coefficient") +
  xlab("Condition") +
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +  
  scale_y_continuous(lim=c(0,80),breaks=seq(0,80,by=10))

pdf("noCoop_value.pdf",width=4.0,height=2.0)
p
dev.off()



coops_scatter = read.csv('summary_combined.csv')
#coops_scatter$SW = coops_scatter$SW / 1000.0
coops_scatter$Condition <- factor(coops_scatter$Condition, levels = c("Untuned", "Tuned", "With Coops"))
p <- ggplot(coops_scatter, aes(x=SW, y=Gini, color=Condition, shape=Condition)) +
  geom_point() + 
  theme_bw() +
  # scale_shape_manual(values = c(4, 15, 16, 17, 23)) +
  scale_color_manual(values = c("#1b9e77", "#d95f02", "#7570b3")) +
  # scale_color_manual(values = c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00"))+
	xlab("Average Final Wealth of Individuals") +
	ylab("Gini Index") +
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +
  scale_y_continuous(lim=c(0.2,1.0),breaks=seq(0.2,1.0,by=0.1)) + 
  scale_x_continuous(lim=c(0,10000),breaks=seq(0,10000,by=2000))
  

pdf("PropvProg.pdf",width=6.0,height=3.0)
p
dev.off()

coops_scatter = read.csv('summary_Remuneration.csv')
coops_scatter = read.csv('summary_Extractive.csv')
coops_scatter = read.csv('summary_Vengence.csv')
coops_scatter = read.csv('summary_Power.csv')
coops_scatter = read.csv('summary_PropvProg.csv')
coops_scatter = read.csv('summary_Merit.csv')

coops_scatter$everything = 1


coops_scatter$total1 = coops_scatter$poor1 + coops_scatter$middle1 + coops_scatter$rich1
coops_scatter$total2 = coops_scatter$poor2 + coops_scatter$middle2 + coops_scatter$rich2
coops_scatter$totalInd = coops_scatter$poorInd + coops_scatter$middleInd + coops_scatter$richInd

coopSum_total1 = summarySE(coops_scatter, measurevar="total1", groupvars=c("Condition"))
coopSum_total2 = summarySE(coops_scatter, measurevar="total2", groupvars=c("Condition"))
coopSum_totalInd = summarySE(coops_scatter, measurevar="totalInd", groupvars=c("Condition"))

coopSum_sw = summarySE(coops_scatter, measurevar="SW", groupvars=c("Condition"))
coopSum_gini = summarySE(coops_scatter, measurevar="Gini", groupvars=c("Condition"))

coopSum_gini = summarySE(coops_scatter, measurevar="Gini", groupvars=c("everything"))

coopSum_poor1 = summarySE(coops_scatter, measurevar="poor1", groupvars=c("Condition"))
coopSum_poor2 = summarySE(coops_scatter, measurevar="poor2", groupvars=c("Condition"))
coopSum_poorInd = summarySE(coops_scatter, measurevar="poorInd", groupvars=c("Condition"))
poor1Percent = (sum(coopSum_poor1$poor1) / 10) / 11
poor2Percent = (sum(coopSum_poor2$poor2) / 10) / 11
poorIndPercent = (sum(coopSum_poorInd$poorInd) / 10) / 11

coopSum_middle1 = summarySE(coops_scatter, measurevar="middle1", groupvars=c("Condition"))
coopSum_middle2 = summarySE(coops_scatter, measurevar="middle2", groupvars=c("Condition"))
coopSum_middleInd = summarySE(coops_scatter, measurevar="middleInd", groupvars=c("Condition"))
mid1Percent = (sum(coopSum_middle1$middle1) / 10) / 4
mid2Percent = (sum(coopSum_middle2$middle2) / 10) / 4
midIndPercent = (sum(coopSum_middleInd$middleInd) / 10) / 4

coopSum_rich1 = summarySE(coops_scatter, measurevar="rich1", groupvars=c("Condition"))
coopSum_rich2 = summarySE(coops_scatter, measurevar="rich2", groupvars=c("Condition"))
coopSum_richInd = summarySE(coops_scatter, measurevar="richInd", groupvars=c("Condition"))
rich1Percent = (sum(coopSum_rich1$rich1) / 10) / 5
rich2Percent = (sum(coopSum_rich2$rich2) / 10) / 5
richIndPercent = (sum(coopSum_richInd$richInd) / 10) / 5

all1Percent = mean(coopSum_rich1$rich1 + coopSum_middle1$middle1 + coopSum_poor1$poor1) / 20
all2Percent = mean(coopSum_rich2$rich2 + coopSum_middle2$middle2 + coopSum_poor2$poor2) / 20
allIndPercent = mean(coopSum_richInd$richInd + coopSum_middleInd$middleInd + coopSum_poorInd$poorInd) / 20

coopSum_aveCoop1 = summarySE(coops_scatter, measurevar="aveCoop1", groupvars=c("Condition"))
coopSum_aveCoop2 = summarySE(coops_scatter, measurevar="aveCoop2", groupvars=c("Condition"))

coopSum_totalWealth = summarySE(coops_scatter, measurevar="totalSW", groupvars=c("Condition"))

coopSum_totalWealth = summarySE(coops_scatter, measurevar="totalSW", groupvars=c("everything"))

coops_scatter$one = 1
coopSum_totalWealth_t = summarySE(coops_scatter, measurevar="totalSW", groupvars=c("one"))
coopSum_gini_t = summarySE(coops_scatter, measurevar="Gini", groupvars=c("one"))
coopSum_sw_t = summarySE(coops_scatter, measurevar="SW", groupvars=c("one"))

# get the percentage of power held by each institution in the end
coop = read.csv('coopLog_Merit.csv')
coop$agentTotal = coop$EndPop1 + coop$EndPop2 + coop$EndPop3 + coop$EndPop4 + coop$EndPop5 + coop$EndPop6 + coop$EndPop7 + coop$EndPop8 + coop$EndPop9 + coop$EndPop10 + coop$EndPop11 + coop$EndPop12 + coop$EndPop13 + coop$EndPop14 + coop$EndPop15 + coop$EndPop16 + coop$EndPop17 + coop$EndPop18 + coop$EndPop19 + coop$EndPop20
coop$total = coop$agentTotal + coop$EndPopC1 + coop$EndPopC2
coop$PercC1 = coop$EndPopC1 / coop$total
coop$PercC2 = coop$EndPopC2 / coop$total
percC1 = summarySE(coop, measurevar="PercC1", groupvars=c("hcabs"))
percC2 = summarySE(coop, measurevar="PercC2", groupvars=c("hcabs"))



sum50 = read.csv('summary_1.csv')
sum(sum50$poorM) / sum(sum50$poorMCount)
sum(sum50$poorNM) / sum(sum50$poorNMCount)
sum(sum50$middleM) / sum(sum50$middleMCount)
sum(sum50$middleNM) / sum(sum50$middleNMCount)
sum(sum50$richM) / sum(sum50$richMCount)
sum(sum50$richNM) / sum(sum50$richNMCount)


sum25 = read.csv('summary_2.csv')
sum(sum25$poorM) / sum(sum25$poorMCount)
sum(sum25$poorNM) / sum(sum25$poorNMCount)
sum(sum25$middleM) / sum(sum25$middleMCount)
sum(sum25$middleNM) / sum(sum25$middleNMCount)
sum(sum25$richM) / sum(sum25$richMCount)
sum(sum25$richNM) / sum(sum25$richNMCount)


initPops = read.csv('initialPops_unequal.csv')
initPops$Player <- factor(initPops$Player, levels = c("p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "p10", "p11", "p12", "p13", "p14", "p15", "p16", "p17", "p18", "p19", "p20"))
p <- ggplot(initPops, aes(x=Player, y=Popularity)) +
  geom_bar(position="dodge", stat = "identity") +
  theme_bw() +
  #scale_fill_manual(values = c("#1b9e77", "#d95f02", "#7570b3")) +
  ylab("Initial Wealth") +
  xlab("") +
  theme(axis.text.x = element_text(size = 6), axis.text.y = element_text(size = 6))+
	theme(axis.title.x = element_text(size = 7, face="bold"), axis.title.y = element_text(size = 7, face="bold"))+
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +  
  scale_y_continuous(lim=c(0,450),breaks=seq(0,450,by=100))

pdf("initPops_unequal.pdf",width=3.5,height=1.0)
p
dev.off()


initPops = read.csv('initialPops_unequal.csv')
initPops$Type <- c("a","a","a","a","a","a","a","a","a","a","a","b","b","b","b","c","c","c","c","c")
initPops$Player <- factor(initPops$Player, levels = c("p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "p10", "p11", "p12", "p13", "p14", "p15", "p16", "p17", "p18", "p19", "p20"))
p <- ggplot(initPops, aes(x=Player, y=Popularity, fill=Type)) +
  geom_bar(position="dodge", stat = "identity") +
  theme_bw() +
  scale_fill_manual(values = c("#abd9e9", "#fdae61", "#d7191c")) +
  theme(legend.position="none")+
  ylab("Initial Wealth") +
  xlab("") +
  theme(axis.text.x = element_text(size = 6), axis.text.y = element_text(size = 6))+
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +  
  scale_y_continuous(lim=c(0,450),breaks=seq(0,450,by=100))

pdf("initPops_unequal_classes.pdf",width=3.5,height=1.8)
p
dev.off()


initPops = read.csv('initialPops_equal.csv')
initPops$Player <- factor(initPops$Player, levels = c("p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "p10", "p11", "p12", "p13", "p14", "p15", "p16", "p17", "p18", "p19", "p20"))
p <- ggplot(initPops, aes(x=Player, y=Popularity)) +
  geom_bar(position="dodge", stat = "identity") +
  theme_bw() +
  #scale_fill_manual(values = c("#1b9e77", "#d95f02", "#7570b3")) +
  ylab("Initial Wealth") +
  xlab("") +
  theme(axis.text.x = element_text(size = 6), axis.text.y = element_text(size = 6))+
	theme(axis.title.x = element_text(size = 7, face="bold"), axis.title.y = element_text(size = 7, face="bold"))+
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +  
  scale_y_continuous(lim=c(0,120),breaks=seq(0,120,by=20))

pdf("initPops_equal.pdf",width=3.5,height=1.0)
p
dev.off()


initPops = read.csv('initialPops_equal_cats.csv')
initPops$Type <- c("p","p","p","p","p","p","p","p","p","p","p","p","p","p","p","p","c","c","c","c")
initPops$Player <- factor(initPops$Player, levels = c("p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "p10", "p11", "p12", "p13", "p14", "p15", "p16", "c1", "c2", "c3", "c4"))
p <- ggplot(initPops, aes(x=Player, y=Popularity, fill=Type)) +
  geom_bar(position="dodge", stat = "identity") +
  theme_bw() +
  scale_fill_manual(values = c("red","#555555")) +
  ylab("Initial Wealth") +
  xlab("") +
  theme(axis.text.x = element_text(size = 6), axis.text.y = element_text(size = 6))+
	theme(axis.title.x = element_text(size = 7, face="bold"), axis.title.y = element_text(size = 7, face="bold"))+
  theme(legend.position="none")+
  theme(axis.title.x = element_text(face="bold")) +
  theme(axis.title.y = element_text(face="bold")) +
  theme(legend.title = element_text(face = "bold")) +  
  scale_y_continuous(lim=c(0,120),breaks=seq(0,120,by=20))

pdf("initPops_equal_cats.pdf",width=3.5,height=1.0)
p
dev.off()



giniGrowth = read.csv('gini_growth.csv')
giniGrowth$AvePop = giniGrowth$AvePop / 100.0
gini_growth_sum = summarySE(giniGrowth, measurevar="AvePop", groupvars=c("StartGini"))
p <- ggplot(gini_growth_sum, aes(x=StartGini, y=AvePop)) +
	geom_line(color="blue") +
  geom_point(color="blue") +
  geom_ribbon(aes(ymin=AvePop-se, ymax=AvePop+se, x=StartGini), alpha = 0.3, fill="blue", color=NA)+
	theme_bw() +
  # scale_fill_manual(values=c('blue')) +
  # scale_color_manual(values=c('blue')) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold"))+
	theme(axis.text.x = element_text(size = 10), axis.text.y = element_text(size = 10))+
	# theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Starting Gini Index") +
	ylab("Economic Growth") +
  # guides(color = guide_legend(title = "Player Type")) +
  # scale_color_manual(values=c(catcolor,hcabcolor)) +  # color brewer
  # scale_y_continuous(lim=c(0,300),breaks=seq(0,300,by=100))
  scale_y_continuous(lim=c(0,5),breaks=seq(0,5,by=1))+
  scale_x_continuous(lim=c(0,0.9),breaks=seq(0,0.9,by=0.1))

pdf("gini_growth.pdf",width=4.0,height=2.0)
p
dev.off()



#  pastel colors
# catcolor = "#d9989e"
# schmusrcolor = "#9ed9ab"
# hcabcolor = "#9ebfd9"

# red, black, blue scheme
catcolor = "#ca0020"
schmusrcolor = "#2c7bb6"
hcabcolor = "#404040"

hCABsvsCATs = read.csv('Results/hCABsvsCATs_1_pops.csv')
p <- ggplot(hCABsvsCATs, aes(x=Round, y=Popularity, color=Type, Fill=Agent)) +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Round") +
	ylab("Popularity") +
  guides(color = guide_legend(title = "Player Type")) +
  # scale_color_manual(values=c("#d7191c","#2c7bb6")) +  # blue color
  # scale_color_manual(values=c("#d7191c","#edb087")) +  # melissa's color
  # scale_color_manual(values=c("#d95f02","#7570b3")) +  # color brewer
  # scale_color_manual(values=c("#ca0020","#404040")) +  # color brewer
  scale_color_manual(values=c(catcolor,hcabcolor)) +  # color brewer
  scale_y_continuous(lim=c(0,300),breaks=seq(0,300,by=100))

pdf("hCABsvsCATs_1.pdf",width=4.5,height=2.3)
p
dev.off()


hCABsvsCATs = read.csv('Results/hcab-schmusr_62_pops.csv')
p <- ggplot(hCABsvsCATs, aes(x=Round, y=Popularity, color=Type, Fill=Agent)) +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Round") +
	ylab("Popularity") +
  guides(color = guide_legend(title = "Player Type")) +
  # scale_color_manual(values=c('Blue','Red')) +
  # scale_color_manual(values=c("#ffd3b6","#a8e6cf")) +
  # scale_color_manual(values=c("#ef8a62","#67a9cf")) +
  # scale_color_manual(values=c("#dfc27d","#80cdc1")) +
  # scale_color_manual(values=c("#d7191c","#2c7bb6")) +
  # scale_color_manual(values=c("#404040","#2c7bb6")) +
  scale_color_manual(values=c(hcabcolor,schmusrcolor)) +
  # scale_linetype_manual(values=c(0, 1))
  scale_y_continuous(lim=c(0,900),breaks=seq(0,1000,by=200))

pdf("hcab-schmusr_62.pdf",width=4.0,height=2.3)
p
dev.off()


hCABsvsCATs = read.csv('Results/HnoFnoC_vsCATs_0_pops.csv')
p <- ggplot(hCABsvsCATs, aes(x=Round, y=Popularity, color=Type, Fill=Agent)) +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Round") +
	ylab("Popularity") +
  guides(color = guide_legend(title = "Player Type")) +
  # scale_color_manual(values=c("#d7191c","#2c7bb6")) +  # blue color
  # scale_color_manual(values=c("#d7191c","#90decc")) +  # melissa's color
  # scale_color_manual(values=c("#d95f02","#1b9e77")) +  # color brewer
  # scale_color_manual(values=c("#ca0020","#2c7bb6")) +  # color brewer
  scale_color_manual(values=c(catcolor,schmusrcolor)) +  # color brewer
  scale_y_continuous(lim=c(0,300),breaks=seq(0,300,by=100))

pdf("HnoFnoC_vsCATs_0.pdf",width=4.5,height=2.3)
p
dev.off()


game_scripted = read.csv('Results/game_scripted_pops.csv')
p <- ggplot(game_scripted, aes(x=Round, y=Popularity, color=Type, Fill=Agent)) +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Round") +
	ylab("Popularity") +
  guides(color = guide_legend(title = "Player Type")) +
  # scale_color_manual(values=c('Blue','Red','Green','Orange','Black','Gray')) +
  scale_color_manual(values=c('#3773b8','#e41a1c','#4daf4a','#ff7f00','#a65628','#984ea3')) +
  theme(legend.position="none")+
  scale_x_continuous(lim=c(0,6.5),breaks=seq(0,6,by=1))
  scale_y_continuous(lim=c(0,200),breaks=seq(0,200,by=50))

pdf("game_scripted.pdf",width=3.5,height=2.3)
p
dev.off()




govPrefs = read.csv('csvs/govPref.csv')
govPref_Z = summarySE(govPrefs, measurevar="Z", groupvars=c("Class"))
govPref_I = summarySE(govPrefs, measurevar="I", groupvars=c("Class"))
govPref_E = summarySE(govPrefs, measurevar="E", groupvars=c("Class"))
govPref_G = summarySE(govPrefs, measurevar="G", groupvars=c("Class"))



humanBotPop_all = read.csv('csvs/popularities.csv')
humanBotPop <- subset(humanBotPop_all, Round=="21")
humanBotPop_sum <- summarySE(humanBotPop, measurevar="Popularity", groupvars=c("Condition","Type"))
humanBotPop_all <- summarySE(humanBotPop, measurevar="Popularity", groupvars=c("Type"))
humanBotPop_all$Condition <- c("All","All")

hBPop = rbind(humanBotPop_sum, humanBotPop_all)

p <- ggplot(hBPop, aes(x=Condition, y=Popularity, fill=Type)) + 
    geom_col(position=position_dodge(0.8), width=0.8, colour="black", size=.3) +
    geom_errorbar(aes(ymin=Popularity-se, ymax=Popularity+se), size=.3, width=.2, position=position_dodge(.8)) +
    xlab("Study Condition") +
    ylab("Ave. Popularity (t = 21)") +
    theme_bw() + 
	theme(legend.position="top") +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 10), axis.text.y = element_text(size = 10))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
  scale_fill_manual(values=c('#F47C6F','#34BDC5')) +
  scale_y_continuous(lim=c(0,270),breaks=seq(0,250,by=50))

pdf("EndingPops.pdf",width=3.6,height=2.8)
p
dev.off()


res.aov2 <- aov(Popularity ~ Condition + Type, data = humanBotPop)
summary(res.aov2)

res.aov2 <- aov(Popularity ~ Type, data = humanBotPop)
summary(res.aov2)



p <- ggplot(humanBotPop, aes(x=Popularity, color=Type, fill=Type)) +
  geom_histogram(alpha=0.5, position="identity",binwidth=33.33)+
  xlab("Final Popularity (t=21)") +
  ylab("Count") +
  theme_bw() + 
	theme(legend.position="top") +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 10), axis.text.y = element_text(size = 10))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
  scale_fill_manual(values=c('#F47C6F','#34BDC5')) +
  scale_color_manual(values=c('#F47C6F','#34BDC5')) +
  scale_y_continuous(lim=c(0,12),breaks=seq(0,12,by=2))# +
  #scale_x_continuous(breaks=seq(0,400,by=100))
  #geom_histogram(fill="white", position=position_dodge(0.8), width=0.8)

pdf("FinalPops_Histo.pdf",width=2.6,height=2.8)
p
dev.off()



humanBotPopularities = read.csv('csvs/popularities.csv')
humanBotPop_all <- summarySE(humanBotPopularities, measurevar="Popularity", groupvars=c("Type","Round"))

p <- ggplot(humanBotPop_all, aes(x=Round, y=Popularity, color=Type, fill=Type)) +
	geom_point() +
	geom_line() +
	theme_bw() +
  theme(legend.position="top") +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 10), axis.text.y = element_text(size = 10))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Round") +
  ylab("Average Popularity") +
	#ylab("Average Popularity\n(all conditions)") +
  scale_fill_manual(values=c('#F47C6F','#34BDC5')) +
  scale_color_manual(values=c('#F47C6F','#34BDC5')) +
	geom_ribbon(aes(ymin=Popularity-se, ymax=Popularity+se, x=Round), alpha = 0.2, color=NA)+
  scale_y_continuous(lim=c(0,260),breaks=seq(0,250,by=50))

pdf("AvePops.pdf",width=2.6,height=2.6)
p
dev.off()


humanBotTokens = read.csv('csvs/allocations.csv')
humanBotTokens_sum <- summarySE(humanBotTokens, measurevar="Proportion", groupvars=c("Transaction","Type"))

p <- ggplot(humanBotTokens_sum, aes(x=Type, y=Proportion, fill=Transaction)) + 
    geom_col(position=position_dodge(0.8), width=0.8, colour="black", size=.3) +
    geom_errorbar(aes(ymin=Proportion-se, ymax=Proportion+se), size=.3, width=.2, position=position_dodge(.8)) +
    xlab("Player Type") +
    ylab("Proportion of Tokens") +
    theme_bw() + 
    theme(legend.position="top") +
    theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
    theme(axis.text.x = element_text(size = 11), axis.text.y = element_text(size = 11))+
    theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
    scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.2))

pdf("Transactions.pdf",width=4.0,height=2.5)
p
dev.off()



humanBotTokensWho = read.csv('csvs/allocationsWho.csv')
humanBotTokensWho_sum <- summarySE(humanBotTokensWho, measurevar="Amount", groupvars=c("Type","Who"))


humanBotAmigos = read.csv('csvs/amigos.csv')
humanBotAmigos_sum <- summarySE(humanBotAmigos, measurevar="numFriends", groupvars=c("Type","Round"))

p <- ggplot(humanBotAmigos_sum, aes(x=Round, y=numFriends, color=Type, fill=Type)) +
	geom_point() +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Round") +
	ylab("Ave. # of Friends\n(all conditions)") +
	geom_ribbon(aes(ymin=numFriends-se, ymax=numFriends+se, x=Round), alpha = 0.2, color=NA)+
  scale_y_continuous(lim=c(0,4),breaks=seq(0,4,by=0.5))

pdf("AveFriends.pdf",width=4.5,height=3.0)
p
dev.off()


humanBotAmigosWho = read.csv('csvs/amigosWho.csv')
humanBotAmigosWho_sum <- summarySE(humanBotAmigosWho, measurevar="Percent", groupvars=c("Type","Who"))

humanBotAmigosAmount = read.csv('csvs/amigosStrength.csv')
humanBotAmigosAmount_sum <- summarySE(humanBotAmigosAmount, measurevar="Amount", groupvars=c("Type","Who"))


CAB_hand_thief = read.csv('csvs/thiefExample_handcoded.csv')
p <- ggplot(CAB_hand_thief, aes(x=Round, y=Popularity, color=Type, Fill=Agent)) +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Round") +
	ylab("Popularity") +
  guides(color = guide_legend(title = "Player Type")) +
  scale_color_manual(values=c('Blue','Red')) +
  scale_y_continuous(lim=c(0,450),breaks=seq(0,400,by=100))

pdf("Thieves_handcoded.pdf",width=3.5,height=1.8)
p
dev.off()


CAB_hand_thief = read.csv('csvs/thiefExample_3_varied.csv')
p <- ggplot(CAB_hand_thief, aes(x=Round, y=Popularity, color=Type, Fill=Agent)) +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Round") +
	ylab("Popularity") +
  guides(color = guide_legend(title = "Player Type")) +
  scale_color_manual(values=c('Blue','Red')) +
  scale_y_continuous(lim=c(0,450),breaks=seq(0,400,by=100))

pdf("Thieves_v3.pdf",width=3.5,height=1.8)
p
dev.off()


welfare_vs_gini = read.csv('csvs/welfare_gini_scatter.csv')

p <- ggplot(welfare_vs_gini, aes(x=Welfare, y=Gini, color=Condition, shape=Condition)) +
	geom_point(size=2.5) +
	theme_bw() +
  #theme(legend.position="top") +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 10), axis.text.y = element_text(size = 10))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Social Welfare") +
	ylab("Gini Index")

pdf("welfare_vs_gini.pdf",width=4.0,height=2.8)
p
dev.off()



socialWelfare = read.csv('csvs/trends.csv')
social <- summarySE(socialWelfare, measurevar="SocialWelfare", groupvars=c("Generation_Config","Round"))


# p <- ggplot(social, aes(x=Generation, y=Value)) +
# 	geom_point() +
# 	geom_line() +
# 	theme_bw() +
# #	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
# #	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
# #	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
# #	xlab("% Mission Time Elapsed") +
# #	ylab("Predicted Success Probability") +
# 	geom_ribbon(aes(ymin=Value-se, ymax=Value+se, x=Generation), alpha = 0.2, color=NA)#+
# 	#scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.25))


homophilyCats = read.csv('csvs/homophilyCategories11_all.csv')
homophily <- summarySE(homophilyCats, measurevar="Proportion", groupvars=c("Generation","Category"))

p <- ggplot(homophily, aes(x=Generation, y=Proportion, color=Category, fill=Category)) +
	geom_point() +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Generation") +
	ylab("Proportion of Population") +
	geom_ribbon(aes(ymin=Proportion-se, ymax=Proportion+se, x=Generation), alpha = 0.2, color=NA)+
  scale_y_continuous(lim=c(0,1),breaks=seq(0,1,by=0.2))

pdf("figs/homophilyCategories.pdf",width=5.8,height=3.0)
p
dev.off()



generalTrends = read.csv('csvs/generalTrends11_all.csv')
socWel = subset(generalTrends, Item=="socialWelfare")
social <- summarySE(socWel, measurevar="Value", groupvars=c("Generation"))
social$Item = "socialWelfare"

p <- ggplot(social, aes(x=Generation, y=Value, color=Item, fill=Item)) +
	geom_point() +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
  theme(legend.position="none")+
	# theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Generation") +
	ylab("Ave Popularity After 40 Rounds") +
	geom_ribbon(aes(ymin=Value-se, ymax=Value+se, x=Generation), alpha = 0.2, color=NA)+
	scale_y_continuous(lim=c(0,530),breaks=seq(0,500,by=100))

pdf("figs/socialWelfare.pdf",width=5.8,height=3.4)
p
dev.off()


generalTrends = read.csv('csvs/generalTrends11_all.csv')
giniInd = subset(generalTrends, Item=="giniIndex")
gini <- summarySE(giniInd, measurevar="Value", groupvars=c("Generation"))
gini$Item = "giniIndex"

p <- ggplot(gini, aes(x=Generation, y=Value, color=Item, fill=Item)) +
	geom_point() +
	geom_line() +
	theme_bw() +
	theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
	theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
  theme(legend.position="none")+
	# theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
	xlab("Generation") +
	ylab("Gini Index After 40 Rounds") +
	geom_ribbon(aes(ymin=Value-se, ymax=Value+se, x=Generation), alpha = 0.2, color=NA)+
	scale_y_continuous(lim=c(0,1),breaks=seq(0,1,by=0.2))

pdf("figs/giniIndex.pdf",width=5.8,height=3.4)
p
dev.off()


tokenAllocs = read.csv('csvs/generalTokenAllocs.csv')
tokenAve <- summarySE(tokenAllocs, measurevar="Proportion", groupvars=c("Generation","Type"))

p <- ggplot(tokenAve, aes(x=Generation, y=Proportion, color=Type, fill=Type)) +
    geom_point() +
    geom_line() +
    theme_bw() +
    theme(axis.title.x = element_text(size = 13, face="bold"), axis.title.y = element_text(size = 13, face="bold"))+
    theme(axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12))+
    theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10))+
    xlab("Generation") +
    ylab("Proportion of Tokens Used") +
    geom_ribbon(aes(ymin=Proportion-se, ymax=Proportion+se, x=Generation), alpha = 0.2, color=NA)+
    scale_y_continuous(lim=c(0,1),breaks=seq(0,1,by=0.2))

pdf("figs/generalTokenAllocs.pdf",width=4.8,height=3.0)
p
dev.off()



master = read.csv('csvs/HomophilyTest.csv')
master2 = subset(master, VisibleTrait!="Mutated-None")
aves <- summarySE(master2, measurevar="Popularity", groupvars=c("Who","VisibleTrait"))

p <- ggplot(aves, aes(x=Who, y=Popularity, fill=VisibleTrait)) + 
    geom_col(position=position_dodge(0.8), width=0.8, colour="black", size=.3) +
    geom_errorbar(aes(ymin=Popularity-se, ymax=Popularity+se), size=.3, width=.2, position=position_dodge(.8)) +
    xlab("") +
    ylab("Average Popularity") +
    theme_bw() + 
    theme(legend.position="top") +
    theme(axis.title.x = element_text(size = 14, face="bold"), axis.title.y = element_text(size = 14, face="bold"))+
    theme(axis.text.x = element_text(size = 14, face="bold"), axis.text.y = element_text(size = 14))+
    theme(legend.title = element_text(size = 12, face="bold"), legend.text = element_text(size = 12))#+
    #scale_fill_manual(values=c('#a6611a','#dfc27d','#80cdc1','#018571'))+
    #scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.2))

pdf("figs/HomophilyImpact.pdf",width=4.5,height=3.0)
p
dev.off()


master = read.csv('csvs/player11Test.csv')
master2 = subset(master, Player=="Player11")
aves <- summarySE(master2, measurevar="Popularity", groupvars=c("Player11","Generation","Player"))
p <- ggplot(aves, aes(x=Generation, y=Popularity, fill=Player11)) + 
    geom_col(position=position_dodge(0.8), width=0.8, colour="black", size=.3) +
    geom_errorbar(aes(ymin=Popularity-se, ymax=Popularity+se), size=.3, width=.2, position=position_dodge(.8)) +
    xlab("") +
    ylab("Average Popularity") +
    theme_bw() + 
    theme(legend.position="top") +
    theme(axis.title.x = element_text(size = 14, face="bold"), axis.title.y = element_text(size = 14, face="bold"))+
    theme(axis.text.x = element_text(size = 14, face="bold"), axis.text.y = element_text(size = 14))+
    theme(legend.title = element_text(size = 12, face="bold"), legend.text = element_text(size = 12))#+
    #scale_fill_manual(values=c('#a6611a','#dfc27d','#80cdc1','#018571'))+
    #scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.2))

pdf("figs/HumanVsBot_gen.pdf",width=4.5,height=3.0)
p
dev.off()


master = read.csv('csvs/player11Test.csv')
master2 = subset(master, Player=="Player11")
aves2 <- summarySE(master2, measurevar="Popularity", groupvars=c("Player11","Configuration","Player"))
p <- ggplot(aves2, aes(x=Configuration, y=Popularity, fill=Player11)) + 
    geom_col(position=position_dodge(0.8), width=0.8, colour="black", size=.3) +
    geom_errorbar(aes(ymin=Popularity-se, ymax=Popularity+se), size=.3, width=.2, position=position_dodge(.8)) +
    xlab("") +
    ylab("Average Popularity") +
    theme_bw() + 
    theme(legend.position="top") +
    theme(axis.title.x = element_text(size = 14, face="bold"), axis.title.y = element_text(size = 14, face="bold"))+
    theme(axis.text.x = element_text(size = 14, face="bold"), axis.text.y = element_text(size = 14))+
    theme(legend.title = element_text(size = 12, face="bold"), legend.text = element_text(size = 12))#+
    #scale_fill_manual(values=c('#a6611a','#dfc27d','#80cdc1','#018571'))+
    #scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.2))

pdf("figs/HumanVsBot_config.pdf",width=4.5,height=3.0)
p
dev.off()


master = read.csv('csvs/numFriends.csv')
aves <- summarySE(master, measurevar="Friends", groupvars=c("Generation"))
p <- ggplot(aves, aes(x=Generation, y=Friends)) + 
    geom_point() +
    geom_line() +
    geom_ribbon(aes(ymin=Friends-se, ymax=Friends+se, x=Generation), alpha = 0.2, color=NA)+
    xlab("Generation") +
    ylab("Average Number of Friends") +
    theme_bw() + 
    theme(axis.title.x = element_text(size = 14, face="bold"), axis.title.y = element_text(size = 14, face="bold"))+
    theme(axis.text.x = element_text(size = 14, face="bold"), axis.text.y = element_text(size = 14))






master_Priority = read.csv('csvs/priorities.csv')

p <- ggplot(master_Priority, aes(x=Round, y=Value, color=Item)) +
  geom_line() +
  # geom_point(aes(shape=Gene)) +
  theme_bw()

master_Takers = read.csv('csvs/takers.csv')

p <- ggplot(master_Takers, aes(x=Round, y=Value, color=Item)) +
  geom_line() +
  # geom_point(aes(shape=Gene)) +
  theme_bw()





master_SW = read.csv('csvs/socialWelfare3.csv')
p <- ggplot(master_SW, aes(x=Round, y=Value, color=Item)) +
  geom_line() +
  # geom_point(aes(shape=Gene)) +
  theme_bw()

pdf("figs/socialWelfare3.pdf",width=6.1,height=2.5)
p
dev.off()

master_SW = read.csv('csvs/visualCounts3.csv')
p <- ggplot(master_SW, aes(x=Round, y=Value, color=Item)) +
  geom_line() +
  # geom_point(aes(shape=Gene)) +
  theme_bw() +
	xlab("Generation") +
	ylab("Proportion of Population")

pdf("figs/visualCounts3.pdf",width=5.0,height=3.0)
p
dev.off()



master_SW = read.csv('csvs/homophily3.csv')
p <- ggplot(master_SW, aes(x=Round, y=Value, color=Preference)) +
  geom_line() +
  # geom_point(aes(shape=Gene)) +
  theme_bw() +
  theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +  
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
	xlab("Generation") +
	ylab("Proportion of Population") +
  scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.2))

pdf("figs/homophily3.pdf",width=4.5,height=2.5)
p
dev.off()


master_SW = read.csv('csvs/visualCounts3b.csv')
p <- ggplot(master_SW, aes(x=Round, y=Value, color=Visual_Trait)) +
  geom_line() +
  # geom_point(aes(shape=Gene)) +
  theme_bw() +
  theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +  
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
	xlab("Generation") +
	ylab("Proportion of Population") +
  scale_color_discrete(name = "Visual Trait")
  scale_y_continuous(lim=c(0,1.0),breaks=seq(0,1.0,by=0.2))

pdf("figs/visualCounts3b.pdf",width=4.5,height=2.5)
p
dev.off()








master_SW = read.csv('csvs/socialWelfare.csv')
master_Takers = read.csv('csvs/takers.csv')

p <- ggplot() +
  geom_line(mapping = aes(x = master_Takers$Round, y = master_Takers$Value), color=master_Takers$Item)) +
  geom_line(mapping = aes(x = master_SW$Round, y = master_SW$Value)) +
  scale_x_date(name = "Generation") +
  scale_y_continuous(name = "Gene Value", 
    sec.axis = sec_axis(~./5, name = "Average Player Popularity", 
      labels = function(b) { paste0(round(b * 100, 0), "%")}))




















# plot gene values of scenario 1
master = read.csv('../Evolution/processedData/theGenerations_RKGS_means.csv')
master_values = subset(master, Gene!="popAve")
master_values = subset(master_values, Gene!="Bestie")
master_values = subset(master_values, Gene!="Influence")
master_values = subset(master_values, Gene!="Vigilante")
master_values$Gene <- factor(master_values$Gene, levels = c("Keep", "Steal", "Reciprocate", "Predator"))

p <- ggplot(master_values, aes(x=Generation, y=Value, color=Gene)) +
  geom_line() +
  geom_point(aes(shape=Gene)) +
  theme_bw() +
  #theme(legend.position="top") +
  ggtitle("Scenario 1") +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  #scale_color_manual(values = c("#a6611a", "#dfc27d", "#80cdc1", "#018571")) +
  scale_color_manual(values = c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3")) +
	xlab("Generation") +
	ylab("Average Gene Value") +
  scale_y_continuous(lim=c(0,9),breaks=seq(0,9,by=1)) +
  scale_x_continuous(lim=c(1,30),breaks=seq(1,30,by=1))

pdf("figs/PopulationDynamics_predators.pdf",width=6.1,height=2.5)
p
dev.off()


# plot gene values of scenario 2
master = read.csv('../Evolution/processedData/theGenerations_RKGSP_means.csv')
master_values = subset(master, Gene!="popAve")
master_values = subset(master_values, Gene!="Bestie")
master_values = subset(master_values, Gene!="Influence")
master_values$Gene <- factor(master_values$Gene, levels = c("Keep", "Steal", "Reciprocate", "Predator", "Vigilante"))

p <- ggplot(master_values, aes(x=Generation, y=Value, color=Gene)) +
  geom_line() +
  geom_point(aes(shape=Gene)) +
  theme_bw() +
  ggtitle("Scenario 2") +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  #scale_color_manual(values = c("#a6611a", "#dfc27d", "#80cdc1", "#018571")) +
  scale_color_manual(values = c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00")) +
	xlab("Generation") +
	ylab("Average Gene Value") +
  scale_y_continuous(lim=c(0,9),breaks=seq(0,9,by=1)) +
  scale_x_continuous(lim=c(1,30),breaks=seq(1,30,by=1))

pdf("figs/PopulationDynamics_vigilantes.pdf",width=6.1,height=2.5)
p
dev.off()


# plot gene values of scenario 3
master = read.csv('../Evolution/processedData/theGenerations_chaos_means.csv')
master_values = subset(master, Gene!="popAve")
master_values = subset(master_values, Gene!="Bestie")
master_values = subset(master_values, Gene!="Influence")
master_values$Gene <- factor(master_values$Gene, levels = c("Keep", "Steal", "Reciprocate", "Predator", "Vigilante"))

p <- ggplot(master_values, aes(x=Generation, y=Value, color=Gene)) +
  geom_line() +
  geom_point(aes(shape=Gene)) +
  theme_bw() +
  ggtitle("Scenario 3") +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  #scale_color_manual(values = c("#a6611a", "#dfc27d", "#80cdc1", "#018571")) +
  scale_color_manual(values = c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00")) +
	xlab("Generation") +
	ylab("Average Gene Value") +
  scale_y_continuous(lim=c(0,9),breaks=seq(0,9,by=1)) +
  scale_x_continuous(lim=c(1,30),breaks=seq(1,30,by=1))

pdf("figs/PopulationDynamics_chaos.pdf",width=6.1,height=2.5)
p
dev.off()


# plot average population wealth
master1 = read.csv('../Evolution/processedData/theGenerations_RKGS_means.csv')
master2 = read.csv('../Evolution/processedData/theGenerations_RKGSP_means.csv')
master3 = read.csv('../Evolution/processedData/theGenerations_chaos_means.csv')

master1 = subset(master1, Gene=="popAve")
master1$Scenario = "Scenario 1"
master2 = subset(master2, Gene=="popAve")
master2$Scenario = "Scenario 2"
master3 = subset(master3, Gene=="popAve")
master3$Scenario = "Scenario 3"

master = rbind(master1, master2, master3)

p <- ggplot(master, aes(x=Generation, y=Value, color=Scenario)) +
  geom_line(aes(linetype=Scenario)) +
  geom_point(aes(shape=Scenario)) +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  #scale_color_manual(values = c("#a6611a", "#dfc27d", "#80cdc1", "#018571")) +
  #scale_color_manual(values = c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00")) +
	xlab("Generation") +
	ylab("Average Popularity") +
  scale_y_continuous(lim=c(0,55),breaks=seq(0,55,by=10)) +
  scale_x_continuous(lim=c(1,30),breaks=seq(0,30,by=5))

pdf("figs/Wealth.pdf",width=4.0,height=2.5)
p
dev.off()



Random = "#1b9377"
Keeper = "#d95f02"
Reciprocator = "#7570b3"
Predator = "#e7298a"
Vigilante = "#66a61e"


master = read.csv('../Evolution/processedData/popChart_RKGS_1.csv')
master = subset(master,Time<31)

p <- ggplot(master, aes(x=Time, y=Popularity, color=Label)) +
	#geom_point() +
	geom_line(aes(linetype=Index)) +
	theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  scale_linetype_manual(values = c(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), guide="none") +
  scale_color_manual(values = c(Keeper, Random)) +
	xlab("Round") +
	ylab("Popularity") +
  labs(color="Player label") +
  scale_x_continuous(lim=c(0,30),breaks=seq(0,30,by=5)) +
  scale_y_continuous(lim=c(0,2),breaks=seq(0,2,by=1))

pdf("figs/popChart_RKGS_1.pdf",width=5.0,height=3.2)
p
dev.off()


master = read.csv('../Evolution/processedData/popChart_RKGS_5.csv')
master = subset(master,Time<31)

p <- ggplot(master, aes(x=Time, y=Popularity, color=Label)) +
	#geom_point() +
	geom_line(aes(linetype=Index)) +
	theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  scale_linetype_manual(values = c(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), guide="none") +
  scale_color_manual(values = c(Keeper, Random)) +
	xlab("Round") +
	ylab("Popularity") +
  labs(color="Player label") +
  scale_x_continuous(lim=c(0,30),breaks=seq(0,30,by=5)) +
  scale_y_continuous(lim=c(0,2),breaks=seq(0,2,by=1))

pdf("figs/popChart_RKGS_5.pdf",width=5.0,height=3.2)
p
dev.off()


master = read.csv('../Evolution/processedData/popChart_RKGS_10.csv')
master = subset(master,Time<31)

p <- ggplot(master, aes(x=Time, y=Popularity, color=Label)) +
	#geom_point() +
	geom_line(aes(linetype=Index)) +
	theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  scale_linetype_manual(values = c(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), guide="none") +
  scale_color_manual(values = c(Keeper, Random, Reciprocator)) +
	xlab("Round") +
	ylab("Popularity") +
  labs(color="Player label") +
  scale_x_continuous(lim=c(0,30),breaks=seq(0,30,by=5)) +
  scale_y_continuous(lim=c(0,14),breaks=seq(0,14,by=2))

pdf("figs/popChart_RKGS_10.pdf",width=5.0,height=3.2)
p
dev.off()

master = read.csv('../Evolution/processedData/popChart_RKGS_15.csv')
master = subset(master,Time<31)

p <- ggplot(master, aes(x=Time, y=Popularity, color=Label)) +
	#geom_point() +
	geom_line(aes(linetype=Index)) +
	theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  scale_linetype_manual(values = c(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), guide="none") +
  scale_color_manual(values = c(Random, Reciprocator)) +
	xlab("Round") +
	ylab("Popularity") +
  labs(color="Player label") +
  scale_x_continuous(lim=c(0,30),breaks=seq(0,30,by=5)) +
  scale_y_continuous(lim=c(0,25),breaks=seq(0,25,by=5))

pdf("figs/popChart_RKGS_15.pdf",width=5.0,height=3.2)
p
dev.off()

master = read.csv('../Evolution/processedData/popChart_RKGS_17.csv')
master = subset(master,Time<31)

p <- ggplot(master, aes(x=Time, y=Popularity, color=Label)) +
	#geom_point() +
	geom_line(aes(linetype=Index)) +
	theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  scale_linetype_manual(values = c(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), guide="none") +
  scale_color_manual(values = c(Keeper, Predator, Reciprocator)) +
	xlab("Round") +
	ylab("Popularity") +
  labs(color="Player label") +
  scale_x_continuous(lim=c(0,30),breaks=seq(0,30,by=5)) +
  scale_y_continuous(lim=c(0,14),breaks=seq(0,14,by=2))

pdf("figs/popChart_RKGS_17.pdf",width=5.0,height=3.2)
p
dev.off()

master = read.csv('../Evolution/processedData/popChart_RKGS_19.csv')
master = subset(master,Time<31)

p <- ggplot(master, aes(x=Time, y=Popularity, color=Label)) +
	#geom_point() +
	geom_line(aes(linetype=Index)) +
	theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  scale_linetype_manual(values = c(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), guide="none") +
  scale_color_manual(values = c(Keeper, Predator, Random, Reciprocator)) +
	xlab("Round") +
	ylab("Popularity") +
  labs(color="Player label") +
  scale_x_continuous(lim=c(0,30),breaks=seq(0,30,by=5)) +
  scale_y_continuous(lim=c(0,25),breaks=seq(0,25,by=5))

pdf("figs/popChart_RKGS_19.pdf",width=5.0,height=3.2)
p
dev.off()

master = read.csv('../Evolution/processedData/popChart_RKGS_27.csv')
master = subset(master,Time<31)

p <- ggplot(master, aes(x=Time, y=Popularity, color=Label)) +
	#geom_point() +
	geom_line(aes(linetype=Index)) +
	theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid.minor = element_blank()) +
	theme(plot.title = element_text(size=14, face="bold")) +
	theme(axis.title.x = element_text(size = 12, face="bold"), axis.title.y = element_text(size = 12, face="bold")) +
	theme(axis.text.x = element_text(size = 7), axis.text.y = element_text(size = 10)) +
	theme(legend.title = element_text(size = 10, face="bold"), legend.text = element_text(size = 10)) +
  scale_linetype_manual(values = c(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), guide="none") +
  scale_color_manual(values = c(Keeper, Predator, Random, Reciprocator)) +
	xlab("Round") +
	ylab("Popularity") +
  labs(color="Player label") +
  scale_x_continuous(lim=c(0,30),breaks=seq(0,30,by=5)) +
  scale_y_continuous(lim=c(0,25),breaks=seq(0,25,by=5))

pdf("figs/popChart_RKGS_27.pdf",width=5.0,height=3.2)
p
dev.off()
